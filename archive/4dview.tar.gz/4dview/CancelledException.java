//***********************************************************************
//***********************************************************************
//*		C L A S S  C A N C E L L E D  E X C E P T I O N
//*		Added 1/22/03 for v1.70
//***********************************************************************
//***********************************************************************

class CancelledException extends Exception
{
	//***** This exception is can be thrown anywhere by the application if the user has
	//***** attempted to cancel a procedure which is underway.

}// end of class CancelledException
