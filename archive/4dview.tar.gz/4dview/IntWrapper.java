import java.awt.*;

public class IntWrapper
{
	int		value;

	public IntWrapper()
	{
		this.value = 0;
		return;

	}// init()

	public IntWrapper(int i)
	{
		this.value = i;
		return;
	}

	public void setValue(int i)
	{
		this.value = i;
		return;
	}

	public int getValue()
	{
		return(this.value);
	}

} // IntWrapper
