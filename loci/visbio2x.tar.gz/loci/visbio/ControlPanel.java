//
// ControlPanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import loci.visbio.util.BioUtil;

/** ControlPanel is the superclass of all control panel types. */
public class ControlPanel extends JScrollPane {

  // -- Fields --

  /** Associated logic manager. */
  protected LogicManager lm;

  /** Name of this control panel. */
  protected String name;

  /** Tip for this control panel. */
  protected String tip;

  /** Panel for placing controls. */
  protected JPanel controls;


  // -- Constructor --

  /** Constructs a control panel. */
  public ControlPanel(LogicManager logic, String name, String tip) {
    super(new JPanel(), VERTICAL_SCROLLBAR_AS_NEEDED,
      HORIZONTAL_SCROLLBAR_NEVER);
    lm = logic;
    this.name = name;
    this.tip = tip;
    JPanel pane = (JPanel) getViewport().getView();

    // control panel with vertical scrollbar
    controls = new JPanel() {
      public Dimension getMaximumSize() { return getPreferredSize(); }
    };
    controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));
    controls.setBorder(new EmptyBorder(10, 10, 10, 10));
    controls.setMaximumSize(controls.getMinimumSize());
    pane.add(controls);
  }


  // -- API methods --

  /** Gets the name of this control panel. */
  public String getName() { return name; }

  /** Gets the tip for this control panel. */
  public String getTip() { return tip; }

}
