//
// BioSlideWidget.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.basic.BasicArrowButton;

import loci.visbio.data.*;
import loci.visbio.util.BioUtil;

/** BioSlideWidget is a widget for exploring one dimension of a dataset. */
public class BioSlideWidget extends JPanel
  implements ActionListener, ChangeListener
{

  // -- Constants --

  /** Size of each arrow button. */
  private static final Dimension BUTTON_SIZE = new Dimension(24, 24);

  // -- Fields --

  /** View manager that gets notified when this component changes. */
  private ViewManager vm;

  /** Linked screen dataset. */
  private ScreenData screen;

  /** Screen dataset dimension affected by this slide widget. */
  private int dim;

  /** Slider bounds. */
  private int lo, hi, step;

  /** Text for slider label. */
  private String sliderText;

  /** Label indicating current slider value. */
  private JLabel current;

  /** Main slider component. */
  private JSlider slider;

  /** Previous step button. */
  private JButton previous;

  /** Next step button. */
  private JButton next;

  /** Current slider value. */
  private int val;

  /** Whether screen needs updating. */
  private boolean screenDirty;

  /** Last slider value where displays were updated. */
  private int last;


  // -- Constructor --

  /** Constructs a new slider widget. */
  public BioSlideWidget(ViewManager vm, ScreenData screen, int dim) {
    this.vm = vm;
    this.screen = screen;
    this.dim = dim;

    // create components
    ScreenDescriptor desc = screen.getDescriptor();
    lo = desc.min[dim];
    hi = desc.max[dim];
    step = desc.step[dim];
    String dimStr = desc.raw.getDimStrings()[dim];

    // ensure upper bound and step size play nice together
    hi -= (hi - lo) % step; 

    // create slider label
    sliderText = "<" + (dim + 1) + "> " + dimStr + ": "; 
    current = BioUtil.makeLabel(sliderText + lo);
    current.setAlignmentY(JLabel.TOP_ALIGNMENT);
    current.setHorizontalTextPosition(JLabel.RIGHT);
    Dimension d = new Dimension(100, current.getPreferredSize().height);
    current.setPreferredSize(d);

    // create slider
    slider = new JSlider(lo, hi, lo);
    slider.setAlignmentY(JSlider.TOP_ALIGNMENT);
    slider.setMinorTickSpacing(step);
    int n = (int) Math.ceil((double) (hi - lo) / (4 * step));
    int majorSpacing = n * step;
    if (majorSpacing > hi - lo) majorSpacing = hi - lo;
    slider.setMajorTickSpacing(majorSpacing);
    slider.setSnapToTicks(true);
    slider.setPaintLabels(true);
    slider.setPaintTicks(true);
    slider.addChangeListener(this);

    // create previous button
    previous = new BasicArrowButton(BasicArrowButton.WEST) {
      public Dimension getMinimumSize() { return BUTTON_SIZE; }
      public Dimension getPreferredSize() { return BUTTON_SIZE; }
      public Dimension getMaximumSize() { return BUTTON_SIZE; }
    };
    previous.setAlignmentY(JButton.TOP_ALIGNMENT);
    previous.setActionCommand("previous");
    previous.addActionListener(this);

    // create next button
    next = new BasicArrowButton(BasicArrowButton.EAST) {
      public Dimension getMinimumSize() { return BUTTON_SIZE; }
      public Dimension getPreferredSize() { return BUTTON_SIZE; }
      public Dimension getMaximumSize() { return BUTTON_SIZE; }
    };
    next.setAlignmentY(JButton.TOP_ALIGNMENT);
    next.setActionCommand("next");
    next.addActionListener(this);

    // lay out components
    setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
    add(current);
    add(previous);
    add(Box.createHorizontalStrut(2));
    add(slider);
    add(Box.createHorizontalStrut(2));
    add(next);

    val = slider.getValue();
    screenDirty = false;
    last = val;
  }


  // -- New API methods --

  /** Sets the slider value to match the given one. */
  public void setValue(int value) {
    if (slider.getValue() != value) slider.setValue(value);
  }

  /** Gets the slider value. */
  public int getValue() { return slider.getValue() - 1; }


  // -- ActionListener API methods --

  /** Called when previous or next button is pushed. */
  public void actionPerformed(ActionEvent e) {
    boolean next = e.getActionCommand().equals("next");
    int n = (int) Math.round((float) (slider.getValue() - lo) / step);
    n += next ? 1 : -1;
    if (n < 0) n = (hi - lo) / step;
    int val = lo + n * step;
    if (val > hi) val = lo;
    slider.setValue(val);
  }


  // -- ChangeListener API methods --

  /** Called when the linked dimensional slider changes. */
  public void stateChanged(ChangeEvent e) {
    doSlider(!slider.getValueIsAdjusting(), true);
  }


  // -- Helper methods --

  /** Recomputes current position based on slider's current value. */
  private void doSlider(boolean updateScreen, boolean updateThumbs) {
    int n = (int) Math.round((float) (slider.getValue() - lo) / step);
    int val = lo + n * step;
    String s = sliderText + val;
    if (!current.getText().equals(s)) current.setText(sliderText + val);

    if (this.val != val) screenDirty = true;
    boolean doScreen = updateScreen && screenDirty;
    boolean doThumbs = updateThumbs && last != val;
    if (!doScreen && !doThumbs && this.val == val) return; // nothing to do
    this.val = val;
    if (doScreen) screenDirty = false;
    if (doThumbs) last = val;

    int[] pos = vm.getPos();
    int[] npos = new int[pos.length];
    System.arraycopy(pos, 0, npos, 0, pos.length);
    npos[dim] = val;
    vm.setPos(npos, doScreen, doThumbs);
  }

}
