//
// CapturePanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.*;
import java.awt.event.*;
import java.rmi.RemoteException;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;

import loci.visbio.*;
import loci.visbio.util.*;

import visad.*;

/** CapturePanel is the control panel for capturing display sequences. */
public class CapturePanel extends ControlPanel
  implements ActionListener, ListSelectionListener
{

  // -- Constants --

  /** Minimum number of frames between display positions. */
  private static final int FRAME_MINIMUM = 5;

  /** Maximum number of frames between display positions. */
  private static final int FRAME_MAXIMUM = 60;


  // -- Fields --

  /** Position list. */
  private JList posList;

  /** Position list model. */
  private DefaultListModel posListModel;

  /** Slider for adjusting movie speed. */
  private JSlider speed;

  /** Output movie frames per second. */
  private SpinWidget fps;

  /** Check box for animation smoothness. */
  private JCheckBox smooth;

  /** Progress bar for movie capture operation. */
  private JProgressBar progress;


  // -- Constructor --

  /** Constructs a control panel for viewing system information. */
  public CapturePanel(LogicManager logic) {
    super(logic, "Capture", "Captures display sequences");
    final VisBio bio = lm.getVisBio();

    // positions label
    JLabel posLabel = BioUtil.makeLabel("Display positions:");
    posLabel.setDisplayedMnemonic('p');
    BioUtil.setTip(bio, posLabel, "List of captured display positions");
    controls.add(BioUtil.pad(posLabel));

    // positions list
    posListModel = new DefaultListModel();
    posList = new JList(posListModel);
    posList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    posList.addListSelectionListener(this);
    posLabel.setLabelFor(posList);
    BioUtil.setTip(bio, posList, "List of captured display positions");
    JScrollPane scroll = new JScrollPane(posList) {
      public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(250, 200);
      }
    };
    controls.add(BioUtil.pad(scroll));

    // add button
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JButton add = new JButton("Add");
    add.setActionCommand("Add");
    add.addActionListener(this);
    add.setMnemonic('a');
    BioUtil.setTip(bio, add, "Adds the current display position to the list");
    p.add(add);

    // remove button
    JButton remove = new JButton("Remove");
    remove.setActionCommand("Remove");
    remove.addActionListener(this);
    remove.setMnemonic('r');
    BioUtil.setTip(bio, remove,
      "Removes the selected display position from the list");
    p.add(remove);
    p.add(Box.createHorizontalStrut(5));

    // up button
    JButton up = new JButton("Up");
    up.setActionCommand("Up");
    up.addActionListener(this);
    up.setMnemonic('u');
    BioUtil.setTip(bio, up,
      "Moves the selected display position up in the list");
    p.add(up);

    // down button
    JButton down = new JButton("Down");
    down.setActionCommand("Down");
    down.addActionListener(this);
    down.setMnemonic('d');
    BioUtil.setTip(bio, down,
      "Moves the selected display position up in the list");
    p.add(down);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // speed label
    JLabel speedLabel = BioUtil.makeLabel("Seconds per transition:");
    speedLabel.setDisplayedMnemonic('s');
    String speedToolTip = "Adjusts display transition speed";
    BioUtil.setTip(bio, speedLabel, speedToolTip);
    controls.add(BioUtil.pad(speedLabel));

    // slow label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel slowLabel = BioUtil.makeLabel("Slow");
    slowLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    p.add(slowLabel);

    // speed slider
    speed = new JSlider(0, 16, 8);
    speed.setAlignmentY(JSlider.TOP_ALIGNMENT);
    speed.setMajorTickSpacing(4);
    speed.setMinorTickSpacing(1);
    Hashtable speedHash = new Hashtable();
    speedHash.put(new Integer(0), BioUtil.makeLabel("4"));
    speedHash.put(new Integer(4), BioUtil.makeLabel("2"));
    speedHash.put(new Integer(8), BioUtil.makeLabel("1"));
    speedHash.put(new Integer(12), BioUtil.makeLabel("1/2"));
    speedHash.put(new Integer(16), BioUtil.makeLabel("1/4"));
    speed.setLabelTable(speedHash);
    speed.setSnapToTicks(true);
    speed.setPaintTicks(true);
    speed.setPaintLabels(true);
    speedLabel.setLabelFor(speed);
    BioUtil.setTip(bio, speed, speedToolTip);
    p.add(BioUtil.pad(speed));

    // fast label
    JLabel fastLabel = BioUtil.makeLabel("Fast");
    fastLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    p.add(fastLabel);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // frames per second label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel fpsLabel = BioUtil.makeLabel("Frames per second: ");
    fpsLabel.setDisplayedMnemonic('o');
    String fpsToolTip = "Adjusts output movie's number of frames per second";
    BioUtil.setTip(bio, fpsLabel, fpsToolTip);
    p.add(fpsLabel);

    // frames per second spinner
    fps = new SpinWidget(1, 600, 10);
    fpsLabel.setLabelFor(fps);
    BioUtil.setTip(bio, fps, fpsToolTip);
    p.add(fps);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // smoothness checkbox
    smooth = new JCheckBox(
      "Emphasize transition at each display position", true);
    smooth.setMnemonic('t');
    BioUtil.setTip(bio, smooth, "Use smooth sine function transitions");
    controls.add(BioUtil.pad(smooth));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // record button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JButton record = new JButton("Record movie");
    record.setActionCommand("Record");
    record.addActionListener(this);
    record.setMnemonic('m');
    BioUtil.setTip(bio, record,
      "Records a movie from the list of display positions");
    p.add(record);
    p.add(Box.createHorizontalStrut(5));

    // progress bar
    progress = new JProgressBar(0, 100);
    BioUtil.setTip(bio, progress, "Displays movie recording progress");
    p.add(progress);
    controls.add(BioUtil.pad(p));
  }


  // -- New API methods --

  /** Sets the progress bar's value. */
  public void setProgress(int value) { progress.setValue(value); }


  // -- ActionListener API methods --

  /** Called when a button is pressed. */
  public void actionPerformed(ActionEvent e) {
    String cmd = e.getActionCommand();
    if (cmd.equals("Add")) {
      VisBio bio = lm.getVisBio();
      ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
      DisplayImpl d = vm.getDisplay3D();
      if (d == null) return;
      ProjectionControl pc = d.getProjectionControl();
      double[] matrix = pc.getMatrix();
      String nextPos = "position" + (posListModel.getSize() + 1);
      String value = (String) JOptionPane.showInputDialog(bio,
        "Position name:", "Add display position",
        JOptionPane.INFORMATION_MESSAGE, null, null, nextPos);
      if (value == null) return;
      posListModel.addElement(new DisplayPosition(value, matrix));
    }
    else if (cmd.equals("Remove")) {
      int ndx = posList.getSelectedIndex();
      if (ndx >= 0) {
        posListModel.removeElementAt(ndx);
        if (posListModel.size() > ndx) posList.setSelectedIndex(ndx);
        else if (ndx > 0) posList.setSelectedIndex(ndx - 1);
      }
    }
    else if (cmd.equals("Up")) {
      int ndx = posList.getSelectedIndex();
      if (ndx >= 1) {
        Object o = posListModel.getElementAt(ndx);
        posListModel.removeElementAt(ndx);
        posListModel.insertElementAt(o, ndx - 1);
        posList.setSelectedIndex(ndx - 1);
      }
    }
    else if (cmd.equals("Down")) {
      int ndx = posList.getSelectedIndex();
      if (ndx >= 0 && ndx < posListModel.size() - 1) {
        Object o = posListModel.getElementAt(ndx);
        posListModel.removeElementAt(ndx);
        posListModel.insertElementAt(o, ndx + 1);
        posList.setSelectedIndex(ndx + 1);
      }
    }
    else if (cmd.equals("Record")) {
      CaptureManager cm = (CaptureManager) lm;
      int size = posListModel.size();
      Vector positions = new Vector(size);
      for (int i=0; i<size; i++) {
        DisplayPosition pos = (DisplayPosition) posListModel.elementAt(i);
        positions.add(pos.getMatrix());
      }
      double secPerTrans = Math.pow(2, 2 - speed.getValue() / 4.0);
      int framesPerSec = fps.getValue();
      boolean sine = smooth.isSelected();
      cm.captureMovie(positions, secPerTrans, framesPerSec, sine);
    }
  }


  // -- ListSelectionListener API methods --

  /** Called when the a new display position is selected. */
  public void valueChanged(ListSelectionEvent e) {
    int ndx = posList.getSelectedIndex();
    if (ndx < 0) return;
    DisplayPosition pos = (DisplayPosition) posListModel.getElementAt(ndx);
    double[] matrix = pos.getMatrix();
    VisBio bio = lm.getVisBio();
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    DisplayImpl d = vm.getDisplay3D();
    if (d == null) return;
    ProjectionControl pc = d.getProjectionControl();
    try { pc.setMatrix(matrix); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

}
