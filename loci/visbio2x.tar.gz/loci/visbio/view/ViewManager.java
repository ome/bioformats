//
// ViewManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import ij.*;
import ij.io.FileSaver;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.rmi.RemoteException;

import javax.swing.*;

import loci.visbio.*;
import loci.visbio.data.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.*;
import loci.visbio.util.*;

import visad.*;
import visad.data.avi.AVIForm;
import visad.java2d.DisplayImplJ2D;
import visad.java3d.*;
import visad.util.*;

/** ViewManager is the class encapsulating VisBio's view logic. */
public class ViewManager extends LogicManager
  implements DataListener, DisplayListener
{

  // -- Constants --

  /** Flag for enabling or disabling Java3D, for debugging. */
  private static final boolean ALLOW_3D = true;

  /** String for automatic View panel option. */
  private static final String AUTO_VIEW =
    "Automatically switch to View panel when displaying screen data";

  /** String for automatic burn-in option. */
  private static final String AUTO_BURN =
    "Automatically burn in full-resolution data while idle";

  /** String for ImageJ quit warning. */
  private static final String WARN_IMAGEJ =
    "Warn about problem where quitting ImageJ also quits VisBio";


  // -- Display components --

  /** Panel containing all VisAD displays. */
  private JPanel displayPane;

  /** VisAD 2-D display. */
  private DisplayImpl display2;

  /** VisAD 3-D display. */
  private DisplayImpl display3;


  // -- Dialogs --

  /** File chooser for snapshots. */
  private JFileChooser snapBox;

  /** File chooser for state saves. */
  private JFileChooser stateBox;

  /** File chooser for captured animation movies. */
  private JFileChooser captureBox;


  // -- Control panel --

  /** View control panel. */
  private ViewPanel viewPanel;


  // -- Data/display mapping objects --

  /** Active screen dataset. */
  private ScreenData screen;

  /** Current position within multidimensional screen dataset. */
  private int[] pos;

  /** Aspect ratio of the display. */
  private double xasp, yasp, zasp;

  /** Current image reference (for 2-D display). */
  private DataReferenceImpl imageRef;

  /** Current stack reference (for 3-D display). */
  private DataReferenceImpl stackRef;

  /** Current slice bounding box reference (for 3-D display). */
  private DataReferenceImpl sliceBoxRef;

  /** Current image data renderer (for 2-D display). */
  private DataRenderer imageRenderer;

  /** Current stack data renderer (for 3-D display). */
  private DataRenderer stackRenderer;

  /** Current slice bounding box data renderer (for 3-D display). */
  private DataRenderer sliceBoxRenderer;

  /** General-purpose RealType for Display.Red mappings. */
  private RealType redType;

  /** General-purpose RealType for Display.Green mappings. */
  private RealType greenType;

  /** General-purpose RealType for Display.Blue mappings. */
  private RealType blueType;


  // -- Data depiction fields --

  /** Indicates 2-D depictions are enabled. */
  private boolean depict2;

  /** Indicates 3-D depictions are enabled. */
  private boolean depict3;

  /** Indicates current 2-D depiction is a thumbnail. */
  private boolean thumbs2;

  /** Indicates current 3-D depiction is a thumbnail. */
  private boolean thumbs3;

  /** Indicates displays are currently animating. */
  private boolean anim;

  /** Axis across which to animate. */
  private int animAxis;

  /** Frame rate at which to animate. */
  private int animRate;

  /** Synchronization object for animation. */
  private Object animSync = new Object();

  /** Indicates 3-D display slice box is enabled. */
  private boolean sliceBox;
 
  /** Indicates 3-D display uses a parallel projection. */
  private boolean parallel;


  // -- Data resolution "burn in" fields --

  /** Indicates current image is being updated. */
  private boolean imageUpdate;

  /** Indicates current full-resolution image is being loaded. */
  private boolean imageLoading;

  /** Indicates current stack is being updated. */
  private boolean stackUpdate;

  /** Indicates current full-resolution stack is being loaded. */
  private boolean stackLoading;

  /** Object notified when full-resolution image is finished updating. */
  private Object imageComplete = new Object();

  /** Object notified when full-resolution stack is finished updating. */
  private Object stackComplete = new Object();

  /** Thread for burning in full-resolution data. */
  private Thread burnThread;


  // -- Other fields --

  /** Wait dialog. */
  private Waiter waiter;


  // -- Constructor --

  /** Constructs a view manager. */
  public ViewManager(VisBio biovis) { super(biovis); }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof DataManager) {
        if (evt.getMessage().equals("set active screen dataset")) {
          setScreenData(((DataManager) lm).getScreenData());
        }
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 12; }


  // -- DataListener API methods --

  /** Called when part of a ScreenData object is recomputed. */
  public void dataComputed(DataEvent e) {
    boolean doStack = false;
    int stackAxis = screen.getDescriptor().stackAxis;

    int eventType = e.getEventType();
    if (eventType == DataEvent.IMAGE_COMPUTED) {
      // update current image
      imageLoading = false;
      FlatField image = screen.getCurrentImage();
      if (image != imageRef.getData()) {
        imageUpdate = true;
        updateStatusBar();
        try { imageRef.setData(image); }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
      else updateStatusBar();
      if (stackAxis < 0) doStack = true;
    }
    else if (eventType == DataEvent.STACK_COMPUTED) doStack = true;

    if (doStack) {
      // update current stack
      stackLoading = false;
      FieldImpl stack = stackAxis < 0 ?
        screen.getCurrentImage() : screen.getCurrentStack();
      if (stackRef != null && stack != stackRef.getData()) {
        stackUpdate = true;
        updateStatusBar();
        try { stackRef.setData(stack); }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
      else updateStatusBar();
    }
  }


  // -- DisplayListener API methods --

  /** Called to notify the display listener of a display event. */
  public synchronized void displayChanged(DisplayEvent e) {
    Display d = e.getDisplay();
    int id = e.getId();
    if (id == DisplayEvent.TRANSFORM_DONE) {
      if (d == display2 && imageUpdate) {
        imageUpdate = false;
        updateStatusBar();
        synchronized (imageComplete) { imageComplete.notifyAll(); }
      }
      else if (d == display3 && stackUpdate) {
        stackUpdate = false;
        updateStatusBar();
        synchronized (stackComplete) { stackComplete.notifyAll(); }
      }
    }
  }


  // -- New API methods --

  /** Adjusts the aspect ratio of the displays. */
  public void setAspect(double x, double y, double z) {
    if (x != x || x == 0.0) x = 1.0;
    if (y != y || y == 0.0) y = 1.0;
    double d = x > y ? x : y;
    double xx = x / d;
    double yy = y / d;
    double zz = z == z ? z / d : 1.0;
    doAspect(display2, xx, yy, zz);
    doAspect(display3, xx, yy, zz);
    xasp = xx;
    yasp = yy;
    zasp = zz;
  }

  /** Sets the active screen dataset. */
  public void setScreenData(ScreenData screen) {
    if (this.screen != null) this.screen.removeDataListener(this);
    this.screen = screen;
    if (screen != null) screen.addDataListener(this);

    try {
      // clear old mappings and references
      display2.removeAllReferences();
      display2.clearMaps();
      if (display3 != null) {
        display3.removeAllReferences();
        display3.clearMaps();
      }
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }

    // clear old data/display mapping objects
    imageRenderer = stackRenderer = sliceBoxRenderer = null;

    if (screen == null) {
      setAspect(1, 1, 1);

      // notify managers that displays are ready for additional configuration
      bio.generateEvent(this, "displays ready", false);
    }
    else {
      waiter.init("Configuring displays");

      // extract needed information from screen dataset
      FlatField image = screen.getCurrentImage();
      FieldImpl stack = screen.getCurrentStack();
      boolean hasThumbs = screen.hasThumbs();
      ScreenDescriptor desc = screen.getDescriptor();
      boolean[] range = desc.range;
      int stackAxis = desc.stackAxis;
      if (stackAxis < 0) stack = image;
      int[] lo = desc.min;
      pos = new int[lo.length];
      System.arraycopy(lo, 0, pos, 0, pos.length);

      // extract needed information from raw dataset
      RawData raw = desc.raw;
      RealType[] types = raw.getTypes();
      MathType imageType = raw.getImageType();
      RealTupleType imageDomain = ((FunctionType) imageType).getDomain();
      MathType imageRange = ((FunctionType) imageType).getRange();
      RealType[] xy = imageDomain.getRealComponents();
      RealType[] rgb = imageRange instanceof RealTupleType ?
        ((RealTupleType) imageRange).getRealComponents() :
        new RealType[] {(RealType) imageRange};

      try {
        // temporarily disable display recomputation
        BioUtil.setDisplayDisabled(display2, true);
        waiter.addDisplay(display2);
        if (display3 != null) {
          BioUtil.setDisplayDisabled(display3, true);
          waiter.addDisplay(display3);

          // Z-axis mapping for 3-D display
          if (stackAxis >= 0) {
            int[] step = desc.step;
            int[] len = screen.getLengths();
            int lo_z = lo[stackAxis];
            int hi_z = lo_z + (len[stackAxis] - 1) * step[stackAxis];
            display3.addMap(makeScalarMap(
              types[stackAxis], Display.ZAxis, lo_z, hi_z));
          }
        }

        // X-axis
        int res_x = desc.raw.getImageWidth();
        display2.addMap(makeScalarMap(xy[0], Display.XAxis, 0, res_x));
        if (display3 != null) {
          display3.addMap(makeScalarMap(xy[0], Display.XAxis, 0, res_x));
        }

        // Y-axis
        int res_y = desc.raw.getImageHeight();
        display2.addMap(makeScalarMap(xy[1], Display.YAxis, 0, res_y));
        if (display3 != null) {
          display3.addMap(makeScalarMap(xy[1], Display.YAxis, 0, res_y));
        }

        // range component color maps
        for (int i=0; i<rgb.length; i++) {
          if (!range[i]) continue;
          display2.addMap(new ScalarMap(rgb[i], Display.RGB));
          if (display3 != null) {
            display3.addMap(new ScalarMap(rgb[i], Display.RGBA));
          }
        }

        // general-purpose color maps
        display2.addMap(makeScalarMap(redType, Display.Red, 0, 1));
        display2.addMap(makeScalarMap(greenType, Display.Green, 0, 1));
        display2.addMap(makeScalarMap(blueType, Display.Blue, 0, 1));
        if (display3 != null) {
          display3.addMap(makeScalarMap(redType, Display.Red, 0, 1));
          display3.addMap(makeScalarMap(greenType, Display.Green, 0, 1));
          display3.addMap(makeScalarMap(blueType, Display.Blue, 0, 1));
        }

        DisplayRenderer dr2 = display2.getDisplayRenderer();
        DisplayRenderer dr3 = display3 == null ?
          null : display3.getDisplayRenderer();

        // add current image to display
        imageRef.setData(image);
        imageRenderer = dr2.makeDefaultRenderer();
        display2.addReferences(imageRenderer, imageRef);

        // add current stack to display
        if (display3 != null) {
          stackRef.setData(stack);
          stackRenderer = dr3.makeDefaultRenderer();
          display3.addReferences(stackRenderer, stackRef);
          sliceBoxRenderer = dr3.makeDefaultRenderer();
          ConstantMap[] cmaps = {
            new ConstantMap(1, Display.Red),
            new ConstantMap(1, Display.Green),
            new ConstantMap(0, Display.Blue),
            new ConstantMap(3, Display.LineWidth)
          };
          display3.addReferences(sliceBoxRenderer, sliceBoxRef, cmaps);
          doSliceBox();
        }

        // adjust display aspect ratio
        setAspect(raw.getImageWidth(), raw.getImageHeight(), Double.NaN);

        // set data depiction flags
        depict2 = depict3 = true;
        thumbs2 = thumbs3 = false;
        anim = false;
        sliceBox = true;
        parallel = false;

        // notify managers that displays are ready for additional configuration
        bio.generateEvent(this, "displays ready", false);

        // re-enable displays
        BioUtil.setDisplayDisabled(display2, false);
        if (display3 != null) BioUtil.setDisplayDisabled(display3, false);
      }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }

      // show progress dialog
      waiter.show();
    }

    viewPanel.updateScreenData(screen);
    bio.generateEvent(this, "apply screen data", false);

    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    StateManager sm = (StateManager) bio.getManager(StateManager.class);
    if (screen != null && om != null && sm != null && !sm.isRestoring()) {
      BooleanOption option = (BooleanOption) om.getOption(AUTO_VIEW);
      if (option.getValue()) {
        // auto-switch to View panel
        PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
        if (pm != null) pm.windowShow("View");
      }
    }
    updateStatusBar();
  }

  /** A slightly crazy hack for making the sliders MUCH more responsive. */
  private long delay = System.currentTimeMillis();

  /** Sets the current position within the screen dataset. */
  public void setPos(int[] pos, boolean updateScreen, boolean updateThumbs) {
    delay = System.currentTimeMillis();
    if (screen == null) return;
    if (anim) updateScreen = false; // no burn-in while animating
    if (!updateScreen && BioUtil.arraysEqual(this.pos, pos)) return;
    try {
      ScreenDescriptor desc = screen.getDescriptor();
      int stackAxis = desc.stackAxis;
      boolean doSliceBox = false;
      boolean doStack = false;
      if (this.pos != null) {
        for (int i=0; i<pos.length; i++) {
          if (this.pos[i] != pos[i]) {
            if (i == stackAxis) doSliceBox = true;
            else doStack = true;
          }
        }
      }
      this.pos = pos;
      updateStatusBar();

      BioUtil.setDisplayDisabled(display2, true);
      BioUtil.setDisplayDisabled(display3, true);
      if (updateThumbs) {
        imageRef.setData(screen.getThumbImage(pos));
        if (doSliceBox) doSliceBox();
        if (doStack && stackRef != null) {
          stackRef.setData(screen.getThumbStack(pos));
        }
      }
      if (updateScreen) updateScreenPos();
      BioUtil.setDisplayDisabled(display2, false);
      BioUtil.setDisplayDisabled(display3, false);

      bio.generateEvent(this, "position change", false);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

  /** Toggles whether 2-D display contains a depiction of the current image. */
  public void toggleDepiction2D(boolean depict) {
    depict2 = depict;
    if (imageRenderer != null) imageRenderer.toggle(depict);
  }

  /** Toggles whether 3-D display contains a depiction of the current stack. */
  public void toggleDepiction3D(boolean depict) {
    depict3 = depict;
    if (stackRenderer != null) stackRenderer.toggle(depict);
  }

  /** Toggles animation across the given axis. */
  public void toggleAnimation() {
    if (anim) anim = false;
    else {
      anim = true;

      // start a new thread for animation
      Thread animThread = new Thread(new Runnable() {
        public void run() {
          while (anim) {
            long waitTime;
            synchronized (animSync) {
              long start = System.currentTimeMillis();
              if (animAxis >= 0) {
                ScreenDescriptor desc = screen.getDescriptor();
                int q = pos[animAxis] + desc.step[animAxis];
                if (q > desc.max[animAxis]) q = desc.min[animAxis];
                viewPanel.setSlider(animAxis, q);
              }
              long end = System.currentTimeMillis();
              waitTime = 1000 / animRate - end + start;
            }
            if (waitTime >= 0) {
              try { Thread.sleep(waitTime); }
              catch (InterruptedException exc) { }
            }
          }
          updateScreenPos();
        }
      });
      animThread.start();
    }
  }

  /** Sets the axis across which animation occurs. */
  public void setAnimationAxis(int axis) {
    synchronized (animSync) { animAxis = axis; }
  }

  /** Sets the frame rate (frames per second) at which animation occurs. */
  public void setAnimationRate(int rate) {
    synchronized (animSync) { animRate = rate; }
  }

  /** Creates an AVI movie of the current animation sequence. */
  public void captureAnimation() {
    if (animAxis < 0) {
      JOptionPane.showMessageDialog(bio, "Cannot record without an " +
        "animation axis.", "Cannot record animation",
        JOptionPane.ERROR_MESSAGE);
      return;
    }
    final AVIForm saver = new AVIForm();
    saver.setFrameRate(animRate);
    final DisplayImpl d2 = getDisplay2D();
    final DisplayImpl d3 = getDisplay3D();

    int stackAxis = screen.getDescriptor().stackAxis;
    boolean do3D = false;
    if (d3 != null && animAxis != stackAxis) {
      // present a dialog to allow choice between 2-D and 3-D
      Object[] choices = {"2-D", "3-D"};
      Object chosen = JOptionPane.showInputDialog(bio,
        "Which display should be recorded?", "VisBio",
        JOptionPane.INFORMATION_MESSAGE, null, choices, choices[0]);
      if (chosen == null) return;
      else if (chosen == choices[1]) do3D = true;
    }
    final DisplayImpl display = do3D ? d3 : d2;

    // get output filename from the user
    int rval = captureBox.showSaveDialog(bio);
    if (rval != JFileChooser.APPROVE_OPTION) return;
    String file = captureBox.getSelectedFile().getPath();
    if (file.indexOf(".") < 0) file = file + ".avi";
    final String filename = file;

    // capture image sequence in a separate thread
    Thread t = new Thread(new Runnable() {
      public void run() {
        BioUtil.setWaitCursor(bio, true);

        // step through each animation position, grabbing images
        ScreenDescriptor desc = screen.getDescriptor();
        int len = screen.getLengths()[animAxis];
        FlatField[] ff = new FlatField[len];
        for (int i=0; i<len; i++) {
          int q = desc.min[animAxis] + i * desc.step[animAxis];
          if (pos[animAxis] != q) {
            if (display == d3) {
              // 3-D display is recording; wait for stack to burn in
              synchronized (stackComplete) {
                viewPanel.setSlider(animAxis, q);
                try { stackComplete.wait(); }
                catch (InterruptedException exc) { exc.printStackTrace(); }
              }
            }
            else if (display == d2) {
              // 2-D display is recording; wait for image to burn in
              synchronized (imageComplete) {
                viewPanel.setSlider(animAxis, q);
                try { imageComplete.wait(); }
                catch (InterruptedException exc) { exc.printStackTrace(); }
              }
            }
            // lame, stupid hack...
            try { Thread.sleep(200); }
            catch (InterruptedException exc) { exc.printStackTrace(); }
          }
          try { ff[i] = DataUtility.makeField(display.getImage(false)); }
          catch (VisADException exc) { exc.printStackTrace(); }
          catch (IOException exc) { exc.printStackTrace(); }
          final int value = 100 * (i + 1) / len;
          Util.invoke(false, new Runnable() {
            public void run() { viewPanel.setProgress(value); }
          });
        }

        try {
          // compile frames into a single data object
          RealType index = RealType.getRealType("index");
          FunctionType ftype = new FunctionType(index, ff[0].getType());
          Integer1DSet fset = new Integer1DSet(len);
          FieldImpl field = new FieldImpl(ftype, fset);
          field.setSamples(ff, false);

          // write data out to AVI file
          saver.save(filename, field, true);
        }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
        catch (IOException exc) { exc.printStackTrace(); }

        Util.invoke(false, new Runnable() {
          public void run() { viewPanel.setProgress(0); }
        });

        // clean up
        ff = null;
        SystemManager.gc();

        BioUtil.setWaitCursor(bio, false);
      }
    });
    t.start();
  }

  /** Packs the VisBio window, but ensures displays are square as well. */
  public void doPack() {
    bio.pack();
    Dimension d = displayPane.getSize();
    int w = d.height;
    if (display3 != null) w /= 2;
    Dimension size = bio.getSize();
    bio.setSize(new Dimension(size.width - d.width + w, size.height));
  }

  /** Restores a display's zoom to the original value. */
  public void resetZoom(DisplayImpl d) {
    if (d instanceof DisplayImplJ2D) {
      try { d.getProjectionControl().resetProjection(); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
      doAspect(d, xasp, yasp, zasp);
    }
    else {
      double scale = d == display2 ? 0.65 : 0.5;
      double rotate = d == display2 ? 0 : 65;
      double[] matrix = d.make_matrix(rotate, 0, 0, scale, 0, 0, 0);
      double[] aspect = new double[]
        {xasp, 0, 0, 0, 0, yasp, 0, 0, 0, 0, zasp, 0, 0, 0, 0, 1};
      matrix = d.multiply_matrix(matrix, aspect);
      try { d.getProjectionControl().setMatrix(matrix); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
    }
  }


  /** Updates screen dataset dimensional position to match the current one. */
  public void updateScreenPos() {
    // get auto-burn option
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      BooleanOption option = (BooleanOption) om.getOption(AUTO_BURN);
      if (option.getValue()) {
        // auto-burn
        Thread t = new Thread(new Runnable() {
          public void run() {
            try { Thread.sleep(2000); }
            catch (InterruptedException exc) { }
            if (System.currentTimeMillis() < delay + 2000) return;
            burn();
          }
        });
        t.start();
        return;
      }
    }
  }

  /** Burns in full-resolution data. */
  public void burn() {
    if (screen == null) return;
    imageLoading = true;
    stackLoading = true;
    try { screen.setCurrentPos(pos); }
    catch (VisADException exc) { exc.printStackTrace(); }
    updateStatusBar();
  }

  /** Updates status bar message to reflect current dimensional position. */
  public void updateStatusBar() {
    StringBuffer sb = new StringBuffer();
    if (screen == null) sb.append("No active screen dataset");
    else {
      ScreenDescriptor desc = screen.getDescriptor();
      String[] dimStr = desc.raw.getDimStrings();
      int[] len = screen.getLengths();
      for (int i=0; i<pos.length; i++) {
        sb.append("<");
        sb.append(i + 1);
        sb.append("> ");
        sb.append(dimStr[i]);
        sb.append(": ");
        sb.append(pos[i]);
        sb.append(" (");
        sb.append((pos[i] - desc.min[i]) / desc.step[i] + 1);
        sb.append(" of ");
        sb.append(len[i]);
        sb.append("); ");
      }
      if (anim) sb.append("animating; ");
      if (imageLoading) sb.append("loading current image; ");
      if (imageUpdate) sb.append("burning in current image; ");
      if (stackLoading) sb.append("loading current stack; ");
      if (stackUpdate) sb.append("burning in current stack; ");
    }
    bio.setDefaultMessage(sb.toString());
  }

  /** Toggles whether 3-D display shows a box around the current slice. */
  public void toggleSliceBox(boolean value) {
    sliceBox = value;
    if (sliceBoxRenderer != null) sliceBoxRenderer.toggle(value);
  }

  /** Toggles whether 3-D display uses a parallel projection. */
  public void toggleParallel(boolean value) {
    parallel = value;
    if (display3 != null) {
      GraphicsModeControlJ3D gmc = (GraphicsModeControlJ3D)
        display3.getGraphicsModeControl();
      try {
        gmc.setProjectionPolicy(parallel ?
          DisplayImplJ3D.PARALLEL_PROJECTION :
          DisplayImplJ3D.PERSPECTIVE_PROJECTION);
      }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
    }
  }

  /** Gets aspect ratio X component. */
  public double getAspectX() { return xasp; }

  /** Gets aspect ratio Y component. */
  public double getAspectY() { return yasp; }

  /** Gets aspect ratio Z component. */
  public double getAspectZ() { return zasp; }

  /** Gets the active screen dataset. */
  public ScreenData getScreenData() { return screen; }

  /** Gets a snapshot of the current displays. */
  public Image getSnapshot() {
    boolean has2 = display2.getComponent().isVisible();
    boolean has3 = display3 != null && display3.getComponent().isVisible();
    BufferedImage image2 = has2 ? display2.getImage() : null;
    BufferedImage image3 = has3 ? display3.getImage() : null;
    int w2 = 0, h2 = 0, w3 = 0, h3 = 0;
    int type = BufferedImage.TYPE_INT_RGB;
    if (!has2 && !has3) w2 = h2 = 1;
    if (has2) {
      w2 = image2.getWidth();
      h2 = image2.getHeight();
      type = image2.getType();
    }
    if (has3) {
      w3 = image3.getWidth();
      h3 = image3.getHeight();
      type = image3.getType();
    }
    BufferedImage img = new BufferedImage(w2 > w3 ? w2 : w3, h2 + h3, type);
    Graphics g = img.createGraphics();
    if (has2) g.drawImage(image2, 0, 0, null);
    if (has3) g.drawImage(image3, 0, h2, null);
    g.dispose();
    return img;
  }

  /** Determines whether 3-D display functions are available. */
  public boolean canDo3D() { return display3 != null; }

  /** Gets the 2-D display. */
  public DisplayImpl getDisplay2D() { return display2; }

  /** Gets the 3-D display. */
  public DisplayImpl getDisplay3D() { return display3; }

  /** Gets all displays associated with the view manager. */
  public DisplayImpl[] getDisplays() {
    int count = 0;
    if (display2 != null) count++;
    if (display3 != null) count++;
    DisplayImpl[] d = new DisplayImpl[count];
    count = 0;
    if (display2 != null) d[count++] = display2;
    if (display3 != null) d[count++] = display3;
    return d;
  }

  /** Gets general-purpose RealType for Display.Red mappings. */
  public RealType getRedType() { return redType; }

  /** Gets general-purpose RealType for Display.Green mappings. */
  public RealType getGreenType() { return greenType; }

  /** Gets general-purpose RealType for Display.Blue mappings. */
  public RealType getBlueType() { return blueType; }

  /** Gets the current position within the screen dataset. */
  public int[] getPos() { return pos; }

  /** Gets whether 2-D display contains a depiction of the current image. */
  public boolean isDepiction2D() { return depict2; }

  /** Gets whether 3-D display contains a depiction of the current stack. */
  public boolean isDepiction3D() { return depict3; }

  /** Gets the axis across which animation occurs. */
  public int getAnimationAxis() { return animAxis; }

  /** Gets the frame rate (frames per second) at which animation occurs. */
  public int getAnimationRate(int rate) { return animRate; }

  /** Gets whether 3-D display shows a box around the current slice. */
  public boolean isSliceBox() { return sliceBox; }

  /** Gets whether 3-D display uses a parallel projection. */
  public boolean isParallel() { return parallel; }


  // -- Helper methods --

  /** Adds view-related GUI components to VisBio. */
  private void doGUI() {
    waiter = new Waiter(bio);
    bio.setStatus("Initializing display logic");
    xasp = yasp = zasp = 1.0;
    redType = RealType.getRealType("bio_red");
    greenType = RealType.getRealType("bio_green");
    blueType = RealType.getRealType("bio_blue");

    bio.setStatus(null);
    displayPane = new JPanel();
    displayPane.setLayout(new BoxLayout(displayPane, BoxLayout.Y_AXIS));
    bio.getContentPane().add(displayPane, BorderLayout.CENTER);
    try {
      boolean do3D = Util.canDoJava3D() && ALLOW_3D;

      // create 2-D display
      bio.setStatus(null);
      display2 = do3D ? (DisplayImpl)
        new DisplayImplJ3D("display2", new TwoDDisplayRendererJ3D()) :
        new DisplayImplJ2D("display2");
      resetZoom(display2);

      // create 3-D display
      bio.setStatus(null);
      if (do3D) {
        display3 = new DisplayImplJ3D("display3");
        resetZoom(display3);
      }
      else display3 = null;

      // set up 2-D display
      bio.setStatus(null);
      doDisplay(display2);
      display2.addDisplayListener(this);
      displayPane.add(display2.getComponent());

      // set up 3-D display
      bio.setStatus(null);
      if (display3 != null) {
        doDisplay(display3);
        display3.getGraphicsModeControl().setLineWidth(2.0f);
        display3.addDisplayListener(this);
        displayPane.add(display3.getComponent());
      }

      // set up data references
      bio.setStatus(null);
      imageRef = new DataReferenceImpl("image_ref");
      if (display3 != null) {
        stackRef = new DataReferenceImpl("stack_ref");
        sliceBoxRef = new DataReferenceImpl("slice_box_ref");
      }
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }

    // snapshot file chooser
    bio.setStatus(null);
    snapBox = new JFileChooser();
    snapBox.addChoosableFileFilter(new ExtensionFileFilter(
      new String[] {"jpg", "jpeg"}, "JPEG files"));
    snapBox.addChoosableFileFilter(new ExtensionFileFilter(
      "raw", "RAW files"));
    snapBox.addChoosableFileFilter(new ExtensionFileFilter(
      new String[] {"tif", "tiff"}, "TIFF files"));

    // save state file chooser
    stateBox = new JFileChooser();
    stateBox.addChoosableFileFilter(new ExtensionFileFilter(
      "txt", "VisBio state files"));

    // snapshot file chooser
    captureBox = new JFileChooser();
    captureBox.addChoosableFileFilter(new ExtensionFileFilter(
      new String[] {"avi"}, "AVI movies"));

    // menu items
    bio.setStatus(null);
    bio.addMenuSeparator("File");
    bio.addMenuItem("File", "Take snapshot...",
      "loci.visbio.view.ViewManager.fileSnap", 't',
      "Saves an image of the current displays");
    bio.addMenuItem("File", "Send snapshot to ImageJ",
      "loci.visbio.view.ViewManager.fileImageJ", 'n',
      "Opens an image of the current displays in ImageJ");

    // control panel
    bio.setStatus(null);
    viewPanel = new ViewPanel(this);
    PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
    if (pm != null) pm.addPanel(viewPanel);

    // options menu
    bio.setStatus(null);
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      om.addBooleanOption("Automation", AUTO_VIEW, 'c',
        "Toggles whether VisBio should bring up the View panel " +
        "as soon as screen data starts being visualized", true);
      om.addBooleanOption("Automation", AUTO_BURN, 'b',
        "Toggles whether VisBio should load and display " +
        "full-resolution data while displays are idle", true);
      om.addBooleanOption("Warnings", WARN_IMAGEJ, 'i',
        "Toggles whether VisBio displays a warning about " +
        "how quitting ImageJ also quits VisBio", true);
    }

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("View", "view.html");

    updateStatusBar();
  }

  /** Adjusts the aspect ratio for the given display. */
  private void doAspect(DisplayImpl d, double x, double y, double z) {
    if (d == null) return;
    ProjectionControl pc = d.getProjectionControl();
    if (d instanceof DisplayImplJ2D) {
      try { pc.setAspect(new double[] {x, y}); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
      return;
    }

    // get old projection matrix
    double[] matrix = pc.getMatrix();

    // clear old aspect ratio from projection matrix
    double[] undo_old_aspect = {
      1 / xasp, 0, 0, 0, 0, 1 / yasp, 0, 0, 0, 0, 1 / zasp, 0, 0, 0, 0, 1
    };
    matrix = d.multiply_matrix(matrix, undo_old_aspect);

    // compute new aspect ratio matrix
    double[] new_aspect = {x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1};
    matrix = d.multiply_matrix(matrix, new_aspect);

    // apply new projection matrix
    try { pc.setMatrix(matrix); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

  /** Recomputes bounding box around current slice. */
  private void doSliceBox() {
    if (sliceBoxRef == null) return;

    ScreenDescriptor desc = screen.getDescriptor();
    int stackAxis = desc.stackAxis;
    if (stackAxis < 0) {
      // no stack
      try { sliceBoxRef.setData(new Real(0)); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
      return;
    }
    RawData raw = desc.raw;
    FunctionType imageType = (FunctionType) raw.getImageType();
    RealTupleType domain = imageType.getDomain();
    RealType[] xy = domain.getRealComponents();
    RealType z = raw.getTypes()[stackAxis];

    int xres = raw.getImageWidth();
    int yres = raw.getImageHeight();
    int slice = pos[stackAxis];
    float[][] samps = {
      {0, xres, xres, 0, 0},
      {0, 0, yres, yres, 0},
      {slice, slice, slice, slice, slice}
    };
    try {
      RealTupleType xyz = new RealTupleType(xy[0], xy[1], z);
      Gridded3DSet box = new Gridded3DSet(xyz, samps, 5);
      sliceBoxRef.setData(box);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }


  // -- Menu commands --

  /** Saves a snapshot of the displays to a file specified by the user. */
  public void fileSnap() {
    int rval = snapBox.showSaveDialog(bio);
    if (rval != JFileChooser.APPROVE_OPTION) return;
    BioUtil.setWaitCursor(bio, true);

    // determine file type
    final String file = snapBox.getSelectedFile().getPath();
    String ext = "";
    int dot = file.indexOf(".");
    if (dot >= 0) ext = file.substring(dot + 1).toLowerCase();
    final boolean tiff = ext.equals("tif") || ext.equals("tiff");
    final boolean jpeg = ext.equals("jpg") || ext.equals("jpeg");
    final boolean raw = ext.equals("raw");
    if (!tiff && !jpeg && !raw) {
      BioUtil.setWaitCursor(bio, false);
      JOptionPane.showMessageDialog(bio, "Invalid filename (" +
        file + "): " + "extension must be TIFF, JPEG or RAW.",
        "Cannot export snapshot", JOptionPane.ERROR_MESSAGE);
      return;
    }

    Thread t = new Thread(new Runnable() {
      public void run() {
        FileSaver saver = new FileSaver(new ImagePlus("null", getSnapshot()));
        if (tiff) saver.saveAsTiff(file);
        else if (jpeg) saver.saveAsJpeg(file);
        else if (raw) saver.saveAsRaw(file);
        BioUtil.setWaitCursor(bio, false);
      }
    });
    t.start();
  }

  /** Sends a snapshot of the displays to ImageJ. */
  public void fileImageJ() {
    BioUtil.setWaitCursor(bio, true);
    Thread t = new Thread(new Runnable() {
      public void run() {
        ImageJ ij = IJ.getInstance();
        if (ij == null || (ij != null && !ij.isShowing())) {
          File dir = new File(System.getProperty("user.dir"));
          File new_dir = new File(dir.getParentFile().getParentFile(), "ij");
          System.setProperty("user.dir", new_dir.getPath());
          new ImageJ(null);
          System.setProperty("user.dir", dir.getPath());
        }
        new ImagePlus("VisBio snapshot", getSnapshot()).show();
        BioUtil.setWaitCursor(bio, false);
        OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
        if (om != null) {
          om.checkWarning(WARN_IMAGEJ, false,
            "Quitting ImageJ will also shut down VisBio, with no warning\n" +
            "or opportunity to save your work. Similarly, quitting VisBio\n" +
            "will shut down ImageJ without warning. Please remember to\n" +
            "save your work in both programs before closing either one.");
        }
      }
    });
    t.start();
  }


  // -- Utility methods --

  /** Configures the given display to VisBio standards. */
  public static void doDisplay(DisplayImpl display)
    throws VisADException, RemoteException
  {
    display.disableEvent(DisplayEvent.MOUSE_PRESSED);
    display.disableEvent(DisplayEvent.FRAME_DONE);
    display.disableEvent(DisplayEvent.MOUSE_PRESSED_LEFT);
    display.disableEvent(DisplayEvent.MOUSE_PRESSED_CENTER);
    display.disableEvent(DisplayEvent.MOUSE_PRESSED_RIGHT);
    display.disableEvent(DisplayEvent.MOUSE_RELEASED);
    display.disableEvent(DisplayEvent.MOUSE_RELEASED_LEFT);
    display.disableEvent(DisplayEvent.MOUSE_RELEASED_CENTER);
    display.disableEvent(DisplayEvent.MOUSE_RELEASED_RIGHT);
    display.disableEvent(DisplayEvent.MAP_ADDED);
    display.disableEvent(DisplayEvent.MAPS_CLEARED);
    display.disableEvent(DisplayEvent.REFERENCE_ADDED);
    display.disableEvent(DisplayEvent.REFERENCE_REMOVED);
    display.disableEvent(DisplayEvent.DESTROYED);
    display.disableEvent(DisplayEvent.MAP_REMOVED);
    display.getMouseBehavior().getMouseHelper().setFunctionMap(new int[][][] {
      {{MouseHelper.DIRECT, MouseHelper.DIRECT},
       {MouseHelper.DIRECT, MouseHelper.DIRECT}},
      {{MouseHelper.CURSOR_TRANSLATE, MouseHelper.CURSOR_ZOOM},
       {MouseHelper.CURSOR_ROTATE, MouseHelper.NONE}},
      {{MouseHelper.ROTATE, MouseHelper.ZOOM},
       {MouseHelper.TRANSLATE, MouseHelper.NONE}}
    });
    display.getGraphicsModeControl().setColorMode(
      GraphicsModeControl.SUM_COLOR_MODE);
    //display.getDisplayRenderer().setPickThreshhold(Float.MAX_VALUE);
  }

  /** Creates a scalar map with the given fixed range. */
  public static ScalarMap makeScalarMap(RealType rt, DisplayRealType drt,
    double lo, double hi) throws VisADException, RemoteException
  {
    ScalarMap map = new ScalarMap(rt, drt);
    map.setRange(lo, hi);
    return map;
  }

  /** Zooms a display by the given amount. */
  public static void setZoom(DisplayImpl d, double scale) {
    try {
      ProjectionControl control = d.getProjectionControl();
      double[] matrix = control.getMatrix();
      double[] zoom = d.make_matrix(0.0, 0.0, 0.0, scale, 0.0, 0.0, 0.0);
      control.setMatrix(d.multiply_matrix(zoom, matrix));
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

}
