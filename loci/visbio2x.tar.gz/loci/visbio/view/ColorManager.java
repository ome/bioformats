//
// ColorManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.Color;
import java.io.*;
import java.rmi.RemoteException;
import java.util.*;

import javax.swing.*;

import loci.visbio.*;
import loci.visbio.data.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.*;
import loci.visbio.util.*;

import visad.*;
import visad.util.*;

/** ColorManager is the class encapsulating VisBio's color logic. */
public class ColorManager extends LogicManager {

  // -- Constants --

  /** RGB color model. */
  public static final int RGB_MODEL = 0;

  /** HSV color model. */
  public static final int HSV_MODEL = 1;

  /** Composite RGB color model. */
  public static final int COMPOSITE_MODEL = 2;

  /** Amount of detail for color. */
  public static final int COLOR_DETAIL = 256;

  /** Starting brightness value. */
  public static final int NORMAL_BRIGHTNESS = COLOR_DETAIL / 2;

  /** Starting contrast value. */
  public static final int NORMAL_CONTRAST = COLOR_DETAIL / 2;

  /** RGB composite color table. */
  public static final float[][] RAINBOW =
    ColorControl.initTableVis5D(new float[3][COLOR_DETAIL]);

  /** Color table file length. */
  private static final int LUT_LEN = 768;


  // -- Dialog pane --

  /** Color dialog pane. */
  private ColorPane colorPane;


  // -- Data object info --

  /** List of range RealTypes mapped to RGB. */
  private RealType[] rgb;


  // -- Color settings --

  /** Brightness and contrast of images. */
  private int brightness, contrast;

  /** Color model (RGB_MODEL, HSV_MODEL or COMPOSITE_MODEL). */
  private int model;

  /** Red, green and blue components of images. */
  private RealType red, green, blue;

  /** Color table range bounds. */
  private double[] lo, hi;

  /** Whether each color table has a fixed color table range. */
  private boolean[] fixed;

  /** Color table for each range component. */
  private float[][][] tables;


  // -- Other fields --

  /** LUT file chooser. */
  private JFileChooser fileBox;

  /** Wait dialog. */
  private Waiter waiter;


  // -- Constructor --

  /** Constructs a color manager. */
  public ColorManager(VisBio biovis) {
    super(biovis);

    brightness = 128;
    contrast = 128;
    model = RGB_MODEL;

    fileBox = new JFileChooser(System.getProperty("user.dir"));
    fileBox.addChoosableFileFilter(
      new ExtensionFileFilter("lut", "Binary color table files"));
  }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof DataManager) {
        if (evt.getMessage().equals("load data")) {
          // get data's range types
          DataManager dm = (DataManager) lm;
          RawData raw = dm.getRawData();
          if (raw == null) rgb = null;
          else {
            MathType imageType = raw.getImageType();
            MathType imageRange = ((FunctionType) imageType).getRange();
            rgb = imageRange instanceof RealTupleType ?
              ((RealTupleType) imageRange).getRealComponents() :
              new RealType[] {(RealType) imageRange};
          }
          int len = rgb == null ? 0 : rgb.length;
          if (lo == null || lo.length != len) {
            lo = new double[len];
            Arrays.fill(lo, 0);
          }
          if (hi == null || hi.length != len) {
            hi = new double[len];
            Arrays.fill(hi, 255);
          }
          if (fixed == null || fixed.length != len) {
            fixed = new boolean[len];
            Arrays.fill(fixed, true);
          }
          StateManager sm = (StateManager) bio.getManager(StateManager.class);
          if (sm == null || !sm.isRestoring()) {
            // compute default color parameters
            colorPane.guessTypes();
            red = colorPane.getRed();
            green = colorPane.getGreen();
            blue = colorPane.getBlue();
            tables = null;
          }
        }
      }
      else if (lm instanceof ViewManager) {
        if (evt.getMessage().equals("displays ready")) {
          // set initial color scheme properly
          applyColors(false);
        }
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 2; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    fout.println(brightness);
    fout.println(contrast);
    fout.println(model);
    fout.println(red == null ? "null" : red.getName());
    fout.println(green == null ? "null" : green.getName());
    fout.println(blue == null ? "null" : blue.getName());
    BioUtil.writeArray(lo, fout);
    BioUtil.writeArray(hi, fout);
    BioUtil.writeArray(fixed, fout);

    // output color table arrays
    if (tables == null) fout.println("null");
    else {
      fout.println(tables.length);
      for (int i=0; i<tables.length; i++) {
        if (tables[i] == null) fout.println("null");
        else {
          fout.println(tables[i].length);
          for (int j=0; j<tables[i].length; j++) {
            BioUtil.writeArray(tables[i][j], fout);
          }
        }
      }
    }
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    try {
      int bright = Integer.parseInt(fin.readLine());
      int cont = Integer.parseInt(fin.readLine());
      int model = Integer.parseInt(fin.readLine());
      String r = fin.readLine();
      String g = fin.readLine();
      String b = fin.readLine();
      RealType red = r.equals("null") ? null : RealType.getRealType(r);
      RealType green = g.equals("null") ? null : RealType.getRealType(g);
      RealType blue = b.equals("null") ? null : RealType.getRealType(b);
      double[] lo = null;
      double[] hi = null;
      boolean[] fixed = null;
      lo = BioUtil.readArray(lo, fin);
      hi = BioUtil.readArray(hi, fin);
      fixed = BioUtil.readArray(fixed, fin);

      // read in color table arrays
      float[][][] tables = null;
      String s = fin.readLine();
      if (!s.equals("null")) {
        int ilen = Integer.parseInt(s);
        tables = new float[ilen][][];
        for (int i=0; i<ilen; i++) {
          s = fin.readLine();
          if (s.equals("null")) tables[i] = null;
          else {
            int jlen = Integer.parseInt(s);
            tables[i] = new float[jlen][];
            for (int j=0; j<jlen; j++) {
              tables[i][j] = BioUtil.readArray(tables[i][j], fin);
            }
          }
        }
      }

      setColors(bright, cont, model, red, green, blue, lo, hi, fixed, tables);
    }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- New API methods --

  /**
   * Displays the color dialog pane onscreen and
   * alters the color scheme as requested.
   */
  public void doColorDialog() {
    DataManager dm = (DataManager) bio.getManager(DataManager.class);
    if (dm != null) {
      ScreenData screen = dm.getScreenData();
      if (screen != null) {
        try { colorPane.setPreviewData(screen.getCurrentImage()); }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
    }
    if (colorPane.showDialog(bio) == ColorPane.APPROVE_OPTION) {
      setColors(colorPane.getBrightness(), colorPane.getContrast(),
        colorPane.getModel(), colorPane.getRed(), colorPane.getGreen(),
        colorPane.getBlue(), colorPane.getLo(), colorPane.getHi(),
        colorPane.getFixed(), colorPane.getTables());
    }
  }

  /** Updates color values to those given. */
  public void setColors(int brightness, int contrast, int model,
    RealType red, RealType green, RealType blue,
    double[] lo, double[] hi, boolean[] fixed, float[][][] tables)
  {
    if (brightness == this.brightness && contrast == this.contrast &&
      model == this.model && BioUtil.objectsEqual(red, this.red) &&
      BioUtil.objectsEqual(green, this.green) &&
      BioUtil.objectsEqual(blue, this.blue) &&
      BioUtil.arraysEqual(lo, this.lo) && BioUtil.arraysEqual(hi, this.hi) &&
      BioUtil.arraysEqual(fixed, this.fixed) &&
      BioUtil.arraysEqual(tables, this.tables))
    {
      return;
    }
    this.brightness = brightness;
    this.contrast = contrast;
    this.model = model;
    this.red = red;
    this.green = green;
    this.blue = blue;
    this.lo = lo;
    this.hi = hi;
    this.fixed = fixed;
    this.tables = tables;
    applyColors(true);
  }

  /**
   * Applies the current color settings, displaying a wait dialog if requested.
   * Computes color tables from the current color settings if necessary.
   */
  public void applyColors(boolean wait) {
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    if (vm == null || vm.getScreenData() == null) return;

    if (wait) waiter.init("Applying color settings");

    DisplayImpl display2 = vm.getDisplay2D();
    DisplayImpl display3 = vm.getDisplay3D();

    // compute color tables from color settings, if necessary
    if (tables == null) {
      tables = computeColorTables(display2, brightness, contrast,
        model, red, green, blue);
    }

    // 2-D display
    if (wait) {
      BioUtil.setDisplayDisabled(display2, true);
      waiter.addDisplay(display2);
    }
    setColorTables(display2, tables, model, lo, hi, fixed);

    // 3-D display
    if (display3 != null) {
      if (wait) {
        BioUtil.setDisplayDisabled(display3, true);
        waiter.addDisplay(display3);
      }
      setColorTables(display3, tables, model, lo, hi, fixed);
    }

    // re-enable displays
    if (wait) {
      BioUtil.setDisplayDisabled(display2, false);
      BioUtil.setDisplayDisabled(display3, false);
      waiter.show();
      bio.generateEvent(this, "color adjustment", true);
    }
  }

  /** Sets the color tables for the given display. */
  public void setColorTables(DisplayImpl d, float[][][] tables,
    int model, double[] lo, double[] hi, boolean[] fixed)
  {
    if (rgb == null) return;

    // set appropriate color mode
    try {
      d.getGraphicsModeControl().setColorMode(model == COMPOSITE_MODEL ?
        GraphicsModeControl.AVERAGE_COLOR_MODE :
        GraphicsModeControl.SUM_COLOR_MODE);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }

    // update colors for each mapping
    ScalarMap[] maps = BioUtil.getMaps(d, rgb);
    boolean rescale = false;
    for (int i=0; i<rgb.length; i++) {
      // apply color table
      boolean doAlpha = maps[i].getDisplayScalar().equals(Display.RGBA);
      BaseColorControl cc = (BaseColorControl) maps[i].getControl();
      float[][] oldt = cc.getTable();
      float[][] t = adjustColorTable(tables[i],
        oldt.length > 3 ? oldt[3] : null, doAlpha);
      try { cc.setTable(t); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }

      // update mapping range
      if (fixed[i]) {
        double[] range = maps[i].getRange();
        if (maps[i].isAutoScale() || range[0] != lo[i] || range[1] != hi[i]) {
          double hii = hi[i];
          if (hii <= lo[i]) hii = lo[i] + 1;
          try { maps[i].setRange(lo[i], hii); }
          catch (VisADException exc) { exc.printStackTrace(); }
          catch (RemoteException exc) { exc.printStackTrace(); }
        }
      }
      else {
        if (!maps[i].isAutoScale()) {
          maps[i].resetAutoScale();
          rescale = true;
        }
      }
    }
    if (rescale) d.reAutoScale();
  }

  /** Computes color tables from the given color settings. */
  public float[][][] computeColorTables(DisplayImpl d, int brightness,
    int contrast, int model, RealType red, RealType green, RealType blue)
  {
    if (rgb == null) return null;

    // compute center and slope from brightness and contrast
    double mid = COLOR_DETAIL / 2.0;
    double slope;
    if (contrast <= mid) slope = contrast / mid;
    else slope = mid / (COLOR_DETAIL - contrast);
    if (slope == Double.POSITIVE_INFINITY) slope = Double.MAX_VALUE;
    double center = (slope + 1) * brightness / COLOR_DETAIL - 0.5 * slope;

    // compute color channel table values from center and slope
    float[] vals = new float[COLOR_DETAIL];
    float[] rvals, gvals, bvals;
    if (model == COMPOSITE_MODEL) {
      rvals = new float[COLOR_DETAIL];
      gvals = new float[COLOR_DETAIL];
      bvals = new float[COLOR_DETAIL];
      float[][] comp = RAINBOW;
      for (int i=0; i<COLOR_DETAIL; i++) {
        rvals[i] = (float) (slope * (comp[0][i] - 0.5) + center);
        gvals[i] = (float) (slope * (comp[1][i] - 0.5) + center);
        bvals[i] = (float) (slope * (comp[2][i] - 0.5) + center);
        if (rvals[i] > 1) rvals[i] = 1;
        if (rvals[i] < 0) rvals[i] = 0;
        if (gvals[i] > 1) gvals[i] = 1;
        if (gvals[i] < 0) gvals[i] = 0;
        if (bvals[i] > 1) bvals[i] = 1;
        if (bvals[i] < 0) bvals[i] = 0;
      }
    }
    else {
      for (int i=0; i<COLOR_DETAIL; i++) {
        vals[i] = (float) (0.5 * slope * (i / mid - 1.0) + center);
      }
      rvals = gvals = bvals = vals;
    }
    for (int i=0; i<COLOR_DETAIL; i++) {
      if (vals[i] < 0.0f) vals[i] = 0.0f;
      else if (vals[i] > 1.0f) vals[i] = 1.0f;
    }

    // update color tables and map ranges
    boolean r_solid = red == BioColorWidget.SOLID;
    boolean g_solid = green == BioColorWidget.SOLID;
    boolean b_solid = blue == BioColorWidget.SOLID;
    ScalarMap[] maps = BioUtil.getMaps(d, rgb);
    float[][][] tables = new float[rgb.length][][];
    for (int j=0; j<rgb.length; j++) {
      RealType rt = rgb[j];
      if (maps[j] == null) continue;

      // fill in color table elements
      float[][] t;
      if (model == COMPOSITE_MODEL) t = new float[][] {rvals, gvals, bvals};
      else {
        t = new float[][] {
          rt.equals(red) ? rvals : new float[COLOR_DETAIL],
          rt.equals(green) ? gvals : new float[COLOR_DETAIL],
          rt.equals(blue) ? bvals : new float[COLOR_DETAIL]
        };
        if (r_solid) Arrays.fill(t[0], 1.0f);
        if (g_solid) Arrays.fill(t[1], 1.0f);
        if (b_solid) Arrays.fill(t[2], 1.0f);

        // convert color table to HSV color model if necessary
        if (model == HSV_MODEL) {
          float[][] newt = new float[3][COLOR_DETAIL];
          for (int i=0; i<COLOR_DETAIL; i++) {
            Color c = new Color(Color.HSBtoRGB(t[0][i], t[1][i], t[2][i]));
            newt[0][i] = c.getRed() / 255f;
            newt[1][i] = c.getGreen() / 255f;
            newt[2][i] = c.getBlue() / 255f;
          }
          t = newt;
        }
      }
      tables[j] = t;
    }
    return tables;
  }

  /**
   * Loads the color table from the given file
   * into the specified color widget.
   */
  public void loadColorTable(LabeledColorWidget lcw, File file) {
    if (file == null) {
      // ask user to specify the file
      int returnVal = fileBox.showOpenDialog(bio);
      if (returnVal != JFileChooser.APPROVE_OPTION) return;
      file = fileBox.getSelectedFile();
    }
    if (file == null || !file.exists()) {
      JOptionPane.showMessageDialog(bio, "Invalid file: " +
        file.getAbsolutePath(), "Cannot load color table",
        JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (file.length() != LUT_LEN) {
      JOptionPane.showMessageDialog(bio, "LUT file must be " + LUT_LEN +
        " bytes long.", "Cannot load color table", JOptionPane.ERROR_MESSAGE);
      return;
    }

    // read in LUT data
    int[] b = new int[LUT_LEN];
    try {
      DataInputStream fin = new DataInputStream(new FileInputStream(file));
      for (int i=0; i<LUT_LEN; i++) b[i] = fin.readUnsignedByte();
      fin.close();
    }
    catch (IOException exc) {
      JOptionPane.showMessageDialog(bio, "Error reading LUT file.",
        "Cannot load color table", JOptionPane.ERROR_MESSAGE);
      return;
    }

    // convert data to VisAD format
    int len = LUT_LEN / 3;
    int count = 0;
    float[][] table = new float[3][len];
    for (int i=0; i<3; i++) {
      for (int j=0; j<len; j++) table[i][j] = b[count++] / 255f;
    }
    lcw.setTable(table);
  }

  /**
   * Saves the color table into the given file
   * from the specified color widget.
   */
  public void saveColorTable(LabeledColorWidget lcw, File file) {
    if (file == null) {
      // ask user to specify the file
      int returnVal = fileBox.showSaveDialog(bio);
      if (returnVal != JFileChooser.APPROVE_OPTION) return;
      file = fileBox.getSelectedFile();
      String s = file.getAbsolutePath();
      if (!s.toLowerCase().endsWith(".lut")) file = new File(s + ".lut");
    }
    if (file == null) return;

    // convert LUT data to binary format
    int len = LUT_LEN / 3;
    float[][] table = lcw.getTable();
    int[] b = new int[LUT_LEN];
    int count = 0;
    for (int i=0; i<3; i++) {
      for (int j=0; j<len; j++) b[count++] = (int) (255 * table[i][j]);
    }

    // write out LUT data
    try {
      DataOutputStream fout = new DataOutputStream(new FileOutputStream(file));
      for (int i=0; i<LUT_LEN; i++) fout.writeByte(b[i]);
      fout.close();
    }
    catch (IOException exc) {
      JOptionPane.showMessageDialog(bio, "Error writing LUT file.",
        "Cannot save color table", JOptionPane.ERROR_MESSAGE);
      return;
    }
  }

  /** Gets list of range RealTypes mapped to RGB. */
  public RealType[] getTypes() { return rgb; }

  /** Gets brightness value. */
  public int getBrightness() { return brightness; }

  /** Gets contrast value. */
  public int getContrast() { return contrast; }

  /** Gets color model (RGB_MODEL, HSV_MODEL or COMPOSITE_MODEL). */
  public int getModel() { return model; }

  /** Gets RealType mapped to red. */
  public RealType getRed() { return red; }

  /** Gets RealType mapped to green. */
  public RealType getGreen() { return green; }

  /** Gets RealType mapped to blue. */
  public RealType getBlue() { return blue; }

  /** Gets color mapping minimums. */
  public double[] getLo() { return lo; }

  /** Gets color mapping maximums. */
  public double[] getHi() { return hi; }

  /** Gets whether each color mapping has a fixed range. */
  public boolean[] getFixed() { return fixed; }

  /** Gets current color tables. */
  public float[][][] getColorTables() { return tables; }


  // -- Helper methods --

  /** Adds color-related GUI components to VisBio. */
  private void doGUI() {
    waiter = new Waiter(bio);

    // dialog pane
    bio.setStatus("Initializing color logic");
    colorPane = new ColorPane(this);

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("Color", "color.html");
  }


  // -- Utility methods --

  /**
   * Ensures the color table is of the proper type (RGB or RGBA).
   *
   * If the alpha is not required but the table has an alpha channel,
   * a new table is returned with the alpha channel stripped out.
   *
   * If alpha is required but the table does not have an alpha channel,
   * a new table is returned with an alpha channel matching the provided
   * one (or all 1s if the provided alpha channel is null or invalid).
   */
  public static float[][] adjustColorTable(float[][] table,
    float[] alpha, boolean doAlpha)
  {
    // Used by: view/ColorManager
    if (table == null || table[0] == null) return null;
    if (table.length == 3) {
      if (!doAlpha) return table;
      int len = table[0].length;
      if (alpha == null || alpha.length != len) {
        alpha = new float[len];
        Arrays.fill(alpha, 1.0f);
      }
      return new float[][] {table[0], table[1], table[2], alpha};
    }
    else { // table.length == 4
      if (doAlpha) return table;
      return new float[][] {table[0], table[1], table[2]};
    }
  }

}
