//
// BioColorWidget.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import loci.visbio.util.*;

import visad.RealType;

/**
 * BioColorWidget is a widget for controlling mappings
 * from range scalars to color scalars.
 */
public class BioColorWidget extends JPanel {

  // -- Constants --


  public static final RealType SOLID = RealType.getRealType("bio_solid");

  private static final String[][] COLOR_NAMES = {
    {"Red", "Green", "Blue"},
    {"Hue", "Saturation", "Value"}
  };


  // -- GUI components --

  private JLabel color;
  private JComboBox scalars;


  // -- Other fields --

  private int model;
  private int type;


  // -- Constructor --

  /** Constructs a new animation widget. */
  public BioColorWidget(int colorType) {
    model = ColorManager.RGB_MODEL;
    type = colorType;

    // create components
    color = BioUtil.makeLabel(COLOR_NAMES[model][type] + ":");
    scalars = new JComboBox();
    scalars.addItem("None");
    scalars.addItem("Full");
    color.setLabelFor(scalars);

    // lay out components
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(Box.createHorizontalGlue());
    p.add(color);
    p.add(Box.createHorizontalGlue());
    add(p);
    add(scalars);
  }


  // -- API methods --

  /** Gets the currently selected RealType, or null if None. */
  public RealType getSelectedItem() {
    Object o = scalars.getSelectedItem();
    if (o instanceof RealType) return (RealType) o;
    String s = (String) o;
    return s.equals("Full") ? SOLID : null;
  }

  /** Gets the widget's color model (RGB, HSV or COMPOSITE). */
  public int getModel() { return model; }

  /** Sets the currently selected RealType. */
  public void setSelectedItem(RealType rt) {
    if (rt == null) scalars.setSelectedIndex(0);
    else scalars.setSelectedItem(rt);
  }

  /** Sets the widget's color model (RGB, HSV or COMPOSITE). */
  public void setModel(int model) {
    this.model = model;
    if (model == ColorManager.COMPOSITE_MODEL) {
      color.setText(COLOR_NAMES[ColorManager.RGB_MODEL][type] + ":");
      color.setEnabled(false);
      scalars.setEnabled(false);
    }
    else {
      color.setText(COLOR_NAMES[model][type] + ":");
      color.setEnabled(true);
      scalars.setEnabled(true);
    }
  }

  /** Adds an item listener to this widget. */
  public void addItemListener(ItemListener l) { scalars.addItemListener(l); }

  /** Removes an item listener from this widget. */
  public void removeItemListener(ItemListener l) {
    scalars.removeItemListener(l);
  }

  /** Sets the mnemonic for this widget. */
  public void setMnemonic(char c) { color.setDisplayedMnemonic(c); }

  /** Sets the tool tip for this widget. */
  public void setToolTipText(String text) {
    color.setToolTipText(text);
    scalars.setToolTipText(text);
  }

  /** Chooses most desirable range type for this widget's color. */
  public void guessType(RealType[] rt) {
    scalars.removeAllItems();
    scalars.addItem("None");
    scalars.addItem("Full");
    if (rt != null) for (int i=0; i<rt.length; i++) scalars.addItem(rt[i]);

    // Autodetect types

    if (model == ColorManager.RGB_MODEL ||
      model == ColorManager.COMPOSITE_MODEL)
    {
      // Case 0: no rtypes
      //   R -> None
      //   G -> None
      //   B -> None
    
      if (rt == null || rt.length == 0) scalars.setSelectedIndex(0); // None

      // Case 1: rtypes.length == 1
      //   R -> rtypes[0]
      //   G -> rtypes[0]
      //   B -> rtypes[0]

      else if (rt.length == 1) scalars.setSelectedItem(rt[0]);

      // Case 2: rtypes.length == 2
      //   R -> rtypes[0]
      //   G -> rtypes[1]
      //   B -> None

      // Case 3: rtypes.length >= 3
      //   R -> rtypes[0]
      //   G -> rtypes[1]
      //   B -> rtypes[2]

      else {
        if (type == 0) scalars.setSelectedItem(rt[0]);
        else if (type == 1) scalars.setSelectedItem(rt[1]);
        else if (type == 2 && rt.length >= 3) scalars.setSelectedItem(rt[2]);
        else scalars.setSelectedIndex(0); // None
      }
    }
    else { // model == ColorManager.HSV_MODEL
      // Case 0: no rtypes
      //   H -> None
      //   S -> None
      //   V -> None

      if (rt == null || rt.length == 0) scalars.setSelectedIndex(0); // None

      // Case 1: rtypes.length >= 1
      //   H -> rtypes[0]
      //   S -> Full
      //   V -> Full

      else {
        if (type == 0) scalars.setSelectedItem(rt[0]);
        else scalars.setSelectedIndex(1); // Full
      }
    }
  }

}
