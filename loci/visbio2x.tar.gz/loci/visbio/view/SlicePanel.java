//
// SlicePanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import loci.visbio.*;
import loci.visbio.util.*;

import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;

import visad.FlatField;

/** SlicePanel is the control panel for adjusting viewing parameters. */
public class SlicePanel extends ControlPanel {

  // -- GUI components --

  /** Label for slice selector. */
  private JLabel sliceLabel;

  /** Active slice selector. */
  private JComboBox sliceBox;

  /** Button for adding a slice. */
  private JButton addSlice;

  /** Button for removing a slice. */
  private JButton removeSlice;

  /** Toggle for whether slice is visible. */
  private JCheckBox sliceVisible;

  /** Label for current slice resolution value. */
  private JLabel sliceValue;

  /** Slider for slice resolution. */
  private JSlider sliceRes;

  /** Toggle for whether slice is superimposed in 3-D display. */
  private JCheckBox showSlice3D;

  /** Toggle for whether slice is continuously recomputed. */
  private JCheckBox sliceContinuous;

  /** Toggle for whether slice is shown in 2-D display. */
  private JCheckBox showSlice2D;

  /** Active arbitrary slice. */
  private ArbitrarySlice activeSlice;

  /** Current data field for slice extraction. */
  private FlatField sliceField;

  /** Maximum resolution for arbitrary slices. */
  private int max_x, max_y;


  // -- Constructor --

  /** Constructs a control panel for adjusting viewing parameters. */
  public SlicePanel(LogicManager logic) {
    super(logic, "Slice", "Controls for arbitrary cross-sectioning");
    final SliceManager sm = (SliceManager) lm;
    final VisBio bio = lm.getVisBio();

    // active arbitrary slice label
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    sliceLabel = BioUtil.makeLabel("Arbitrary slice: ");
    sliceLabel.setDisplayedMnemonic('s');
    String sliceTip = "Changes the active cross-section";
    BioUtil.setTip(bio, sliceLabel, sliceTip);
    sliceLabel.setEnabled(false);
    p.add(sliceLabel);

    // active arbitrary slice combo box
    sliceBox = new JComboBox(new Object[] {"None"});
    sliceBox.setEditable(false);
    sliceBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { updateSlice(); }
    });
    sliceLabel.setLabelFor(sliceBox);
    BioUtil.setTip(bio, sliceBox, sliceTip);
    sliceBox.setEnabled(false);
    p.add(sliceBox);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // add slice button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    addSlice = new JButton("Add");
    addSlice.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        String value = (String) JOptionPane.showInputDialog(bio,
          "Slice name:", "Create slice", JOptionPane.INFORMATION_MESSAGE,
          null, null, "slice" + sliceBox.getItemCount());
        if (value == null) return;
        ArbitrarySlice slice = sm.addSlice(value);
        doSliceRes(slice, sliceRes.getValue());
        slice.setSliceField(sliceField);
        slice.setShow2D(showSlice2D.isSelected());
        slice.setShow3D(true);
        sliceBox.addItem(slice);
        sliceBox.setSelectedItem(slice);
        lm.getVisBio().generateEvent(lm, "add slice", true);
      }
    });
    addSlice.setMnemonic('a');
    BioUtil.setTip(bio, addSlice, "Adds a cross-section to the display");
    addSlice.setEnabled(false);
    p.add(addSlice);

    // remove slice button
    removeSlice = new JButton("Remove");
    removeSlice.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ArbitrarySlice slice = (ArbitrarySlice) sliceBox.getSelectedItem();
        sm.removeSlice(slice);
        sliceBox.removeItem(slice);
      }
    });
    removeSlice.setMnemonic('r');
    BioUtil.setTip(bio, removeSlice,
      "Removes a cross-section from the display");
    removeSlice.setEnabled(false);
    p.add(removeSlice);

    // horizontal spacing
    p.add(Box.createHorizontalStrut(5));


    // slice visibility checkbox
    sliceVisible = new JCheckBox("Visible");
    sliceVisible.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        ArbitrarySlice slice = (ArbitrarySlice) sliceBox.getSelectedItem();
        boolean visible = sliceVisible.isSelected();
        if (visible != slice.isVisible()) {
          slice.setVisible(visible);
          updateSlice();
        }
      }
    });
    sliceVisible.setMnemonic('v');
    BioUtil.setTip(bio, sliceVisible,
      "Toggles visibility of the active cross-section");
    sliceVisible.setEnabled(false);
    p.add(sliceVisible);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // slice slider
    int normal = ArbitrarySlice.DEFAULT_RESOLUTION;
    int res = 2 * normal;
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    sliceRes = new JSlider(0, res, normal);
    sliceRes.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        Object o = sliceBox.getSelectedItem();
        ArbitrarySlice slice = o instanceof ArbitrarySlice &&
          !sliceRes.getValueIsAdjusting() ? (ArbitrarySlice) o : null;
        int res = sliceRes.getValue();
        doSliceRes(slice, res);
      }
    });
    BioUtil.setTip(bio, sliceRes, "Adjusts cross-section resolution");
    sliceRes.setMajorTickSpacing(res / 4);
    sliceRes.setMinorTickSpacing(res / 16);
    sliceRes.setPaintTicks(true);
    sliceRes.setEnabled(false);
    p.add(sliceRes);

    // current slice value
    sliceValue = BioUtil.makeLabel(normal + " x " + normal);
    sliceValue.setPreferredSize(
      BioUtil.makeLabel("9999 x 9999").getPreferredSize());
    BioUtil.setTip(bio, sliceValue, "Current cross-section resolution");
    sliceValue.setEnabled(false);
    p.add(sliceValue);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // checkbox for 3-D slice display
    showSlice3D = new JCheckBox("Show computed slice in 3-D", false);
    showSlice3D.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        ArbitrarySlice slice = (ArbitrarySlice) sliceBox.getSelectedItem();
        boolean show = showSlice3D.isSelected();
        if (show != slice.isShow3D()) slice.setShow3D(show);
      }
    });
    showSlice3D.setMnemonic('3');
    showSlice3D.setEnabled(false);
    BioUtil.setTip(bio, showSlice3D,
      "Superimposes cross-section in the 3-D display");
    controls.add(BioUtil.pad(showSlice3D));

    // continuous update checkbox
    sliceContinuous = new JCheckBox("Update slice continuously", false);
    sliceContinuous.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        ArbitrarySlice slice = (ArbitrarySlice) sliceBox.getSelectedItem();
        boolean c = sliceContinuous.isSelected();
        if (c != slice.isContinuous()) slice.setContinuous(c);
      }
    });
    sliceContinuous.setMnemonic('c');
    BioUtil.setTip(bio, sliceContinuous,
      "Updates the cross-section as you drag the mouse");
    sliceContinuous.setEnabled(false);
    controls.add(BioUtil.pad(sliceContinuous));

    // vertical spacing
    controls.add(Box.createVerticalStrut(5));

    // checkbox for 2-D slice display
    showSlice2D = new JCheckBox("Display computed slice in 2-D window", true);
    showSlice2D.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        ArbitrarySlice slice = (ArbitrarySlice) sliceBox.getSelectedItem();
        boolean show = showSlice2D.isSelected();
        if (show != slice.isShow2D()) {
          slice.setShow2D(show);
          setDepict2D(!show || !slice.isVisible());
        }
      }
    });
    showSlice2D.setMnemonic('2');
    showSlice2D.setEnabled(false);
    BioUtil.setTip(bio, showSlice2D,
      "Displays cross-section in the 2-D display");
    controls.add(BioUtil.pad(showSlice2D));
  }


  // -- New API methods --

  /** Gets the currently selected arbitrary slice. */
  public ArbitrarySlice getSelectedSlice() {
    Object o = sliceBox.getSelectedItem();
    return o instanceof ArbitrarySlice ? (ArbitrarySlice) o : null;
  }

  /** Sets the currently selected arbitrary slice. */
  public void setSelectedSlice(ArbitrarySlice slice) {
    sliceBox.setSelectedItem(slice);
  }

  /** Gets the current list of arbitrary slices. */
  public Vector getArbitrarySlices() {
    Vector v = new Vector();
    int size = sliceBox.getItemCount();
    for (int i=1; i<size; i++) v.add(sliceBox.getItemAt(i));
    return v;
  }

  /** Sets the current list of arbitrary slices. */
  public void setArbitrarySlices(Vector v) {
    int ndx = sliceBox.getSelectedIndex();
    Object none = sliceBox.getItemAt(0);
    sliceBox.removeAllItems();
    sliceBox.addItem(none);
    int size = v.size();
    for (int i=0; i<size; i++) sliceBox.addItem(v.elementAt(i));
    if (ndx < sliceBox.getItemCount()) sliceBox.setSelectedIndex(ndx);
  }

  /** Sets the slider's arbitrary maximum slice resolution. */
  public void setMaximumResolution(int res_x, int res_y) {
    max_x = res_x;
    max_y = res_y;
    int res = res_x > res_y ? res_y : res_x;
    if (sliceRes.getValue() > res) sliceRes.setValue(res);
    sliceRes.setMaximum(res);
    sliceRes.setPaintTicks(false);
    sliceRes.setMajorTickSpacing(res / 4);
    sliceRes.setMinorTickSpacing(res / 16);
    sliceRes.setPaintTicks(true);
  }

  /** Sets the arbitrary slices' data field. */
  public void setSliceField(FlatField sliceField) {
    if (this.sliceField == sliceField) return;
    this.sliceField = sliceField;
    for (int i=0; i<sliceBox.getItemCount(); i++) {
      Object o = sliceBox.getItemAt(i);
      if (!(o instanceof ArbitrarySlice)) continue;
      ArbitrarySlice arb = (ArbitrarySlice) o;
      arb.setSliceField(sliceField);
    }
  }

  /** Enables or disables this control panel. */
  public void setEnabled(boolean enabled) {
    sliceLabel.setEnabled(enabled);
    sliceBox.setEnabled(enabled);
    addSlice.setEnabled(enabled);
  }


  // -- Helper methods --

  /** Updates active arbitrary slice. */
  private void updateSlice() {
    if (activeSlice != null) activeSlice.setShow2D(false);

    Object o = sliceBox.getSelectedItem();
    boolean isSlice = o instanceof ArbitrarySlice;
    removeSlice.setEnabled(isSlice);
    sliceVisible.setEnabled(isSlice);
    sliceValue.setEnabled(isSlice);
    sliceRes.setEnabled(isSlice);
    showSlice2D.setEnabled(isSlice);
    showSlice3D.setEnabled(isSlice);
    sliceContinuous.setEnabled(isSlice);

    boolean do2D = false;
    if (isSlice) {
      ArbitrarySlice slice = (ArbitrarySlice) o;
      activeSlice = slice;
      boolean vis = slice.isVisible();
      sliceVisible.setSelected(vis);
      int res_x = slice.getResolutionX();
      int res_y = slice.getResolutionY();
      sliceRes.setValue(res_x < res_y ? res_x : res_y);
      showSlice3D.setSelected(slice.isShow3D());
      sliceContinuous.setSelected(slice.isContinuous());
      do2D = showSlice2D.isSelected() && vis;
    }
    if (activeSlice != null) activeSlice.setShow2D(do2D);
    setDepict2D(!do2D);
  }

  /** Toggles depiction of normal slice data in 2-D window. */
  private void setDepict2D(boolean depict) {
    VisBio bio = lm.getVisBio();
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    vm.toggleDepiction2D(depict);
  }

  /** Adjusts the given slice's resolution to match that given. */
  private void doSliceRes(ArbitrarySlice slice, int res) {
    if (res < 2) res = 2;
    int res_x, res_y;
    if (max_x < max_y) {
      res_x = res;
      res_y = res * max_y / max_x;
    }
    else {
      res_x = res * max_x / max_y;
      res_y = res;
    }
    sliceValue.setText(res_x + " x " + res_y);
    if (slice != null) {
      int rx = slice.getResolutionX();
      int ry = slice.getResolutionY();
      if (res_x != rx || res_y != ry) slice.setResolution(res_x, res_y);
    }
  }

}
