//
// DisplayPosition.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.io.*;

import loci.visbio.state.*;
import loci.visbio.util.BioUtil;

/** DisplayPosition represents an orientation of the 3-D display. */
public class DisplayPosition implements Saveable, Dynamic {

  // -- Fields --

  /** Name of the group. */
  private String name;

  /** Matrix representing the position. */
  private double[] matrix;


  // -- Constructor --

  /** Constructs an uninitialized display position. */
  public DisplayPosition() { }

  /** Constructs a display position. */
  public DisplayPosition(String name, double[] matrix) {
    this.name = name;
    this.matrix = matrix;
  }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    fout.println(name);
    BioUtil.writeArray(matrix, fout);
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    try {
      name = fin.readLine();
      matrix = BioUtil.readArray(matrix, fin);
    }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- Dynamic API methods --

  /** Tests whether two dynamic objects have matching states. */
  public boolean matches(Dynamic dyn) {
    if (dyn == null || !(dyn instanceof DisplayPosition)) return false;
    DisplayPosition pos = (DisplayPosition) dyn;
    return BioUtil.objectsEqual(name, pos.name) &&
      BioUtil.arraysEqual(matrix, pos.matrix);
  }

  /** Modifies this object's state to match that of the given object. */
  public void initState(Dynamic dyn) {
    if (dyn != null && dyn instanceof DisplayPosition) {
      DisplayPosition pos = (DisplayPosition) dyn;
      name = pos.name;
      matrix = pos.matrix;
    }
  }

  /**
   * Called when this object is being discarded in favor of
   * another object with a matching state.
   */
  public void discard() { }


  // -- New API methods --

  /** Gets the position's string representation (name). */
  public String toString() { return name; }

  /** Gets the positions's name. */
  public String getName() { return name; }

  /** Gets the position's description. */
  public double[] getMatrix() { return matrix; }

}
