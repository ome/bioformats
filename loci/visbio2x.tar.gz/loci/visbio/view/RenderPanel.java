//
// RenderPanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.*;
import java.awt.event.*;
import java.rmi.RemoteException;

import javax.swing.*;
import javax.swing.event.*;

import loci.visbio.*;
import loci.visbio.util.BioUtil;

import visad.*;
import visad.browser.Divider;
import visad.util.Util;

/** RenderPanel is the control panel for doing volume rendering. */
public class RenderPanel extends ControlPanel {

  // -- GUI components --

  /** Toggle for 3-D volume rendering. */
  private JCheckBox doVolume;

  /** Label for current volume rendering resolution value. */
  private JLabel volumeValue;

  /** Slider for volume rendering resolution. */
  private JSlider volumeRes;

  /** Label for alpha. */
  private JLabel alphaLabel;

  /** Bounding labels for alpha slider. */
  private JLabel solidLabel, clearLabel;

  /** Slider for alpha function. */
  private JSlider alpha;

  /** Label for current alpha value. */
  private JLabel alphaValue;


  // -- Other fields --

  /** Maximum resolution for volume rendering. */
  private int maxVolRes;


  // -- Constructor --

  /** Constructs a control panel for adjusting viewing parameters. */
  public RenderPanel(LogicManager lm) {
    super(lm, "Render", "Controls for volume rendering");
    final RenderManager rm = (RenderManager) lm;
    final VisBio bio = lm.getVisBio();

    // volume rendering checkbox
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    doVolume = new JCheckBox("3-D volume rendering: ", false);
    doVolume.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        boolean vol = doVolume.isSelected();
        rm.setVolumeRender(vol);
        alphaLabel.setEnabled(vol);
        solidLabel.setEnabled(vol);
        alpha.setEnabled(vol);
        clearLabel.setEnabled(vol);
        alphaValue.setEnabled(vol);
      }
    });
    doVolume.setMnemonic('v');
    BioUtil.setTip(bio, doVolume, "Enables semi-transparent volume rendering");
    doVolume.setEnabled(false);
    p.add(doVolume);

    // current volume value
    int normal = RenderManager.DEFAULT_VOL_RES;
    int max = RenderManager.MAX_VOL_RES;
    volumeValue = BioUtil.makeLabel(normal + " x " + normal + " x " + normal);
    volumeValue.setPreferredSize(BioUtil.makeLabel(
      max + " x " + max + " x " + max).getPreferredSize());
    BioUtil.setTip(bio, volumeValue, "Volume rendering resolution");
    volumeValue.setEnabled(false);
    p.add(volumeValue);
    controls.add(BioUtil.pad(p));

    // volume slider
    volumeRes = new JSlider(0, max, normal);
    volumeRes.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        doVolumeRes(volumeRes.getValue(), !volumeRes.getValueIsAdjusting());
      }
    });
    BioUtil.setTip(bio, volumeRes, "Adjusts the volume rendering resolution");
    volumeRes.setEnabled(false);
    volumeRes.setMajorTickSpacing(max / 4);
    volumeRes.setMinorTickSpacing(max / 16);
    volumeRes.setPaintTicks(true);
    controls.add(BioUtil.pad(volumeRes));

    // spacing
    controls.add(Box.createVerticalStrut(10));

    // alpha label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    alphaLabel = BioUtil.makeLabel("Transparency:  ");
    alphaLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    alphaLabel.setDisplayedMnemonic('a');
    String alphaToolTip = "Adjusts volume transparency";
    BioUtil.setTip(bio, alphaLabel, alphaToolTip);
    alphaLabel.setEnabled(false);
    p.add(alphaLabel);

    // current alpha value
    alphaValue = BioUtil.makeLabel("x ^ 1.0");
    alphaValue.setPreferredSize(
      BioUtil.makeLabel("x ^ 9999").getPreferredSize());
    alphaValue.setAlignmentY(JLabel.TOP_ALIGNMENT);
    BioUtil.setTip(bio, alphaValue, "Transparency function exponent");
    alphaValue.setEnabled(false);
    p.add(alphaValue);
    controls.add(BioUtil.pad(p));

    // solid label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    solidLabel = BioUtil.makeLabel("Solid");
    solidLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    solidLabel.setEnabled(false);
    p.add(solidLabel);

    // alpha slider
    alpha = new JSlider(0, ColorManager.COLOR_DETAIL,
      ColorManager.COLOR_DETAIL / 2);
    alpha.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        doAlpha(!alpha.getValueIsAdjusting());
      }
    });
    alpha.setAlignmentY(JSlider.TOP_ALIGNMENT);
    alpha.setMajorTickSpacing(ColorManager.COLOR_DETAIL / 4);
    alpha.setMinorTickSpacing(ColorManager.COLOR_DETAIL / 16);
    alpha.setPaintTicks(true);
    alphaLabel.setLabelFor(alpha);
    BioUtil.setTip(bio, alpha, alphaToolTip);
    alpha.setEnabled(false);
    p.add(alpha);

    // clear label
    clearLabel = BioUtil.makeLabel("Clear");
    clearLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    clearLabel.setEnabled(false);
    p.add(clearLabel);
    controls.add(BioUtil.pad(p));
  }


  // -- New API methods --

  /** Sets the slider's maximum volume rendering resolution. */
  public void setMaximumResolution(int res) {
    if (res > RenderManager.MAX_VOL_RES) res = RenderManager.MAX_VOL_RES;
    if (res == volumeRes.getMaximum()) return;

    if (volumeRes.getValue() > res) volumeRes.setValue(res);
    volumeRes.setMaximum(res);
    volumeRes.setPaintTicks(false);
    volumeRes.setMajorTickSpacing(res / 4);
    volumeRes.setMinorTickSpacing(res / 16);
    volumeRes.setPaintTicks(true);
  }

  /** Enables or disables the panel. */
  public void setEnabled(boolean enabled) {
    doVolume.setEnabled(enabled);
    volumeValue.setEnabled(enabled);
    volumeRes.setEnabled(enabled);
  }

  /** Gets the alpha exponent based on the alpha slider's position. */
  public double getAlphaExponent() {
    // [0, 0.5] -> [1/N, 1]
    // [0.5, 1] -> [1, N]
    double value = (double) alpha.getValue() / ColorManager.COLOR_DETAIL;
    boolean invert = value < 0.5;
    if (invert) value = 1 - value;
    double pow = (RenderManager.MAX_POWER - 1) * 2 * (value - 0.5) + 1;
    if (invert) pow = 1 / pow;
    return pow;
  }


  // -- Helper methods --

  /** Adjusts the volume rendering resolution to match that given. */
  private void doVolumeRes(int res, boolean update) {
    if (res < 2) res = 2;
    volumeValue.setText(res + " x " + res + " x " + res);
    if (update) {
      RenderManager rm = (RenderManager) lm;
      rm.setResolution(res);
    }
  }

  /** Updates image alpha, for transparency in volume rendering. */
  private void doAlpha(boolean update) {
    double pow = getAlphaExponent();
    String s = "" + pow;
    if (s.length() > 4) s = s.substring(0, 4);
    alphaValue.setText("x ^ " + s);
    if (update) {
      RenderManager rm = (RenderManager) lm;
      rm.setAlpha(RenderManager.getAlphaTable(pow, ColorManager.COLOR_DETAIL));
    }
  }

}
