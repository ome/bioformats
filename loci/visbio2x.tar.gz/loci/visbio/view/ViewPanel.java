//
// ViewPanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.*;
import java.awt.event.*;
import java.rmi.RemoteException;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;

import loci.visbio.*;
import loci.visbio.data.*;
import loci.visbio.state.*;
import loci.visbio.util.*;

import visad.*;
import visad.util.Util;

/** ViewPanel is the control panel for adjusting viewing parameters. */
public class ViewPanel extends ControlPanel implements ActionListener {

  // -- GUI components --

  /** Button for altering color scheme. */
  private JButton colors;

  /** Button for burning in full-resolution data. */
  private JButton burn;

  /** Button for toggling animation. */
  private JButton animate;

  /** Combo box for selecting animation axis. */
  private JComboBox axisBox;

  /** Progress bar for animation capture operation. */
  private JProgressBar progress;

  /** Pane containing dimensional slider widgets. */
  private JPanel sliders;

  /** List of dimensional slider widgets. */
  private Vector widgets;


  // -- Constructor --

  /** Constructs a control panel for adjusting viewing parameters. */
  public ViewPanel(LogicManager logic) {
    super(logic, "View", "Controls for the displays");
    final VisBio bio = lm.getVisBio();
    final ViewManager vm = (ViewManager) lm;

    // display controls
    DisplayImpl display2 = vm.getDisplay2D();
    controls.add(makeViewControls(new DisplayImpl[] {display2},
      display2.getComponent(), "2-D", "2-D display", '2', true));

    DisplayImpl display3 = vm.getDisplay3D();
    controls.add(makeViewControls(new DisplayImpl[] {display3},
      display3 == null ? null : display3.getComponent(),
      "3-D", "3-D display", '3', true));

    // spacing
    controls.add(Box.createVerticalStrut(5));

    // parallel projection checkbox
    final JCheckBox parallel = new JCheckBox(
      "Use parallel projection for 3-D display", false);
    parallel.setMnemonic('p');
    BioUtil.setTip(bio, parallel, "Toggles whether the 3-D display " +
      "uses a parallel projection (instead of perspective)");
    parallel.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        vm.toggleParallel(parallel.isSelected());
      }
    });
    controls.add(BioUtil.pad(parallel));

    // bounding box around current slice checkbox
    final JCheckBox sliceBound = new JCheckBox(
      "Show bounding box around current slice in 3-D", true);
    sliceBound.setMnemonic('b');
    BioUtil.setTip(bio, sliceBound, "Toggles whether the 3-D display " +
      "highlights the current slice with a bounding box");
    sliceBound.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        vm.toggleSliceBox(sliceBound.isSelected());
      }
    });
    controls.add(BioUtil.pad(sliceBound));

    // spacing
    controls.add(Box.createVerticalStrut(5));

    // edit colors button
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    colors = new JButton("Edit colors");
    colors.setMnemonic('c');
    BioUtil.setTip(bio, colors, "Edits the displayed data's color scheme");
    colors.setActionCommand("colors");
    colors.addActionListener(this);
    colors.setEnabled(false);
    p.add(colors);
    p.add(Box.createHorizontalStrut(5));

    // burn in button
    burn = new JButton("Burn");
    burn.setMnemonic('u');
    BioUtil.setTip(bio, burn, "Loads full-resolution data and displays it");
    burn.setActionCommand("burn");
    burn.addActionListener(this);
    burn.setEnabled(false);
    p.add(burn);
    controls.add(BioUtil.pad(p));

    // spacing
    controls.add(Box.createVerticalStrut(10));

    // animate button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    animate = new JButton("Animate");
    animate.setPreferredSize(animate.getPreferredSize());
    animate.setMnemonic('t');
    BioUtil.setTip(bio, animate, "Toggles animation across the linked axis");
    animate.setActionCommand("animate");
    animate.addActionListener(this);
    animate.setEnabled(false);
    p.add(animate);

    // horizontal spacing
    p.add(Box.createHorizontalStrut(3));

    // FPS label
    JLabel fpsLabel = BioUtil.makeLabel("FPS: ");
    fpsLabel.setDisplayedMnemonic('f');
    BioUtil.setTip(bio, fpsLabel,
      "Adjusts the animation speed (frames per second)");
    p.add(fpsLabel);

    // FPS adjuster
    int animRate = 2;
    final SpinWidget fpsAdjust = new SpinWidget(1, 600, animRate);
    vm.setAnimationRate(animRate);
    fpsAdjust.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        vm.setAnimationRate(fpsAdjust.getValue());
      }
    });
    fpsLabel.setLabelFor(fpsAdjust);
    BioUtil.setTip(bio, fpsAdjust,
      "Adjusts the animation speed (frames per second)");
    p.add(fpsAdjust);

    // horizontal spacing
    p.add(Box.createHorizontalStrut(3));

    // animation axis label
    JLabel axisLabel = BioUtil.makeLabel("Axis: ");
    axisLabel.setDisplayedMnemonic('x');
    String axisTip = "Assigns the axis over which to animate";
    BioUtil.setTip(bio, axisLabel, axisTip);
    p.add(axisLabel);

    // animation axis combo box
    axisBox = new JComboBox(new String[] {"None"});
    axisBox.setActionCommand("axis");
    axisBox.addActionListener(this);
    axisLabel.setLabelFor(axisBox);
    BioUtil.setTip(bio, axisBox, axisTip);
    p.add(axisBox);
    controls.add(BioUtil.pad(p));

/* CTR - Animation movie recording is still buggy; disable for now
    // vertical spacing
    controls.add(Box.createVerticalStrut(3));

    // record button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JButton record = new JButton("Record animation");
    record.setActionCommand("record");
    record.addActionListener(this);
    record.setMnemonic('r');
    BioUtil.setTip(bio, record, "Records a movie of the animation");
    p.add(record);
    p.add(Box.createHorizontalStrut(5));

    // progress bar
    progress = new JProgressBar(0, 100);
    BioUtil.setTip(bio, progress, "Displays movie recording progress");
    p.add(progress);
    controls.add(BioUtil.pad(p));
*/

    // ensure sufficient panel width
    controls.add(Box.createHorizontalStrut(370));

    // sliders panel
    sliders = new JPanel();
    sliders.setLayout(new BoxLayout(sliders, BoxLayout.Y_AXIS));
    controls.add(sliders);

    widgets = new Vector();
  }


  // -- New API methods --

  /** Updates this control panel's GUI based on the given screen dataset. */
  public void updateScreenData(ScreenData screen) {
    ViewManager vm = (ViewManager) lm;

    colors.setEnabled(screen != null);
    burn.setEnabled(screen != null);

    // set up animation axis combo box
    axisBox.removeAllItems();
    axisBox.addItem("None");
    if (screen != null) {
      ScreenDescriptor desc = screen.getDescriptor();
      RawData raw = desc.raw;
      int[] types = raw.getDimTypes();
      String[] s = raw.getDimStrings();
      int axis = 0;
      for (int i=0; i<s.length; i++) {
        axisBox.addItem("<" + (i + 1) + "> " + s[i]);
        if (axis == 0 && types[i] == RawData.TIME) axis = i + 1;
      }
      if (axis == 0 && s.length > 0) axis = 1;
      axisBox.setSelectedIndex(axis);
    }

    // set up sliders
    sliders.removeAll();
    widgets.removeAllElements();
    if (screen != null) {
      int numDim = screen.getDescriptor().min.length;
      for (int i=0; i<numDim; i++) {
        BioSlideWidget bsw = new BioSlideWidget(vm, screen, i);
        sliders.add(Box.createVerticalStrut(10));
        sliders.add(BioUtil.pad(bsw, true, false));
        widgets.add(bsw);
      }
    }

    // repack panel if floating windows are enabled
    VisBio bio = vm.getVisBio();
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    BooleanOption option = (BooleanOption) om.getOption(PanelManager.FLOATING);
    if (option != null && option.getValue()) {
      Window w = BioUtil.getWindow(this);
      w.pack();
    }
  }

  /** Updates the slider at the given index to match the specified value. */
  public void setSlider(int slider, int value) {
    if (sliders.getComponentCount() <= slider) return;
    BioSlideWidget bsw = (BioSlideWidget) widgets.elementAt(slider);
    bsw.setValue(value);
  }

  /** Sets the animation recording progress bar's value. */
  public void setProgress(int value) { progress.setValue(value); }


  // -- ActionListener API methods --

  /** Handles button presses. */
  public void actionPerformed(ActionEvent e) {
    ViewManager vm = (ViewManager) lm;
    VisBio bio = lm.getVisBio();
    String cmd = e.getActionCommand();
    if (cmd.equals("colors")) {
      ColorManager cm = (ColorManager) bio.getManager(ColorManager.class);
      if (cm != null) cm.doColorDialog();
    }
    else if (cmd.equals("burn")) vm.burn();
    else if (cmd.equals("animate")) {
      vm.toggleAnimation();
      if (animate.getText().equals("Animate")) animate.setText("Stop");
      else animate.setText("Animate");
    }
    else if (cmd.equals("axis")) {
      int axis = axisBox.getSelectedIndex() - 1;
      vm.setAnimationAxis(axis);
      animate.setEnabled(axis >= 0);

    }
    else if (cmd.equals("record")) vm.captureAnimation();
  }


  // -- Helper methods --

  /** Creates a panel of view controls for the given display(s). */
  private JPanel makeViewControls(DisplayImpl[] displays, Component component,
    String name, String desc, char mnemonic, boolean visible)
  {
    final DisplayImpl[] d = displays;
    final Component c = component;
    final ViewManager vm = (ViewManager) lm;
    final VisBio bio = vm.getVisBio();

    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));

    // visibility checkbox
    final JCheckBox vis = new JCheckBox(name + ":", visible && c != null);
    vis.setMnemonic(mnemonic);
    BioUtil.setTip(bio, vis, "Toggles visibility of the " + desc);
    if (c == null) vis.setEnabled(false);
    p.add(vis);

    // zoom in button
    final JButton zoomIn =
      BioUtil.makeButton(this, "zoom-in.png", "Zoom in", 6, 6);
    zoomIn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        for (int i=0; i<d.length; i++) ViewManager.setZoom(d[i], 1.5);
      }
    });
    BioUtil.setTip(bio, zoomIn, "Zooms in on the " + desc);
    p.add(zoomIn);

    // zoom reset button
    final JButton zoomReset =
      BioUtil.makeButton(this, "reset.png", "Reset", 6, 6);
    zoomReset.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        for (int i=0; i<d.length; i++) vm.resetZoom(d[i]);
      }
    });
    BioUtil.setTip(bio, zoomReset,
      "Resets zoom and orientation for the " + desc);
    p.add(zoomReset);

    // zoom out button
    final JButton zoomOut =
      BioUtil.makeButton(this, "zoom-out.png", "Zoom out", 6, 6);
    zoomOut.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        for (int i=0; i<d.length; i++) ViewManager.setZoom(d[i], 0.667);
      }
    });
    BioUtil.setTip(bio, zoomOut, "Zooms out on the " + desc);
    p.add(zoomOut);
    p.add(Box.createHorizontalStrut(5));

    // data visibility button
    final JButton toggleData =
      BioUtil.makeButton(this, "data.png", "Toggle data", 6, 6);
    toggleData.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        DisplayImpl display2 = vm.getDisplay2D();
        DisplayImpl display3 = vm.getDisplay3D();
        if (d[0] == display2) vm.toggleDepiction2D(!vm.isDepiction2D());
        else if (d[0] == display3) vm.toggleDepiction3D(!vm.isDepiction3D());
      }
    });
    BioUtil.setTip(bio, toggleData, "Toggles data visibility for the " + desc);
    p.add(toggleData);

    // bounding box button
    final JButton toggleBox =
      BioUtil.makeButton(this, "box.png", "Toggle box", 6, 6);
    toggleBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try {
          for (int i=0; i<d.length; i++) {
            DisplayRenderer dr = d[i].getDisplayRenderer();
            dr.setBoxOn(!dr.getBoxOn());
          }
        }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
    });
    BioUtil.setTip(bio, toggleBox,
      "Toggles bounding box visibility for the " + desc);
    p.add(toggleBox);

    vis.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        boolean b = vis.isSelected();
        c.setVisible(b);
        zoomIn.setEnabled(b);
        zoomReset.setEnabled(b);
        zoomOut.setEnabled(b);
        toggleData.setEnabled(b);
        toggleBox.setEnabled(b);
      }
    });
    if (!vis.isSelected()) {
      zoomIn.setEnabled(false);
      zoomReset.setEnabled(false);
      zoomOut.setEnabled(false);
      toggleData.setEnabled(false);
      toggleBox.setEnabled(false);
    }

    return BioUtil.pad(p);
  }

}
