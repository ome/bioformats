//
// SliceManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.Color;

import java.io.*;

import java.rmi.RemoteException;
import java.util.Vector;

import loci.visbio.*;
import loci.visbio.data.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.*;
import loci.visbio.util.*;

import visad.*;

/**
 * SliceManager is the class encapsulating
 * VisBio's arbitrary cross-sectioning logic.
 */
public class SliceManager extends LogicManager implements DataListener {

  // -- Constants --

  /** Line colors for arbitrary slices. */
  private static final Color[] SLICE_COLORS = {
    Color.cyan, Color.cyan, Color.cyan
  };


  // -- Control panel --

  /** Slice control panel. */
  private SlicePanel slicePanel;


  // -- Other fields --

  /** Current uncollapsed stack data. */
  private FieldImpl field;


  // -- Constructor --

  /** Constructs an arbitrary slice manager. */
  public SliceManager(VisBio biovis) { super(biovis); }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof ViewManager) {
        if (evt.getMessage().equals("apply screen data")) {
          ViewManager vm = (ViewManager) lm;
          ScreenData screen = vm.getScreenData();
          boolean enabled = false;
          if (screen != null) {
            ScreenDescriptor desc = screen.getDescriptor();
            if (desc.stackAxis >= 0) {
              if (screen.getLengths()[desc.stackAxis] > 1) enabled = true;
            }
            slicePanel.setMaximumResolution(desc.image_x, desc.image_y);
            screen.addDataListener(this);
          }
          slicePanel.setEnabled(enabled);
        }
        else if (evt.getMessage().equals("position change")) {
          try { updateSliceField(true); }
          catch (VisADException exc) { exc.printStackTrace(); }
          catch (RemoteException exc) { exc.printStackTrace(); }
        }
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 2; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    // save arbitrary slices
    Vector v = slicePanel.getArbitrarySlices();
    int num = v.size();
    fout.println(num);
    for (int i=0; i<num; i++) {
      ((ArbitrarySlice) v.elementAt(i)).saveState(fout);
    }

    // save current arbitrary slice index
    ArbitrarySlice slice = slicePanel.getSelectedSlice();
    fout.println(v.indexOf(slice));
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    // restore arbitrary slices
    int num;
    try { num = Integer.parseInt(fin.readLine()); }
    catch (IOException exc) { throw new SaveException(exc); }
    Vector old_slices = slicePanel.getArbitrarySlices();
    Vector new_slices = new Vector(num);
    for (int i=0; i<num; i++) {
      ArbitrarySlice slice = new ArbitrarySlice();
      slice.restoreState(fin);
      new_slices.add(slice);
    }
    StateManager.mergeStates(old_slices, new_slices);
    slicePanel.setArbitrarySlices(new_slices);

    // restore current arbitrary slice
    int cur;
    try { cur = Integer.parseInt(fin.readLine()); }
    catch (IOException exc) { throw new SaveException(exc); }
    if (cur < 0 || cur >= num) slicePanel.setSelectedSlice(null);
    else {
      ArbitrarySlice slice = (ArbitrarySlice) new_slices.elementAt(cur);
      slicePanel.setSelectedSlice(slice);
    }
  }


  // -- DataListener API methods --

  /** Called when part of a ScreenData object is recomputed. */
  public void dataComputed(DataEvent e) {
    int eventType = e.getEventType();
    if (eventType == DataEvent.STACK_COMPUTED) {
      try { updateSliceField(false); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
      bio.generateEvent(this, "slice computed", false);
    }
  }

  // -- New API methods --

  /** Creates a new arbitrary slice and adds it to the display. */
  public ArbitrarySlice addSlice(String name) {
    try { updateSliceField(false); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    DisplayImpl display2 = vm.getDisplay2D();
    DisplayImpl display3 = vm.getDisplay3D();
    ArbitrarySlice slice = new ArbitrarySlice(name, SLICE_COLORS, Color.white);
    try { slice.link(display2, display3); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
    slice.setVisible(true);
    return slice;
  }

  /** Removes an arbitrary slice from the display. */
  public void removeSlice(ArbitrarySlice slice) {
    try { slice.unlink(); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
    bio.generateEvent(this, "remove slice", true);
  }


  // -- Helper methods --

  /** Adds view-related GUI components to VisBio. */
  private void doGUI() {
    // control panel
    bio.setStatus("Initializing slicing logic");
    slicePanel = new SlicePanel(this);
    PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
    if (pm != null) pm.addPanel(slicePanel);

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("Slice", "slice.html");
  }

  /** Updates arbitrary slice field to match the current timestep. */
  private void updateSliceField(boolean thumbs)
    throws VisADException, RemoteException
  {
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    ScreenData screen = vm.getScreenData();
    FieldImpl f = null;
    if (thumbs) {
      ScreenDescriptor desc = screen.getDescriptor();
      if (desc.stackAxis < 0) return; // cannot do slice w/o image stack
      int len = screen.getLengths()[desc.stackAxis];
      int[] pos = vm.getPos();
      int min = desc.min[desc.stackAxis];
      int step = desc.step[desc.stackAxis];
      int[] ndx = new int[pos.length];
      System.arraycopy(pos, 0, ndx, 0, pos.length);
      for (int i=0; i<len; i++) {
        ndx[desc.stackAxis] = min + i * step;
        FlatField thumb = screen.getThumbImage(ndx);
        if (thumb == null) return; // cannot do lowres slice w/o thumbnails
        GriddedSet thumbSet = (GriddedSet) thumb.getDomainSet();
        int[] lengths = thumbSet.getLengths();
        Linear2DSet set = new Linear2DSet(thumbSet.getType(),
          1, desc.stack_x, lengths[0],
          1, desc.stack_y, lengths[1]);
        FlatField ff = new FlatField((FunctionType) thumb.getType(), set);
        ff.setSamples(thumb.getValues(false), false);
        if (i == 0) {
          FunctionType stackType = screen.getStackTypes()[desc.stackAxis];
          Linear1DSet stackSet = screen.getSets()[desc.stackAxis];
          f = new FieldImpl(stackType, stackSet);
        }
        f.setSample(i, ff);
      }
    }
    else f = screen.getCurrentStack();
    if (f == field) return; // no update needed
    field = f;
    slicePanel.setSliceField(BioUtil.collapse(f));
  }

}
