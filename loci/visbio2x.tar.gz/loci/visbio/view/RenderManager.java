//
// RenderManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.io.*;

import java.rmi.RemoteException;
import java.util.Arrays;

import loci.visbio.*;
import loci.visbio.data.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.Waiter;
import loci.visbio.util.*;

import visad.*;

/**
 * RenderManager is the class encapsulating VisBio's volume rendering logic.
 */
public class RenderManager extends LogicManager implements DataListener {

  // -- Constants --

  /** Maximum resolution for volume rendering. */
  public static final int MAX_VOL_RES = 192;

  /** Default resolution for volume rendering. */
  public static final int DEFAULT_VOL_RES = 64;

  /** Maximum alpha exponent. */
  public static final int MAX_POWER = 8;

  /** Dummy data. */
  private static final DataImpl DUMMY = new Real(0);

  /** Solid alpha color table. */
  private static final float[] SOLID_TABLE =
    getSolidTable(ColorManager.COLOR_DETAIL);


  // -- Control panel --

  /** Render control panel. */
  private RenderPanel renderPanel;


  // -- Data fields --

  /** Display in which volume rendering takes place. */
  private DisplayImpl display;

  /** List of range RealTypes mapped to RGB. */
  private RealType[] rgb;

  /** Volume data reference. */
  private DataReferenceImpl volumeRef;

  /** Volume data renderer. */
  private DataRenderer volumeRenderer;

  /** Current uncollapsed stack data. */
  private FieldImpl field;

  /** Current collapsed stack data. */
  private FlatField collapse;


  // -- Rendering parameters --

  /** Whether volume rendering is currently active. */
  private boolean volume;

  /** Resolution of volume rendering. */
  private int volumeRes;


  // -- Other fields --

  /** Wait dialog. */
  private Waiter waiter;

  /** Flag indicating volume rendering still needs to be enabled. */
  private boolean needsEnabling;

  /** Flag indicating resolution was changed while rendering was off. */
  private boolean resChanged;


  // -- Constructor --

  /** Constructs a rendering manager. */
  public RenderManager(VisBio biovis) { super(biovis); }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof DataManager) {
        if (evt.getMessage().equals("load data")) {
          // get data's range types
          DataManager dm = (DataManager) lm;
          RawData raw = dm.getRawData();
          if (raw == null) rgb = null;
          else {
            MathType imageType = raw.getImageType();
            MathType imageRange = ((FunctionType) imageType).getRange();
            rgb = imageRange instanceof RealTupleType ?
              ((RealTupleType) imageRange).getRealComponents() :
              new RealType[] {(RealType) imageRange};
          }
        }
      }
      else if (lm instanceof ViewManager) {
        String msg = evt.getMessage();
        if (msg.equals("displays ready")) {
          ViewManager vm = (ViewManager) lm;
          display = vm.getDisplay3D();
          if (display != null) {
            DisplayRenderer dr = display.getDisplayRenderer();
            volumeRenderer = dr.makeDefaultRenderer();
            try { display.addReferences(volumeRenderer, volumeRef); }
            catch (VisADException exc) { exc.printStackTrace(); }
            catch (RemoteException exc) { exc.printStackTrace(); }
            volumeRenderer.toggle(false);
          }
        }
        else if (msg.equals("apply screen data")) {
          ViewManager vm = (ViewManager) lm;
          ScreenData screen = vm.getScreenData();
          boolean enabled = false;
          if (screen != null) {
            ScreenDescriptor desc = screen.getDescriptor();
            int stackAxis = desc.stackAxis;
            if (stackAxis >= 0) {
              int slices = screen.getLengths()[stackAxis];
              if (slices > 1) {
                enabled = true;
                int res_x = desc.raw.getImageWidth();
                int res_y = desc.raw.getImageHeight();
                int res = res_x > res_y ? res_x : res_y;
                if (slices > res) res = slices;
                renderPanel.setMaximumResolution(res);
              }
            }
            screen.addDataListener(this);
          }
          renderPanel.setEnabled(enabled);
        }
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 2; }


  // -- DataListener API methods --

  /** Called when part of a ScreenData object is recomputed. */
  public void dataComputed(DataEvent e) {
    int eventType = e.getEventType();
    if (eventType == DataEvent.STACK_COMPUTED) {
      synchronized (waiter) {
        if (volume) computeVolume(false);
      }
      SystemManager.gc(); // volume rendering seems to generate lots of waste
      bio.generateEvent(this, "volume rendering computed", false);
    }
  }


  // -- New API methods --

  /** Toggles volume rendering on or off. */
  public void setVolumeRender(boolean on) {
    if (volume == on) return;
    synchronized (waiter) {
      volume = on;
      ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
      if (volume) {
        needsEnabling = true;
        if (needsEnabling) {
          ScreenData screen = vm.getScreenData();
          try {
            // force STACK_COMPUTED message
            screen.setCurrentPos(screen.getCurrentPos()); 
          }
          catch (VisADException exc) { exc.printStackTrace(); }
        }
      }
      else doRenderDisable();
    }
    bio.generateEvent(this, "toggle volume rendering", false);
  }

  /** Sets cubic resolution of volume rendering. */
  public void setResolution(int res) {
    if (volumeRes == res) return;
    volumeRes = res;
    if (volume) {
      synchronized (waiter) { computeVolume(true); }
    }
    else resChanged = true;
  }

  /** Sets alpha component of volume rendered display. */
  public void setAlpha(float[] table) {
    // update color table alpha components
    ScalarMap[] maps = BioUtil.getMaps(display, rgb);
    for (int j=0; j<maps.length; j++) {
      if (maps[j] == null) continue;
      if (!maps[j].getDisplayScalar().equals(Display.RGBA)) continue;
      BaseColorControl cc = (BaseColorControl) maps[j].getControl();
      float[][] t = cc.getTable();
      t[3] = table; // switch to new alpha table
      try { cc.setTable(t); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
    }
  }


  // -- Helper methods --

  /** Adds view-related GUI components to VisBio. */
  private void doGUI() {
    waiter = new Waiter(bio);

    // volume reference
    try {
      volumeRef = new DataReferenceImpl("volume_ref");
      volumeRef.setData(DUMMY);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
    volumeRes = DEFAULT_VOL_RES;

    // control panel
    bio.setStatus("Initializing rendering logic");
    renderPanel = new RenderPanel(this);
    PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
    if (pm != null) pm.addPanel(renderPanel);

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("Render", "render.html");
  }

  /** Enables volume rendering within the display. */
  private void doRenderEnable() {
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    vm.toggleDepiction3D(false);
    setAlpha(getAlphaTable(renderPanel.getAlphaExponent(),
      ColorManager.COLOR_DETAIL));
    volumeRenderer.toggle(true);
    needsEnabling = false;
  }

  /** Disables volume rendering within the display. */
  private void doRenderDisable() {
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    volumeRenderer.toggle(false);
    setAlpha(SOLID_TABLE);
    vm.toggleDepiction3D(true);
  }

  /** Computes volume field and waits for rendering to complete. */
  private void computeVolume(boolean force) {
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    ScreenData screen = vm.getScreenData();
    final FieldImpl f = screen.getCurrentStack();
    final boolean collapse = f != field;
    final boolean fforce = force;
    if (!collapse && !fforce && !needsEnabling) return;
    waiter.init("Generating volume");
    waiter.addDisplay(display);
    waiter.go(new Runnable() {
      public void run() {
        if (collapse || fforce || resChanged) {
          field = f;
          waiter.setText("Computing volume");
          try { updateVolumeField(collapse); }
          catch (VisADException exc) { exc.printStackTrace(); }
          catch (RemoteException exc) { exc.printStackTrace(); }
          resChanged = false;
        }
        if (needsEnabling) {
          waiter.setText("Enabling rendering");
          doRenderEnable();
        }
        waiter.setText("Rendering volume");
      }
    });
  }

  /** Updates volume rendering field to match the current timestep. */
  private void updateVolumeField(boolean doCollapse)
    throws VisADException, RemoteException
  {
    if (doCollapse) collapse = BioUtil.collapse(field);
    FlatField volumeField = null;
    GriddedSet set = (GriddedSet) collapse.getDomainSet();
    int[] len = set.getLengths();
    if (len[0] == volumeRes && len[1] == volumeRes && len[2] == volumeRes) {
      volumeField = collapse;
    }
    else {
      float[] lo = set.getLow();
      float[] hi = set.getHi();
      Linear3DSet nset = new Linear3DSet(set.getType(), lo[0], hi[0],
        volumeRes, lo[1], hi[1], volumeRes, lo[2], hi[2], volumeRes);
      volumeField = (FlatField) collapse.resample(nset,
        Data.WEIGHTED_AVERAGE, Data.NO_ERRORS);
    }
    if (volume) volumeRef.setData(volumeField);
  }


  // -- Utility methods --

  /** Creates a table filled with 1s. */
  private static float[] getSolidTable(int detail) {
    float[] t = new float[detail];
    Arrays.fill(t, 1.0f);
    return t;
  }

  /** Gets an alpha color table component based on the given exponent. */
  public static float[] getAlphaTable(double pow, int detail) {
    float[] t = new float[detail];
    for (int i=0; i<detail; i++) {
      double inc = (double) i / (detail - 1);
      t[i] = (float) Math.pow(inc, pow);
    }
    return t;
  }

}
