//
// ColorPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.*;
import java.awt.event.*;
import java.rmi.RemoteException;
import java.util.Arrays;

import javax.swing.*;
import javax.swing.event.*;

import loci.visbio.*;
import loci.visbio.util.*;

import visad.*;
import visad.bom.ImageRendererJ3D;
import visad.browser.*;
import visad.java2d.DisplayImplJ2D;
import visad.java3d.*;
import visad.util.*;

/** ColorPane is a dialog pane for adjusting color settings. */
public class ColorPane extends DialogPane
  implements DocumentListener, ItemListener
{

  // -- GUI components --

  /** GUI panel for color table widget. */
  private JPanel widgetPane;

  /** Color preview display. */
  private DisplayImpl previewDisplay;

  /** Label for brightness. */
  private JLabel brightnessLabel;

  /** Slider for level of brightness. */
  private JSlider brightness;

  /** Label for current brightness value. */
  private JLabel brightnessValue;

  /** Label for contrast. */
  private JLabel contrastLabel;

  /** Slider for level of contrast. */
  private JSlider contrast;

  /** Label for current contrast value. */
  private JLabel contrastValue;

  /** Option for RGB color model. */
  private JRadioButton rgb;

  /** Option for HSV color model. */
  private JRadioButton hsv;

  /** Option for composite coloring. */
  private JRadioButton composite;

  /** Red/hue color map widget. */
  private BioColorWidget red;

  /** Green/saturation color map widget. */
  private BioColorWidget green;

  /** Blue/value color map widget. */
  private BioColorWidget blue;

  /** Combo box for choosing color widgets. */
  private JComboBox selector;

  /** Option for fixed color scaling. */
  private JCheckBox fixed;

  /** Text field for low color scale value. */
  private JTextField loVal;

  /** Label for fixed color scale. */
  private JLabel toLabel;

  /** Text field for high color scale value. */
  private JTextField hiVal;

  /** Panel containing buttons for LUT saving and loading. */
  private JPanel lutPanel;

  /** Button for loading color look-up table. */
  private JButton lutLoad;

  /** Button for saving color look-up table. */
  private JButton lutSave;


  // -- Other fields --

  /** Color manager for this color pane. */
  private ColorManager cm;

  /** List of mappings from range components to RGB. */
  private ScalarMap[] maps;

  /** Should changes to the color components be ignored? */
  private boolean ignore = false;


  // -- Constructor --

  /** Constructs a control panel for adjusting viewing parameters. */
  public ColorPane(ColorManager manager) {
    super("Edit colors", BoxLayout.X_AXIS);
    this.cm = manager;
    final VisBio bio = cm.getVisBio();

    // left-hand panel
    JPanel left = new JPanel();
    left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
    pane.add(left);

    // divider between left- and right-hand panels
    pane.add(Box.createHorizontalStrut(10));
    pane.add(new Divider(Divider.VERTICAL));
    pane.add(Box.createHorizontalStrut(10));

    // right-hand panel
    JPanel right = new JPanel();
    right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
    pane.add(right);

    // preview label
    JLabel previewLabel = BioUtil.makeLabel("Preview:");
    left.add(BioUtil.pad(previewLabel));

    // preview display
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    try {
      previewDisplay = vm.canDo3D() ? (DisplayImpl)
        new DisplayImplJ3D("bio_color_preview", new TwoDDisplayRendererJ3D()) :
        new DisplayImplJ2D("bio_color_preview");
      ViewManager.doDisplay(previewDisplay);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
    left.add(previewDisplay.getComponent());

    // spacing
    left.add(Box.createVerticalStrut(5));

    // brightness label
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    brightnessLabel = BioUtil.makeLabel("Brightness: ");
    brightnessLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    brightnessLabel.setDisplayedMnemonic('b');
    String brightnessToolTip = "Adjusts the brightness of the displays";
    brightnessLabel.setToolTipText(brightnessToolTip);
    p.add(brightnessLabel);

    // brightness slider
    brightness = new JSlider(0, ColorManager.COLOR_DETAIL,
      ColorManager.NORMAL_BRIGHTNESS);
    brightness.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) { doColorTable(); }
    });
    brightness.setAlignmentY(JSlider.TOP_ALIGNMENT);
    brightnessLabel.setLabelFor(brightness);
    brightness.setToolTipText(brightnessToolTip);
    p.add(brightness);

    // current brightness value
    brightnessValue = BioUtil.makeLabel("" + ColorManager.NORMAL_BRIGHTNESS);
    Dimension labelSize =
      BioUtil.makeLabel("." + ColorManager.COLOR_DETAIL).getPreferredSize();
    brightnessValue.setPreferredSize(labelSize);
    brightnessValue.setAlignmentY(JLabel.TOP_ALIGNMENT);
    brightnessValue.setToolTipText("Current brightness value");
    p.add(brightnessValue);
    left.add(BioUtil.pad(p));

    // contrast label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    contrastLabel = BioUtil.makeLabel("Contrast: ");
    contrastLabel.setPreferredSize(brightnessLabel.getPreferredSize());
    contrastLabel.setAlignmentY(JLabel.TOP_ALIGNMENT);
    contrastLabel.setDisplayedMnemonic('n');
    String contrastToolTip = "Adjusts the contrast of the displays";
    contrastLabel.setToolTipText(contrastToolTip);
    p.add(contrastLabel);

    // contrast slider
    contrast = new JSlider(0, ColorManager.COLOR_DETAIL,
      ColorManager.NORMAL_CONTRAST);
    contrast.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) { doColorTable(); }
    });
    contrast.setAlignmentY(JSlider.TOP_ALIGNMENT);
    contrast.setMajorTickSpacing(ColorManager.COLOR_DETAIL / 4);
    contrast.setMinorTickSpacing(ColorManager.COLOR_DETAIL / 16);
    contrast.setPaintTicks(true);
    contrastLabel.setLabelFor(contrast);
    contrast.setToolTipText(contrastToolTip);
    p.add(contrast);

    // current contrast value
    contrastValue = BioUtil.makeLabel("" + ColorManager.NORMAL_CONTRAST);
    contrastValue.setPreferredSize(labelSize);
    contrastValue.setAlignmentY(JLabel.TOP_ALIGNMENT);
    contrastValue.setToolTipText("Current contrast value");
    p.add(contrastValue);
    left.add(BioUtil.pad(p));

    // spacing
    left.add(Box.createVerticalStrut(5));

    // color model label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel colorModel = BioUtil.makeLabel("Color model: ");
    p.add(colorModel);

    // RGB color model option
    ButtonGroup group = new ButtonGroup();
    rgb = new JRadioButton("RGB", true);
    rgb.addActionListener(this);
    rgb.setMnemonic('r');
    rgb.setToolTipText("Switches to a Red-Green-Blue color model");
    group.add(rgb);
    p.add(rgb);

    // HSV color model option
    hsv = new JRadioButton("HSV");
    hsv.addActionListener(this);
    hsv.setMnemonic('s');
    hsv.setToolTipText("Switches to a Hue-Saturation-Value color model");
    group.add(hsv);
    p.add(hsv);

    // composite color model option
    composite = new JRadioButton("Composite");
    composite.addActionListener(this);
    composite.setMnemonic('i');
    composite.setToolTipText(
      "Combines range values into a composite RGB color table");
    group.add(composite);
    p.add(composite);
    left.add(BioUtil.pad(p));

    // spacing
    left.add(Box.createVerticalStrut(5));

    // red/hue color map widget
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    red = new BioColorWidget(0);
    red.addItemListener(this);
    red.setMnemonic('e');
    red.setToolTipText("Range mapping to Red/Hue color component");
    p.add(red);

    // green/saturation color map widget
    green = new BioColorWidget(1);
    green.addItemListener(this);
    green.setMnemonic('n');
    green.setToolTipText("Range mapping to Green/Saturation color component");
    p.add(green);

    // blue/value color map widget
    blue = new BioColorWidget(2);
    blue.addItemListener(this);
    blue.setMnemonic('u');
    blue.setToolTipText("Range mapping to Blue/Value color component");
    p.add(blue);
    left.add(BioUtil.pad(p));

    // color widget selector label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel selLabel = BioUtil.makeLabel("Color table: ");
    selLabel.setDisplayedMnemonic('t');
    String selToolTip = "List of color tables for color components";
    selLabel.setToolTipText(selToolTip);
    p.add(selLabel);

    // color widget selector
    //BaseRGBMap.USE_COLOR_CURSORS = true;
    selector = new JComboBox();
    Util.adjustComboBox(selector);
    selector.addActionListener(this);
    selLabel.setLabelFor(selector);
    selector.setToolTipText(selToolTip);
    p.add(selector);
    right.add(BioUtil.pad(p));

    // spacing
    right.add(Box.createVerticalStrut(5));

    // fixed color scaling option
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    fixed = new JCheckBox("Fixed color range: ", true);
    fixed.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        boolean b = fixed.isSelected();
        loVal.setEnabled(b);
        toLabel.setEnabled(b);
        hiVal.setEnabled(b);
        doColorTable();
      }
    });
    fixed.setMnemonic('f');
    fixed.setToolTipText("Fixes color range between the given values");
    p.add(fixed);

    // low color scale value text field
    loVal = BioUtil.makeField(4);
    loVal.setText("0");
    Util.adjustTextField(loVal);
    loVal.getDocument().addDocumentListener(this);
    loVal.setToolTipText("Minimum color range value");
    p.add(loVal);

    // color scale label
    toLabel = BioUtil.makeLabel(" to ");
    p.add(toLabel);

    // high color scale value text field
    hiVal = BioUtil.makeField(4);
    hiVal.setText("255");
    Util.adjustTextField(hiVal);
    hiVal.getDocument().addDocumentListener(this);
    hiVal.setToolTipText("Maximum color range value");
    p.add(hiVal);
    right.add(BioUtil.pad(p));

    // spacing
    right.add(Box.createVerticalStrut(5));

    // color widget pane
    widgetPane = new JPanel();
    widgetPane.setLayout(new BoxLayout(widgetPane, BoxLayout.X_AXIS));
    right.add(widgetPane);

    // LUT buttons
    lutPanel = new JPanel();
    lutPanel.setLayout(new BoxLayout(lutPanel, BoxLayout.X_AXIS));
    right.add(lutPanel);

    // load LUT button
    lutLoad = new JButton("Load LUT...");
    lutLoad.addActionListener(this);
    lutPanel.add(lutLoad);

    // save LUT button
    lutSave = new JButton("Save LUT...");
    lutSave.addActionListener(this);
    lutPanel.add(lutSave);

    // spacing
    right.add(Box.createVerticalGlue());
  }


  // -- New API methods --

  /** Sets the data displayed in the preview display to that given. */
  public void setPreviewData(FlatField ff)
    throws VisADException, RemoteException
  {
    BioUtil.setDisplayDisabled(previewDisplay, true);

    // clear old preview data
    previewDisplay.removeAllReferences();
    previewDisplay.clearMaps();
    widgetPane.removeAll();
    selector.removeAllItems();

    // guess at some default color mappings
    FunctionType ftype = (FunctionType) ff.getType();
    RealTupleType domain = ftype.getDomain();
    RealType[] xy = domain.getRealComponents();
    if (xy.length != 2) throw new VisADException("Invalid preview data");
    RealType rt_x = xy[0];
    RealType rt_y = xy[1];
    guessTypes();

    // create data reference
    DataReferenceImpl ref = new DataReferenceImpl("color_preview_ref");
    ref.setData(ff);

    // add scalar maps and data reference
    previewDisplay.addMap(new ScalarMap(rt_x, Display.XAxis));
    previewDisplay.addMap(new ScalarMap(rt_y, Display.YAxis));
    RealType[] rtypes = cm.getTypes();
    maps = new ScalarMap[rtypes.length];
    for (int i=0; i<rtypes.length; i++) {
      maps[i] = new ScalarMap(rtypes[i], Display.RGB);
      previewDisplay.addMap(maps[i]);
      widgetPane.add(new LabeledColorWidget(new ColorMapWidget(maps[i])));
    }
    for (int i=0; i<rtypes.length; i++) selector.addItem(rtypes[i].getName());
    //previewDisplay.addReferences(new ImageRendererJ3D(), ref);
    previewDisplay.addReference(ref);

    // set aspect ratio
    GriddedSet set = (GriddedSet) ff.getDomainSet();
    float[] lo = set.getLow();
    float[] hi = set.getHi();
    double x = hi[0] - lo[0];
    double y = hi[1] - lo[1];
    double d = x > y ? x : y;
    double xasp = x / d;
    double yasp = y / d;
    ProjectionControl pc = previewDisplay.getProjectionControl();
    if (previewDisplay instanceof DisplayImplJ2D) {
      pc.setAspect(new double[] {xasp, yasp});
    }
    else pc.setAspect(new double[] {xasp, yasp, 1.0});

    BioUtil.setDisplayDisabled(previewDisplay, false);
  }

  /** Guesses reasonable mappings from range RealTypes to color components. */
  public void guessTypes() {
    red.removeItemListener(this);
    green.removeItemListener(this);
    blue.removeItemListener(this);
    RealType[] rtypes = cm.getTypes();
    red.guessType(rtypes);
    green.guessType(rtypes);
    blue.guessType(rtypes);
    red.addItemListener(this);
    green.addItemListener(this);
    blue.addItemListener(this);
  }

  /** Gets current brightness value. */
  public int getBrightness() { return brightness.getValue(); }

  /** Gets current contrast value. */
  public int getContrast() { return contrast.getValue(); }

  /** Gets current color model. */
  public int getModel() {
    return rgb.isSelected() ? ColorManager.RGB_MODEL : (hsv.isSelected() ?
      ColorManager.HSV_MODEL : ColorManager.COMPOSITE_MODEL);
  }

  /** Gets current red RealType. */
  public RealType getRed() { return red.getSelectedItem(); }

  /** Gets current green RealType. */
  public RealType getGreen() { return green.getSelectedItem(); }

  /** Gets current blue RealType. */
  public RealType getBlue() { return blue.getSelectedItem(); }

  /** Gets current color table range minimums. */
  public double[] getLo() {
    double[] lo = new double[maps.length];
    int ndx = selector.getSelectedIndex();
    for (int i=0; i<maps.length; i++) {
      if (i == ndx) {
        try { lo[i] = Double.parseDouble(loVal.getText()); }
        catch (NumberFormatException exc) { lo[i] = maps[i].getRange()[0]; }
      }
      else lo[i] = maps[i].getRange()[0];
    }
    return lo;
  }

  /** Gets current color table range maximums. */
  public double[] getHi() {
    double[] hi = new double[maps.length];
    int ndx = selector.getSelectedIndex();
    for (int i=0; i<maps.length; i++) {
      if (i == ndx) {
        try { hi[i] = Double.parseDouble(hiVal.getText()); }
        catch (NumberFormatException exc) { hi[i] = maps[i].getRange()[1]; }
      }
      else hi[i] = maps[i].getRange()[1];
    }
    return hi;
  }

  /** Gets whether each color table has a fixed color range. */
  public boolean[] getFixed() {
    boolean[] fixed = new boolean[maps.length];
    int ndx = selector.getSelectedIndex();
    for (int i=0; i<maps.length; i++) {
      fixed[i] = i == ndx ? this.fixed.isSelected() : !maps[i].isAutoScale();
    }
    return fixed;
  }

  /** Gets current color table values. */
  public float[][][] getTables() {
    float[][][] tables = new float[maps.length][][];
    for (int i=0; i<maps.length; i++) {
      LabeledColorWidget lcw = (LabeledColorWidget) widgetPane.getComponent(i);
      tables[i] = lcw.getTable();
    }
    return tables;
  }


  // -- DialogPane API methods --

  /** Resets the dialog pane's components to their default states. */
  public void resetComponents() {
    int brightness = cm.getBrightness();
    int contrast = cm.getContrast();
    int model = cm.getModel();
    RealType red = cm.getRed();
    RealType green = cm.getGreen();
    RealType blue = cm.getBlue();
    double[] lo = cm.getLo();
    double[] hi = cm.getHi();
    boolean[] fixed = cm.getFixed();

    ignore = true;
    this.brightness.setValue(brightness);
    this.contrast.setValue(contrast);
    if (model == ColorManager.RGB_MODEL) rgb.setSelected(true);
    else if (model == ColorManager.HSV_MODEL) hsv.setSelected(true);
    else if (model == ColorManager.COMPOSITE_MODEL) {
      composite.setSelected(true);
    }
    this.red.setSelectedItem(red);
    this.green.setSelectedItem(green);
    this.blue.setSelectedItem(blue);
    float[][][] tables = cm.getColorTables();
    BioUtil.setDisplayDisabled(previewDisplay, true);
    for (int i=0; i<maps.length; i++) {
      if (fixed[i]) {
        try { maps[i].setRange(lo[i], hi[i]); }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
      BaseColorControl cc = (BaseColorControl) maps[i].getControl();
      if (cc != null) {
        try { cc.setTable(tables[i]); }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
    }
    BioUtil.setDisplayDisabled(previewDisplay, false);
    selector.setSelectedIndex(0);
    ignore = false;
  }


  // -- ActionListener API methods --

  /** Handles GUI events. */
  public void actionPerformed(ActionEvent e) {
    Object o = e.getSource();
    if (o == rgb) {
      red.setModel(ColorManager.RGB_MODEL);
      green.setModel(ColorManager.RGB_MODEL);
      blue.setModel(ColorManager.RGB_MODEL);
      guessTypes();
      doColorTable();
    }
    else if (o == hsv) {
      red.setModel(ColorManager.HSV_MODEL);
      green.setModel(ColorManager.HSV_MODEL);
      blue.setModel(ColorManager.HSV_MODEL);
      guessTypes();
      doColorTable();
    }
    else if (o == composite) {
      red.setModel(ColorManager.COMPOSITE_MODEL);
      green.setModel(ColorManager.COMPOSITE_MODEL);
      blue.setModel(ColorManager.COMPOSITE_MODEL);
      guessTypes();
      doColorTable();
    }
    else if (o == selector) {
      int ndx = selector.getSelectedIndex();
      for (int i=0; i<widgetPane.getComponentCount(); i++) {
        widgetPane.getComponent(i).setVisible(i == ndx);
      }
      if (ndx >= 0) {
        ignore = true;
        fixed.setSelected(!maps[ndx].isAutoScale());
        double[] range = maps[ndx].getRange();
        loVal.setText("" + range[0]);
        hiVal.setText("" + range[1]);
        ignore = false;
      }
    }
    else if (o == lutLoad) {
      LabeledColorWidget lcw = (LabeledColorWidget)
        widgetPane.getComponent(selector.getSelectedIndex());
      cm.loadColorTable(lcw, null);
    }
    else if (o == lutSave) {
      LabeledColorWidget lcw = (LabeledColorWidget)
        widgetPane.getComponent(selector.getSelectedIndex());
      cm.saveColorTable(lcw, null);
    }
    super.actionPerformed(e);
  }


  // -- DocumentListener API methods --

  /** Handles text field changes. */
  public void changedUpdate(DocumentEvent e) { doColorTable(); }

  /** Handles text field additions. */
  public void insertUpdate(DocumentEvent e) { doColorTable(); }

  /** Handles text field deletions. */
  public void removeUpdate(DocumentEvent e) { doColorTable(); }


  // -- ItemListener API methods --

  /** ItemListener method for handling color mapping changes. */
  public void itemStateChanged(ItemEvent e) { doColorTable(); }


  // -- Helper methods --

  /** Updates image color table, for brightness and color adjustments. */
  private void doColorTable() {
    if (ignore) return;

    int bright = getBrightness();
    int cont = getContrast();
    int model = getModel();
    RealType red = getRed();
    RealType green = getGreen();
    RealType blue = getBlue();
    double[] lo = getLo();
    double[] hi = getHi();
    boolean[] fixed = getFixed();

    brightnessValue.setText("" + bright);
    contrastValue.setText("" + cont);

    BioUtil.setDisplayDisabled(previewDisplay, true);
    float[][][] tables = cm.computeColorTables(previewDisplay, bright, cont,
      model, red, green, blue);
    cm.setColorTables(previewDisplay, tables, model, lo, hi, fixed);
    BioUtil.setDisplayDisabled(previewDisplay, false);
  }

}
