//
// CaptureManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.view;

import java.awt.image.BufferedImage;
import java.io.*;
import java.rmi.RemoteException;
import java.util.Vector;

import javax.swing.*;

import loci.visbio.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.SaveException;
import loci.visbio.util.BioUtil;

import visad.*;
import visad.data.avi.AVIForm;
import visad.util.*;

/**
 * CaptureManager is the class encapsulating VisBio's display recording logic.
 */
public class CaptureManager extends LogicManager {

  // -- Dialogs --

  /** File chooser for captured movies. */
  private JFileChooser captureBox;


  // -- Control panel --

  /** Capture control panel. */
  private CapturePanel capturePanel;


  // -- Constructor --

  /** Constructs a capture manager. */
  public CaptureManager(VisBio biovis) { super(biovis); }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 2; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    // CTR TODO
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    // CTR TODO
  }


  // -- New API methods --

  /** Creates an AVI movie of the given transformation sequence. */
  public void captureMovie(Vector positions, double secPerTrans,
    int framesPerSec, boolean sine)
  {
    final int size = positions.size();
    if (size < 1) {
      JOptionPane.showMessageDialog(bio, "Must have at least two display " +
        "positions on the list.", "Cannot record movie",
        JOptionPane.ERROR_MESSAGE);
      return;
    }

    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    if (vm == null) {
      JOptionPane.showMessageDialog(bio, "View manager not found.",
        "Cannot record movie", JOptionPane.ERROR_MESSAGE);
      return;
    }
    final DisplayImpl d = vm.getDisplay3D();
    if (d == null) {
      JOptionPane.showMessageDialog(bio, "3-D display not found.",
        "Cannot record movie", JOptionPane.ERROR_MESSAGE);
      return;
    }
    final ProjectionControl pc = d.getProjectionControl();

    final AVIForm saver = new AVIForm();
    saver.setFrameRate(framesPerSec);

    final int framesPerTrans = (int) (framesPerSec * secPerTrans);
    final int total = (size - 1) * framesPerTrans + 1;

    // get output filename from the user
    int rval = captureBox.showSaveDialog(bio);
    if (rval != JFileChooser.APPROVE_OPTION) return;
    String file = captureBox.getSelectedFile().getPath();
    if (file.indexOf(".") < 0) file = file + ".avi";

    // capture image sequence in a separate thread
    final String filename = file;
    final Vector pos = positions;
    final int frm = framesPerTrans;
    final boolean doSine = sine;
    Thread t = new Thread(new Runnable() {
      public void run() {
        BioUtil.setWaitCursor(bio, true);

        // step incremental from position to position, grabbing images
        double[] mx_start = (double[]) pos.elementAt(0);
        FlatField[] ff = new FlatField[total];
        int count = 0;
        for (int i=1; i<size; i++) {
          double[] mx_end = (double[]) pos.elementAt(i);
          double[] mx = new double[mx_start.length];
          for (int j=0; j<frm; j++) {
            double p = (double) j / frm;
            if (doSine) p = sine(p);
            for (int k=0; k<mx.length; k++) {
              mx[k] = p * (mx_end[k] - mx_start[k]) + mx_start[k];
            }
            ff[count++] = captureImage(pc, mx, d, 100 * count / total);
          }
          mx_start = mx_end;
        }

        // cap off last frame
        ff[count] = captureImage(pc, mx_start, d, 100);

        try {
          // compile frames into a single data object
          RealType index = RealType.getRealType("index");
          FunctionType ftype = new FunctionType(index, ff[0].getType());
          Integer1DSet fset = new Integer1DSet(total);
          FieldImpl field = new FieldImpl(ftype, fset);
          field.setSamples(ff, false);

          // write data out to AVI file
          saver.save(filename, field, true);
        }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
        catch (IOException exc) { exc.printStackTrace(); }

        Util.invoke(false, new Runnable() {
          public void run() { capturePanel.setProgress(0); }
        });

        // clean up
        ff = null;
        SystemManager.gc();

        BioUtil.setWaitCursor(bio, false);
      }
    });
    t.start();
  }

  // -- Helper methods --

  /** Adds view-related GUI components to VisBio. */
  private void doGUI() {
    // snapshot file chooser
    bio.setStatus("Initializing capture logic");
    captureBox = new JFileChooser();
    captureBox.addChoosableFileFilter(new ExtensionFileFilter(
      new String[] {"avi"}, "AVI movies"));

    // control panel
    bio.setStatus(null);
    capturePanel = new CapturePanel(this);
    PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
    if (pm != null) pm.addPanel(capturePanel);

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("Capture", "capture.html");
  }

  /**
   * Takes a snapshot of the given display
   * with the specified projection matrix.
   */
  private FlatField captureImage(ProjectionControl pc,
    double[] mx, DisplayImpl d, int percent)
  {
    FlatField ff = null;
    try {
      pc.setMatrix(mx);

      // lame, stupid hack...
      try { Thread.sleep(100); }
      catch (InterruptedException exc) { exc.printStackTrace(); }

      ff = DataUtility.makeField(d.getImage(false));
      final int value = percent;
      Util.invoke(false, new Runnable() {
        public void run() { capturePanel.setProgress(value); }
      });
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
    catch (IOException exc) { exc.printStackTrace(); }
    return ff;
  }


  // -- Utility methods --

  /** Evaluates a smooth sine function at the given value. */
  public static double sine(double x) {
    // [0, 1] -> [-pi/2, pi/2] -> [0, 1]
    return (Math.sin(Math.PI * (x - 0.5)) + 1) / 2;
  }

}
