//
// ScreenDataPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;

import loci.visbio.state.BioTask;
import loci.visbio.util.*;

import visad.VisADException;

/** ScreenDataPane provides an interface for creating a new screen dataset. */
public class ScreenDataPane extends DialogPane {

  // -- GUI components --

  /** Name of screen dataset. */
  private JTextField nameField;

  /** Resolution of screen dataset's current image. */
  private JTextField imageX, imageY;

  /** Resolution of screen dataset's current image stack. */
  private JTextField stackX, stackY;

  /** Resolution of screen dataset thumbnails. */
  private JTextField thumbX, thumbY;

  /** Whether screen dataset has thumbnails. */
  private JCheckBox thumbs;

  /** Dimensional subsampling parameters for screen dataset. */
  private JTextField[] dimLo, dimHi, dimStep;

  /** Which range components are present within the screen dataset. */
  private JCheckBox[] rangeBoxes;

  /** Which axis to use for Z-axis. */
  private JComboBox stackAxisBox;


  // -- Other fields --

  /** Associated data manager. */
  private DataManager dm;

  /** Raw dataset from which screen dataset will be created. */
  private RawData raw;

  /** Resolution of the raw dataset's images. */
  private int res_x, res_y;

  /** Number of samples across each dimension of the raw dataset. */
  private int[] lengths;

  /** Type of each dimension of the raw dataset. */
  private int[] dims;

  /** Number of dimensions in raw dataset multidimensional image structure. */
  private int numDim;

  /** Number of range components in raw dataset. */
  private int numRange;

  /** Dataset to use for dialog's initial values. */
  private ScreenData initialData;

  /** Name to use when dialog initially appears. */
  private String initialName;


  // -- Constructor --

  /** Creates a new measurement group pane. */
  public ScreenDataPane(DataManager dm, RawData raw) {
    super("Create screen dataset");
    this.dm = dm;
    this.raw = raw;

    // determine raw data parameters
    res_x = raw.getImageWidth();
    res_y = raw.getImageHeight();
    lengths = raw.getLengths();
    dims = raw.getDimTypes();
    numDim = lengths.length;
    numRange = raw.getRangeCount();

    // create name field
    JLabel nameLabel = BioUtil.makeLabel("Name: ");
    nameField = new JTextField(10);
    nameLabel.setDisplayedMnemonic('n');
    nameLabel.setLabelFor(nameField);

    // create image resolution fields
    JLabel imageLabel = BioUtil.makeLabel("Current image: ");
    imageX = BioUtil.makeField(4);
    imageY = BioUtil.makeField(4);
    imageLabel.setDisplayedMnemonic('i');
    imageLabel.setLabelFor(imageX);

    // create stack resolution fields
    JLabel stackLabel = BioUtil.makeLabel("Current stack: ");
    stackX = BioUtil.makeField(4);
    stackY = BioUtil.makeField(4);
    stackLabel.setDisplayedMnemonic('s');
    stackLabel.setLabelFor(stackX);

    // create thumbnail resolution fields
    thumbX = BioUtil.makeField(4);
    thumbY = BioUtil.makeField(4);

    // create dimensional range fields
    JLabel[] dimLabel = new JLabel[numDim];
    dimLo = new JTextField[numDim];
    dimHi = new JTextField[numDim];
    dimStep = new JTextField[numDim];
    String[] dimStr = raw.getDimStrings();
    for (int i=0; i<numDim; i++) {
      String s = "" + (i + 1);
      dimLabel[i] = BioUtil.makeLabel("<" + s + "> " + dimStr[i] + ": ");
      dimLo[i] = BioUtil.makeField(4);
      dimHi[i] = BioUtil.makeField(4);
      dimStep[i] = BioUtil.makeField(4);
      //if (i < 9) dimLabel[i].setDisplayedMnemonic(s.charAt(0));
      dimLabel[i].setLabelFor(dimLo[i]);
    }

    // create thumbnail checkbox
    thumbs = new JCheckBox("Thumbnails: ", true);
    thumbs.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        boolean b = thumbs.isSelected();
        thumbX.setEnabled(b);
        thumbY.setEnabled(b);
      }
    });
    thumbs.setMnemonic('t');

    // create range component checkboxes
    JLabel rangeLabel = BioUtil.makeLabel("Range components: ");
    rangeBoxes = new JCheckBox[numRange];
    for (int i=0; i<numRange; i++) {
      String s = "" + (i + 1);
      rangeBoxes[i] = new JCheckBox(s, true);
      if (i < 9) rangeBoxes[i].setMnemonic(s.charAt(0));
    }

    // create stack axis combo box
    JLabel stackAxisLabel = BioUtil.makeLabel("Z-stack using: ");
    stackAxisBox = new JComboBox(new String[] {"None"});
    stackAxisLabel.setDisplayedMnemonic('z');
    stackAxisLabel.setLabelFor(stackAxisBox);

    // populate stack axis combo box
    for (int i=0; i<numDim; i++) {
      stackAxisBox.addItem("<" + (i + 1) + "> " + dimStr[i]);
    }

    // lay out screen dataset name components
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(nameLabel);
    p.add(nameField);
    pane.add(p);

    // lay out current image resolution components
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(imageLabel);
    p.add(imageX);
    p.add(BioUtil.makeLabel(" by "));
    p.add(imageY);
    pane.add(p);

    // lay out image stack resolution components
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(stackLabel);
    p.add(stackX);
    p.add(BioUtil.makeLabel(" by "));
    p.add(stackY);
    pane.add(p);

    // lay out thumbnail resolution components
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(thumbs);
    p.add(thumbX);
    p.add(BioUtil.makeLabel(" by "));
    p.add(thumbY);
    pane.add(p);

    // lay out dimensional axis components
    for (int i=0; i<numDim; i++) {
      p = new JPanel();
      p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
      int ndx = dims[i];
      p.add(dimLabel[i]);
      p.add(dimLo[i]);
      p.add(BioUtil.makeLabel(" to "));
      p.add(dimHi[i]);
      p.add(BioUtil.makeLabel(" step "));
      p.add(dimStep[i]);
      pane.add(p);
    }

    // lay out range components
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(rangeLabel);
    for (int i=0; i<numRange; i++) {
      p.add(rangeBoxes[i]);
      p.add(Box.createHorizontalStrut(10));
    }
    pane.add(p);

    // lay out stack axis components
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    p.add(stackAxisLabel);
    p.add(stackAxisBox);
    pane.add(p);
  }


  // -- New API methods --

  /** Sets the dialog to use the given dataset for its initial values. */
  public void setInitialData(ScreenData screen) { initialData = screen; }

  /** Sets the dialog to use the given name when it first appears. */
  public void setInitialName(String name) { initialName = name; }

  /** Constructs a screen dataset based on this dialog's inputs. */
  public ScreenData getScreenData() { return getScreenData(null, dialog); }

  /** Modifies the given screen dataset to match this dialog's inputs. */
  public ScreenData getScreenData(ScreenData screen) {
    return getScreenData(screen, dialog);
  }

  /** Constructs a screen dataset based on dialog defaults. */
  public ScreenData getScreenData(Window w) { return getScreenData(null, w); }

  /** Gets the number of pixels per 3-D image stack. */
  public long getImageStackSize() {
    int stack_x = Integer.parseInt(stackX.getText());
    int stack_y = Integer.parseInt(stackY.getText());
    int thumb_x = Integer.parseInt(thumbX.getText());
    int thumb_y = Integer.parseInt(thumbY.getText());
    int res_x = stack_x > thumb_x ? stack_x : thumb_x;
    int res_y = stack_y > thumb_y ? stack_y : thumb_y;
    int num_slices = getNumberOfSlices();
    int num_range = getNumberOfRangeComponents();
    return (long) res_x * res_y * num_slices * num_range;
  }

  /** Gets the number of pixels' worth of thumbnail data. */
  public long getThumbnailSize() {
    int thumb_x = Integer.parseInt(thumbX.getText());
    int thumb_y = Integer.parseInt(thumbY.getText());
    int num_range = getNumberOfRangeComponents();
    long pix = (long) thumb_x * thumb_y * num_range;
    for (int i=0; i<numDim; i++) {
      int lo = Integer.parseInt(dimLo[i].getText());
      int hi = Integer.parseInt(dimHi[i].getText());
      int step = Integer.parseInt(dimStep[i].getText());
      pix *= (hi - lo) / step + 1;
    }
    return pix;
  }

  /** Gets the number of slices that will be displayed simultaneously. */
  public int getNumberOfSlices() {
    int stackAxis = stackAxisBox.getSelectedIndex() - 1;
    if (stackAxis < 0) return 1;
    int lo = Integer.parseInt(dimLo[stackAxis].getText());
    int hi = Integer.parseInt(dimHi[stackAxis].getText());
    int step = Integer.parseInt(dimStep[stackAxis].getText());
    return (hi - lo) / step + 1;
  }

  /** Gets the number of range components selected. */
  public int getNumberOfRangeComponents() {
    int count = 0;
    for (int i=0; i<numRange; i++) if (rangeBoxes[i].isSelected()) count++;
    return count;
  }


  // -- DialogPane API methods --

  /** Resets the dialog pane's components to their default states. */
  public void resetComponents() {
    if (initialData == null) {
      // guess at some good initial values

      nameField.setText(initialName == null ? "screen" : initialName);
      for (int i=0; i<numRange; i++) rangeBoxes[i].setSelected(true);
      thumbs.setSelected(true);
      thumbX.setEnabled(true);
      thumbY.setEnabled(true);
      imageX.setText("" + res_x);
      imageY.setText("" + res_y);

      // stack axis
      int stackAxis = 0;
      for (int i=0; i<numDim; i++) {
        if (dims[i] == RawData.FOCAL_PLANE) stackAxis = i + 1;
      }
      if (stackAxis == 0 && numDim >= 1) stackAxis = 1;
      stackAxisBox.setSelectedIndex(stackAxis);

      // dimensional ranges
      for (int i=0; i<numDim; i++) {
        dimLo[i].setText("1");
        dimHi[i].setText("" + lengths[i]);
        dimStep[i].setText("1");
      }

      // stack resolution
      int stack_x = res_x;
      int stack_y = res_y;
      int stack_res = dm.getDefaultStackRes();
      if (stack_x > stack_res || stack_y > stack_res) {
        // scale down image stack resolution to match the default
        if (stack_x > stack_y) {
          double ratio = (double) stack_res / stack_x;
          stack_x = stack_res;
          stack_y = (int) (stack_y * ratio);
        }
        else {
          double ratio = (double) stack_res / stack_y;
          stack_x = (int) (stack_x * ratio);
          stack_y = stack_res;
        }
      }
      stackX.setText("" + stack_x);
      stackY.setText("" + stack_y);

      // stack axis step
      if (stackAxis > 0) {
        int axis = stackAxis - 1;
        int num = lengths[axis];
        if (num > stack_res) {
          // choose a step to keep number of slices within the maximum
          int step = (num - 1) / stack_res + 1;
          dimStep[axis].setText("" + step);
        }
      }

      // thumbnail resolution
      int thumb_x = res_x;
      int thumb_y = res_y;
      int thumb_res = dm.getDefaultThumbRes();
      if (thumb_x > thumb_res || thumb_y > thumb_res) {
        // scale down thumbnail resolution to match the default
        if (thumb_x > thumb_y) {
          double ratio = (double) thumb_res / thumb_x;
          thumb_x = thumb_res;
          thumb_y = (int) (thumb_y * ratio);
        }
        else {
          double ratio = (double) thumb_res / thumb_y;
          thumb_x = (int) (thumb_x * ratio);
          thumb_y = thumb_res;
        }
      }
      thumbX.setText("" + thumb_x);
      thumbY.setText("" + thumb_y);
    }
    else {
      // use initial screen dataset object for initial values
      ScreenDescriptor desc = initialData.getDescriptor();
      int thumb_x = desc.thumb_x;
      int thumb_y = desc.thumb_y;

      nameField.setText(desc.name);
      imageX.setText("" + desc.image_x);
      imageY.setText("" + desc.image_y);
      stackX.setText("" + desc.stack_x);
      stackY.setText("" + desc.stack_y);
      thumbX.setText("" + thumb_x);
      thumbY.setText("" + thumb_y);
      int[] lo = desc.min;
      int[] hi = desc.max;
      int[] step = desc.step;
      for (int i=0; i<numDim; i++) {
        dimLo[i].setText("" + lo[i]);
        dimHi[i].setText("" + hi[i]);
        dimStep[i].setText("" + step[i]);
      }
      boolean[] range = desc.range;
      for (int i=0; i<numRange; i++) rangeBoxes[i].setSelected(range[i]);
      stackAxisBox.setSelectedIndex(desc.stackAxis + 1);

      boolean b = thumb_x > 0 && thumb_y > 0;
      thumbs.setSelected(b);
      thumbX.setEnabled(b);
      thumbY.setEnabled(b);
    }
  }

  /** Handles button press events. */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("ok")) {
      // check screen dataset name
      if (nameField.getText().trim().equals("")) {
        JOptionPane.showMessageDialog(this,
          "Screen dataset must have a name.",
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }

      // check current image resolution
      boolean ok = true;
      int image_x = 0, image_y = 0;
      try {
        image_x = Integer.parseInt(imageX.getText());
        image_y = Integer.parseInt(imageY.getText());
        if (image_x <= 0 || image_y <= 0) ok = false;
      }
      catch (NumberFormatException exc) { ok = false; }
      if (!ok) {
        JOptionPane.showMessageDialog(this,
          "Invalid resolution for current image",
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (image_x > res_x || image_y > res_y) {
        int rval = JOptionPane.showConfirmDialog(this,
          "Current image resolution exceeds raw data resolution. Is this ok?",
          "VisBio", JOptionPane.YES_NO_OPTION);
        if (rval != JOptionPane.YES_OPTION) return;
      }

      // check current stack resolution
      ok = true;
      int stack_x = 0, stack_y = 0;
      try {
        stack_x = Integer.parseInt(stackX.getText());
        stack_y = Integer.parseInt(stackY.getText());
        if (stack_x <= 0 || stack_y <= 0) ok = false;
      }
      catch (NumberFormatException exc) { ok = false; }
      if (!ok) {
        JOptionPane.showMessageDialog(this,
          "Invalid resolution for current stack",
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (stack_x > res_x || stack_y > res_y) {
        int rval = JOptionPane.showConfirmDialog(this,
          "Current stack resolution exceeds raw data resolution. Is this ok?",
          "VisBio", JOptionPane.YES_NO_OPTION);
        if (rval != JOptionPane.YES_OPTION) return;
      }

      // check thumbnail resolution
      if (thumbs.isSelected()) {
        ok = true;
        int thumb_x = 0, thumb_y = 0;
        try {
          thumb_x = Integer.parseInt(thumbX.getText());
          thumb_y = Integer.parseInt(thumbY.getText());
          if (thumb_x <= 0 || thumb_y <= 0) ok = false;
        }
        catch (NumberFormatException exc) { ok = false; }
        if (!ok) {
          JOptionPane.showMessageDialog(this,
            "Invalid resolution for thumbnails",
            "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }
        if (thumb_x > res_x || thumb_y > res_x) {
          int rval = JOptionPane.showConfirmDialog(this, "Current thumbnail " +
            "resolution exceeds raw data resolution. Is this ok?",
            "VisBio", JOptionPane.YES_NO_OPTION);
          if (rval != JOptionPane.YES_OPTION) return;
        }
      }

      // check dimensional sampling values
      for (int i=0; i<numDim; i++) {
        ok = true;
        int lo = 0, hi = 0, step = 0;
        try {
          lo = Integer.parseInt(dimLo[i].getText());
          hi = Integer.parseInt(dimHi[i].getText());
          step = Integer.parseInt(dimStep[i].getText());
          if (lo < 1 || hi > lengths[i] || lo > hi || step < 1) ok = false;
        }
        catch (NumberFormatException exc) { ok = false; }
        if (!ok) {
          JOptionPane.showMessageDialog(this,
            "Dimension #" + (i + 1) + " has invalid sampling parameters.",
            "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }
      }

      // check range components
      ok = false;
      for (int i=0; i<numRange; i++) {
        if (rangeBoxes[i].isSelected()) {
          ok = true;
          break;
        }
      }
      if (!ok) {
        JOptionPane.showMessageDialog(this,
          "Must select at least one range component to include.",
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }

      // check for dataset warnings
      boolean success = dm.checkDataset(this);
      if (!success) return;
    }
    super.actionPerformed(e);
  }


  // -- Helper methods --

  /** Constructs or modifies a screen dataset. */
  private ScreenData getScreenData(ScreenData screen, Window w) {
    // construct sampling arrays
    int[] lo = new int[numDim];
    int[] hi = new int[numDim];
    int[] step = new int[numDim];
    for (int i=0; i<numDim; i++) {
      lo[i] = Integer.parseInt(dimLo[i].getText());
      hi[i] = Integer.parseInt(dimHi[i].getText());
      step[i] = Integer.parseInt(dimStep[i].getText());
    }

    String name = nameField.getText();
    int image_x = Integer.parseInt(imageX.getText());
    int image_y = Integer.parseInt(imageY.getText());
    int stack_x = Integer.parseInt(stackX.getText());
    int stack_y = Integer.parseInt(stackY.getText());
    boolean hasThumbs = thumbs.isSelected();
    int thumb_x = hasThumbs ? Integer.parseInt(thumbX.getText()) : 0;
    int thumb_y = hasThumbs ? Integer.parseInt(thumbY.getText()) : 0;

    boolean[] range = new boolean[numRange];
    for (int i=0; i<numRange; i++) range[i] = rangeBoxes[i].isSelected();

    int stackAxis = stackAxisBox.getSelectedIndex() - 1;

    final ScreenDescriptor desc = new ScreenDescriptor(raw, name,
      lo, hi, step, image_x, image_y, stack_x, stack_y, thumb_x, thumb_y,
      range, stackAxis);
    if (screen == null) screen = dm.makeScreenData();
    final ScreenData fscreen = screen;
    Thread t = new Thread(new Runnable() {
      public void run() { fscreen.setSampling(desc); }
    });
    t.start();
    if (w != null) {
      BioTask task = screen.getTask();
      if (w instanceof Dialog) task.showProgressDialog((Dialog) w);
      else if (w instanceof Frame) task.showProgressDialog((Frame) w);
    }
    return screen;
  }

}
