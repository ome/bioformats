//
// DataPanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;

import loci.visbio.*;
import loci.visbio.util.*;

import visad.browser.Divider;
import visad.util.Util;

/**
 * DataPanel is the control panel for adjusting data parameters, such as
 * image resolution and dimensional mappings, as well as reporting important
 * information about the current dataset, memory usage information, etc.
 */
public class DataPanel extends ControlPanel {

  // -- Constants --

  /** Description for each type of dimension. */
  private static final String[] DIM_TYPES = {
    "time point", "focal plane", "spectral channel",
    "lifetime bin", "polarization state"
  };

  /** Data information message when no data is loaded. */
  private static final String NO_DATA_LOADED =
    "<html><body><center>\n" +
    "No dataset is currently loaded.\n" +
    "</center></body></html>\n";

  /** Data information message when no data is loaded. */
  private static final String NO_SCREEN_DATA =
    "<html><body><center>\n" +
    "No screen dataset selected.\n" +
    "</center></body></html>\n";


  // -- GUI components --

  /** Screen dataset creation dialog. */
  private ScreenDataPane screenDataPane;

  /** Button for importing a dataset. */
  private JButton importData;

  /** Button for exporting a dataset. */
  private JButton exportData;

  /** Raw dataset information display panel. */
  private JEditorPane rawDataInfo;

  /** Active screen dataset selector. */
  private JComboBox screenDataBox;

  /** Button for editing selected screen dataset. */
  private JButton editScreenDataset;

  /** Button for deleting selected screen dataset. */
  private JButton purgeScreenDataset;

  /** Screen dataset information display panel. */
  private JEditorPane screenDataInfo;


  // -- Constructor --

  /** Constructs a tool panel for adjusting data parameters. */
  public DataPanel(LogicManager logic) {
    super(logic, "Data", "Controls for managing the current dataset");
    final DataManager dm = (DataManager) lm;
    final VisBio bio = lm.getVisBio();

    // raw dataset information label
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel rawDataLabel = BioUtil.makeLabel("Raw dataset: ");
    p.add(rawDataLabel);

    // import data button
    importData = new JButton("Import data");
    importData.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { dm.fileOpenGroup(); }
    });
    importData.setMnemonic('i');
    BioUtil.setTip(bio, importData, "Imports a dataset into VisBio");
    p.add(importData);

    // export data button
    exportData = new JButton("Export data");
    exportData.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { dm.fileExport(); }
    });
    exportData.setMnemonic('x');
    BioUtil.setTip(bio, exportData, "Exports a dataset from VisBio");
    p.add(exportData);
    controls.add(BioUtil.pad(p));

    // spacing
    controls.add(Box.createVerticalStrut(10));

    // raw dataset information display panel
    rawDataInfo = new JEditorPane();
    rawDataInfo.setEditable(false);
    rawDataInfo.setContentType("text/html");
    BioUtil.setTip(bio, rawDataInfo,
      "Reports information about the loaded raw dataset");
    JScrollPane scroll = new JScrollPane(rawDataInfo) {
      public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(d.width, 200);
      }
    };
    controls.add(scroll);
    updateRawData();

    // divider between raw dataset functions and screen dataset functions
    controls.add(Box.createVerticalStrut(10));
    controls.add(new Divider());
    controls.add(Box.createVerticalStrut(10));

    // selected screen dataset label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel screenDataLabel = BioUtil.makeLabel("Screen dataset: ");
    screenDataLabel.setDisplayedMnemonic('s');
    String screenDataTip = "Changes the selected screen dataset";
    BioUtil.setTip(bio, screenDataLabel, screenDataTip);
    p.add(screenDataLabel);

    // selected screen dataset combo box
    screenDataBox = new JComboBox(new Object[] {"None"});
    screenDataBox.setEditable(false);
    screenDataLabel.setLabelFor(screenDataBox);
    BioUtil.setTip(bio, screenDataBox, screenDataTip);
    screenDataBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { updateScreenData(); }
    });
    p.add(screenDataBox);
    controls.add(BioUtil.pad(p));

    // vertical spacing
    controls.add(Box.createVerticalStrut(2));

    // new screen dataset button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JButton newScreenDataset = new JButton("New");
    newScreenDataset.setMnemonic('n');
    BioUtil.setTip(bio, newScreenDataset, "Creates a new screen dataset");
    newScreenDataset.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { makeScreenData(true); }
    });
    p.add(newScreenDataset);

    // edit screen dataset button
    editScreenDataset = new JButton("Edit");
    editScreenDataset.setMnemonic('e');
    BioUtil.setTip(bio, editScreenDataset,
      "Edits the selected screen dataset");
    editScreenDataset.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (screenDataPane == null) return;
        ScreenData data = (ScreenData) screenDataBox.getSelectedItem();
        screenDataPane.setInitialData(data);
        int rval = screenDataPane.showDialog(bio);
        if (rval != DialogPane.APPROVE_OPTION) return;
        screenDataPane.getScreenData(data);
        updateScreenData();
        bio.generateEvent(dm, "edit screen dataset", true);
      }
    });
    p.add(editScreenDataset);

    // purge screen dataset button
    purgeScreenDataset = new JButton("Purge");
    purgeScreenDataset.setMnemonic('p');
    BioUtil.setTip(bio, purgeScreenDataset,
      "Deletes the selected screen dataset");
    purgeScreenDataset.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        int rval = JOptionPane.showConfirmDialog(bio,
          "Are you sure you wish to delete the selected screen dataset?",
          "VisBio", JOptionPane.YES_NO_OPTION);
        if (rval != JOptionPane.YES_OPTION) return;
        int ndx = screenDataBox.getSelectedIndex();
        screenDataBox.removeItemAt(ndx);
        SystemManager.gc();
        bio.generateEvent(dm, "purge screen dataset", true);
      }
    });
    p.add(purgeScreenDataset);

    // display screen dataset button
    JButton displayScreenDataset = new JButton("Display");
    displayScreenDataset.setMnemonic('d');
    BioUtil.setTip(bio, displayScreenDataset,
      "Visualizes the selected screen dataset");
    displayScreenDataset.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        DataManager dm = (DataManager) lm;
        dm.setScreenData(getSelectedScreenDataset());
      }
    });
    p.add(displayScreenDataset);
    controls.add(BioUtil.pad(p));

    // spacing
    controls.add(Box.createVerticalStrut(10));

    // screen dataset information display panel
    screenDataInfo = new JEditorPane();
    screenDataInfo.setEditable(false);
    screenDataInfo.setContentType("text/html");
    BioUtil.setTip(bio, screenDataInfo,
      "Reports information about the selected screen dataset");
    scroll = new JScrollPane(screenDataInfo) {
      public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(d.width, 250);
      }
    };
    controls.add(scroll);
    updateScreenData();
  }


  // -- API methods --

  /** Gets the currently selected screen dataset. */
  public ScreenData getSelectedScreenDataset() {
    Object o = screenDataBox.getSelectedItem();
    return o instanceof ScreenData ? (ScreenData) o : null;
  }

  /** Gets the current list of screen datasets. */
  public Vector getScreenDatasets() {
    Vector v = new Vector();
    int size = screenDataBox.getItemCount();
    for (int i=1; i<size; i++) v.add(screenDataBox.getItemAt(i));
    return v;
  }

  /** Sets the current list of screen datasets. */
  public void setScreenDatasets(Vector v) {
    int ndx = screenDataBox.getSelectedIndex();
    Object none = screenDataBox.getItemAt(0);
    screenDataBox.removeAllItems();
    screenDataBox.addItem(none);
    int size = v.size();
    for (int i=0; i<size; i++) screenDataBox.addItem(v.elementAt(i));
    if (ndx < screenDataBox.getItemCount()) {
      screenDataBox.setSelectedIndex(ndx);
    }
  }

  /** Sets the currently selected screen dataset. */
  public void setSelectedScreenDataset(ScreenData screen) {
    if (screen == null) screenDataBox.setSelectedIndex(0);
    else screenDataBox.setSelectedItem(screen);
  }

  /** Creates a new screen dataset. */
  public void makeScreenData(boolean showDialog) {
    if (screenDataPane == null) return;
    screenDataPane.setInitialData(null);
    screenDataPane.setInitialName("screen" + screenDataBox.getItemCount());
    ScreenData data;
    if (showDialog) {
      int rval = screenDataPane.showDialog(lm.getVisBio());
      if (rval != DialogPane.APPROVE_OPTION) return;
      data = screenDataPane.getScreenData();
    }
    else {
      screenDataPane.resetComponents();
      data = screenDataPane.getScreenData(lm.getVisBio());
    }
    screenDataBox.addItem(data);
    screenDataBox.setSelectedItem(data);
    DataManager dm = (DataManager) lm;
    dm.getVisBio().generateEvent(dm, "create screen dataset", true);
    dm.checkAutoDisplay();
  }

  /** Updates raw dataset information panel. */
  public void updateRawData() {
    DataManager dm = (DataManager) lm;
    RawData raw = dm == null ? null : dm.getRawData();
    if (raw == null) {
      rawDataInfo.setText(NO_DATA_LOADED);
      screenDataPane = null;
      return;
    }
    screenDataPane = new ScreenDataPane(dm, raw);

    String[] ids = raw.getFilenames();
    int[] lengths = raw.getLengths();
    String format = raw.getFileFormat();
    int width = raw.getImageWidth();
    int height = raw.getImageHeight();
    int rangeCount = raw.getRangeCount();
    int[] dims = raw.getDimTypes();
    String[] dimStr = raw.getDimStrings();

    StringBuffer sb = new StringBuffer("<html><body>\n");
    String pattern = raw.getPattern();
    pattern = pattern.replaceAll("<", "&lt;");
    pattern = pattern.replaceAll(">", "&gt;");
    sb.append(pattern);
    sb.append("<p>\n\n");
    sb.append(ids.length + " " + format);
    sb.append(" in dataset.<br>\n");
    sb.append(dims.length > 0 ? "Each i" : "I");
    sb.append("mage is " + width + " x " + height + " pixel");
    if (width * height != 1) sb.append("s");
    sb.append(".<br>\n");
    sb.append(dims.length > 0 ? "Each i" : "I");
    sb.append("mage has " + rangeCount + " range component");
    if (rangeCount != 1) sb.append("s");
    sb.append(".<p>\n");
    if (dims.length > 0) {
      sb.append("Dataset has " + dims.length + " dimensional ax");
      sb.append(dims.length == 1 ? "is" : "es");
      sb.append(":<ul>\n");
      for (int i=0; i<dims.length; i++) {
        sb.append("<li>&lt;" + (i + 1) + "&gt; " + dimStr[i] + ": " +
          lengths[i] + " " + (dims[i] < 0 ? "sample" : DIM_TYPES[dims[i]]));
        if (lengths[i] != 1) sb.append("s");
        sb.append("\n");
      }
      sb.append("</ul>\n");
    }
    sb.append("</body></html>\n");
    rawDataInfo.setText(sb.toString());
  }

  /** Updates screen dataset information panel. */
  public void updateScreenData() {
    ScreenData data = getSelectedScreenDataset();
    boolean isScreen = data != null;
    editScreenDataset.setEnabled(isScreen);
    purgeScreenDataset.setEnabled(isScreen);

    if (isScreen) {
      ScreenDescriptor desc = data.getDescriptor();
      int[] min = desc.min;
      int[] max = desc.max;
      int[] step = desc.step;
      int[] len = data.getLengths();
      int image_x = desc.image_x;
      int image_y = desc.image_y;
      int stack_x = desc.stack_x;
      int stack_y = desc.stack_y;
      int thumb_x = desc.thumb_x;
      int thumb_y = desc.thumb_y;
      boolean[] range = desc.range;
      int stackAxis = desc.stackAxis;
      long mem = data.getMemoryUse();
      long leftover = (mem % 1048576) / 10486;
      String smem = (mem >> 20) + ".";
      if (leftover < 10) smem = smem + "0";
      smem = smem + leftover;

      DataManager dm = (DataManager) lm;
      RawData raw = dm.getRawData();
      String[] dimStr = raw.getDimStrings();

      StringBuffer sb = new StringBuffer("<html><body>\n");
      if (min.length > 0) {
        sb.append("Dimensional sampling ranges:<ul>\n");
        for (int i=0; i<min.length; i++) {
          sb.append("<li>&lt;" + (i + 1) + "&gt; " + dimStr[i] + ": " +
            min[i] + " to " + max[i]);
          if (step[i] != 1) {
            sb.append(" step ");
            sb.append("" + step[i]);
          }
          sb.append(" (" + len[i] + " total)\n");
        }
        sb.append("</ul>\n");
      }

      sb.append("Included range components");
      boolean first = true;
      for (int i=0; i<range.length; i++) {
        if (!range[i]) continue;
        sb.append((first ? ": " : ", ") + (i + 1));
        first = false;
      }
      sb.append("<br>\n");

      sb.append("Z-axis mapping: ");
      if (stackAxis < 0) sb.append("None");
      else sb.append("&lt;" + (stackAxis + 1) + "&gt; " + dimStr[stackAxis]);
      sb.append("<p>\n");

      sb.append("Current image is " + image_x + " x " + image_y + " pixel");
      if (image_x * image_y != 1) sb.append("s");
      sb.append(".<br>\n");

      if (stackAxis < 0) sb.append("No current stack");
      else {
        sb.append("Current stack is " + stack_x + " x " + stack_y + " pixel");
        if (stack_x * stack_y != 1) sb.append("s");
      }
      sb.append(".<br>\n");

      if (thumb_x == 0 || thumb_y == 0) sb.append("No thumbnails");
      else {
        sb.append("Thumbnails are " + thumb_x + " x " + thumb_y + " pixel");
        if (thumb_x * thumb_y != 1) sb.append("s");
      }
      sb.append(".<br>\n");

      sb.append("Dataset is approximately " + smem + " MB in size.\n");

      sb.append("</body></html>\n");
      screenDataInfo.setText(sb.toString());
    }
    else screenDataInfo.setText(NO_SCREEN_DATA);
  }

}
