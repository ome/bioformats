//
// ScreenDescriptor.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.io.*;

import loci.visbio.*;
import loci.visbio.state.*;
import loci.visbio.util.BioUtil;

import visad.VisADException;

/** Describes a particular sampling of a screen dataset. */
public class ScreenDescriptor implements Saveable {

  // -- Fields --

  /** Associated raw data object, from which data is extracted. */
  public RawData raw;

  /** Name of this screen dataset. */
  public String name;

  /** Minimum index value for each dimension. */
  public int[] min;

  /** Maximum index value for each dimension. */
  public int[] max;

  /** Index step value for each dimension. */
  public int[] step;

  /** Width of current image. */
  public int image_x;

  /** Height of current image. */
  public int image_y;

  /** Width of images in current image stack. */
  public int stack_x;

  /** Height of images in current image stack. */
  public int stack_y;

  /** Width of each thumbnail image. */
  public int thumb_x;

  /** Height of each thumbnail image. */
  public int thumb_y;

  /** List of included range components. */
  public boolean[] range;

  /** Dimensional axis for the image stack. */
  public int stackAxis;


  // -- Constructor --

  /** Constructs an uninitialized screen descriptor. */
  public ScreenDescriptor() { }

  /**
   * Constructs a screen descriptor with the given parameters.
   * @param name Name of the screen dataset.
   * @param min Array listing minimum index value for each dimension.
   * @param max Array listing maximum index value for each dimension.
   * @param step Array listing step interval for each dimension.
   * @param image_x The width of the current image.
   * @param image_y The height of the current image.
   * @param stack_x The width of the current image stack.
   * @param stack_y The height of the current image stack.
   * @param thumb_x The width of all other images in the sampling
   *   (0 for no thumbnails).
   * @param thumb_y The height of all other images in the sampling
   *   (0 for no thumbnails).
   * @param range Array dictating all included range components
   *   for the sampling.
   * @param stackAxis Dimensional axis for to image stack (-1 for none).
   */
  public ScreenDescriptor(RawData raw, String name, int[] min, int[] max,
    int[] step, int image_x, int image_y, int stack_x, int stack_y,
    int thumb_x, int thumb_y, boolean[] range, int stackAxis)
  {
    this.raw = raw;
    this.name = name;
    this.min = min;
    this.max = max;
    this.step = step;
    this.image_x = image_x;
    this.image_y = image_y;
    this.stack_x = stack_x;
    this.stack_y = stack_y;
    this.thumb_x = thumb_x;
    this.thumb_y = thumb_y;
    this.range = range;
    this.stackAxis = stackAxis;
  }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    raw.saveState(fout);
    fout.println(name);
    BioUtil.writeArray(min, fout);
    BioUtil.writeArray(max, fout);
    BioUtil.writeArray(step, fout);
    fout.println(image_x);
    fout.println(image_y);
    fout.println(stack_x);
    fout.println(stack_y);
    fout.println(thumb_x);
    fout.println(thumb_y);
    BioUtil.writeArray(range, fout);
    fout.println(stackAxis);
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    raw = new RawData();
    raw.restoreState(fin);
    try {
      name = fin.readLine();
      min = BioUtil.readArray(min, fin);
      max = BioUtil.readArray(max, fin);
      step = BioUtil.readArray(step, fin);
      image_x = Integer.parseInt(fin.readLine());
      image_y = Integer.parseInt(fin.readLine());
      stack_x = Integer.parseInt(fin.readLine());
      stack_y = Integer.parseInt(fin.readLine());
      thumb_x = Integer.parseInt(fin.readLine());
      thumb_y = Integer.parseInt(fin.readLine());
      range = BioUtil.readArray(range, fin);
      stackAxis = Integer.parseInt(fin.readLine());
    }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- Object API methods --

  /** Gets a string representation of this screen descriptor. */
  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("ScreenDescriptor:");
    sb.append("\n\traw=");
    sb.append(raw);
    sb.append("\n\tname=");
    sb.append(name);
    sb.append("\n\tmin=");
    sb.append(min);
    sb.append("\n\tmax=");
    sb.append(max);
    sb.append("\n\tstep=");
    sb.append(step);
    sb.append("\n\timage_x=");
    sb.append(image_x);
    sb.append("\n\timage_y=");
    sb.append(image_y);
    sb.append("\n\tstack_x=");
    sb.append(stack_x);
    sb.append("\n\tstack_y=");
    sb.append(stack_y);
    sb.append("\n\tthumb_x=");
    sb.append(thumb_x);
    sb.append("\n\tthumb_y=");
    sb.append(thumb_y);
    sb.append("\n\trange=");
    sb.append(range);
    sb.append("\n\tstackAxis=");
    sb.append(stackAxis);
    return sb.toString();
  }

}
