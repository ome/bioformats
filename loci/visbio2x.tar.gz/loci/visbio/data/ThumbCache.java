//
// ThumbCache.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free
Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA
*/

package loci.visbio.data;

import java.io.*;
import java.util.Vector;

import visad.FlatField;

/** Disk cache for thumbnails generated from datasets. */
public class ThumbCache {

  // -- Fields --

  /** Filename of thumbnail index. */
  private File index_file;

  /** Filename of thumbnail cache data. */
  private File data_file;

  /** Index file entries. */
  private Vector index;

  /** Last retrieved thumbnail index. */
  private int last;


  // -- Constructor --

  /** Constructs a thumbnail cache that uses the given index and data files. */
  public ThumbCache(String index_filename, String data_filename) {
    index_file = new File(index_filename);
    data_file = new File(data_filename);
    index = new Vector();
    last = 0;
    try {
      if (!index_file.exists()) index_file.createNewFile();
      BufferedReader fin = new BufferedReader(new FileReader(index_file));
      while (true) {
        ThumbIndexEntry entry = ThumbIndexEntry.readEntry(fin);
        if (entry == null) break;
        index.add(entry);
      }
      fin.close();
    }
    catch (IOException exc) { exc.printStackTrace(); }
  }


  // -- API methods --

  /**
   * Retrieves the thumbnail matching the specified
   * parameters from the disk cache.
   */
  public FlatField retrieveThumb(RawData raw,
    int[] pos, int res_x, int res_y, boolean[] range)
  {
    int size = index.size();
    for (int i=0; i<size; i++) {
      int ndx = (i + last) % size;
      ThumbIndexEntry entry = (ThumbIndexEntry) index.elementAt(ndx);
      if (entry.matches(raw, pos, res_x, res_y, range)) {
        last = ndx;
        try { return load(entry.getOffset(), entry.getLength()); }
        catch (IOException exc) { return null; }
      }
    }
    return null;
  }

  /** Stores the given thumbnail in the disk cache. */
  public void storeThumb(FlatField thumb, RawData raw,
    int[] pos, int res_x, int res_y, boolean[] range)
  {
    try {
      long offset = data_file.length();

      // append thumbnail to the data file
      save(thumb);

      // construct index entry
      int length = (int) (data_file.length() - offset);
      ThumbIndexEntry entry = new ThumbIndexEntry(
        raw, pos, res_x, res_y, range, offset, length);
      index.add(entry);

      // append index entry to the index file
      PrintWriter fout = new PrintWriter(
        new FileWriter(index_file.getPath(), true));
      entry.writeEntry(fout);
      fout.close();

      save(thumb);
    }
    catch (IOException exc) { exc.printStackTrace(); }
  }

  /** Wipes the thumbnail disk cache. */
  public void clear() {
    try {
      index_file.delete();
      data_file.delete();
      index_file.createNewFile();
      data_file.createNewFile();
    }
    catch (IOException exc) { exc.printStackTrace(); }
  }

  /** Gets thumbnail cache disk usage in bytes. */
  public long getUsage() { return index_file.length() + data_file.length(); }

  /** Gets the number of thumbnails in the disk cache. */
  public int getThumbCount() { return index.size(); }


  // -- Helper methods --

  /** Saves the given data object to the end of the cache file. */
  private void save(FlatField thumb) throws IOException {
    ObjectOutputStream fout = new ObjectOutputStream(
      new FileOutputStream(data_file.getPath(), true));
    fout.writeObject(thumb);
    fout.flush();
    fout.close();
  }

  /** Loads the data object at the given byte offset of the cache file. */
  private FlatField load(long offset, int length) throws IOException {
    RandomAccessFile file = new RandomAccessFile(data_file, "r");
    file.seek(offset);
    byte[] bytes = new byte[length];
    file.readFully(bytes);
    file.close();

    ObjectInputStream fin = new ObjectInputStream(
      new ByteArrayInputStream(bytes));
    FlatField thumb = null;
    try { thumb = (FlatField) fin.readObject(); }
    catch (ClassNotFoundException exc) { }
    fin.close();
    return thumb;
  }

}
