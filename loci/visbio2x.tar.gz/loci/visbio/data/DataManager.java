//
// DataManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.awt.event.*;
import java.io.*;
import java.util.Vector;

import javax.swing.*;

import loci.visbio.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.*;
import loci.visbio.util.*;

import visad.VisADException;
import visad.util.Util;

/** DataManager is the class encapsulating VisBio's data object logic. */
public class DataManager extends LogicManager implements ActionListener {

  // -- Constants --

  /** String for usage of thumbnail cache. */
  private static final String CACHE_THUMBS = "Cache thumbnails on disk";

  /** String for default (maximum) image stack resolution. */
  private static final String STACK_RES = "Default image stack resolution";

  /** String for default (maximum) thumbnail resolution. */
  private static final String THUMB_RES = "Default thumbnail resolution";

  /** String for limit (maximum) of image stack data. */
  private static final String STACK_LIMIT = "Image stack size limit";

  /** String for limit (maximum) of thumbnail data. */
  private static final String THUMB_LIMIT = "Thumbnail size limit";

  /** String for automatic screen data purging. */
  private static final String AUTO_PURGE =
    "Purge old screen data when importing raw data";

  /** String for automatic screen data creation option. */
  private static final String AUTO_CREATE =
    "Automatically create screen data from raw data";

  /** String for automatic screen data display option. */
  private static final String AUTO_DISPLAY =
    "Automatically display newly created screen data";

  /** String for large dataset creation warning. */
  private static final String WARN_LARGE =
    "Warn if image stack size is above the limit";

  /** String for large-thumbed dataset creation warning. */
  private static final String WARN_THUMBS =
    "Warn if thumbnail size is above the limit";


  // -- Fields --

  /** Current multidimensional raw data object. */
  private RawData raw;

  /** Current multidimensional screen data object. */
  private ScreenData screen;


  // -- Dialogs --

  /** Import dialog for loading single file dataset. */
  private JFileChooser fileImporter;

  /** Import dialog for loading multidimensional data series. */
  private ImportGroupPane groupImporter;

  /** Export dialog for saving multidimensional data series. */
  private ExportPane exporter;


  // -- Control panel --

  /** Data control panel. */
  private DataPanel dataPanel;


  // -- Constructor --

  /** Constructs a data manager. */
  public DataManager(VisBio biovis) { super(biovis); }


  // -- New API methods --

  /** Sets VisBio's current dataset to the given one. */
  public void setRawData(RawData raw) {
    boolean changed = this.raw != raw;
    this.raw = raw;
    if (changed) {
      dataPanel.updateRawData();
      exporter.setRawData(raw);
    }

    StateManager sm = (StateManager) bio.getManager(StateManager.class);
    bio.generateEvent(this, "load data", true);

    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om == null || sm == null || sm.isRestoring()) return;

    // auto-purge old screen datasets
    BooleanOption purgeOption = (BooleanOption) om.getOption(AUTO_PURGE);
    if (purgeOption.getValue()) {
      dataPanel.setScreenDatasets(new Vector());
      SystemManager.gc();
    }

    // auto-create screen dataset
    BooleanOption createOption = (BooleanOption) om.getOption(AUTO_CREATE);
    if (createOption.getValue()) dataPanel.makeScreenData(false);
  }

  /** Sets VisBio's active screen dataset to the given one. */
  public void setScreenData(ScreenData screen) {
    if (this.screen == screen) return;
    this.screen = screen;
    if (screen == null) bio.setTitle(VisBio.TITLE);
    else {
      String name = screen.getDescriptor().name;
      String pattern = screen.getDescriptor().raw.getPattern();
      bio.setTitle(VisBio.TITLE + " - " + name + " (" + pattern + ")");
    }
    dataPanel.setSelectedScreenDataset(screen);
    bio.generateEvent(this, "set active screen dataset", true);
  }

  /** Imports a single file into VisBio. */
  public void importFile(String id) {
    final String fid = id;
    Util.invoke(false, new Runnable() {
      public void run() {
        groupImporter.importFile(new File(fid));
        RawData raw = groupImporter.getDataObject();
        if (raw != null) doRawData(raw);
      }
    });
  }

  /**
   * Imports a file group using the group import dialog
   * with the given initial file.
   */
  public void importFileGroup(File file) {
    final File ffile = file;
    Util.invoke(false, new Runnable() {
      public void run() {
        // get file group from import dialog
        groupImporter.selectFile(ffile);
        if (groupImporter.showDialog(bio) != DialogPane.APPROVE_OPTION) {
          return;
        }
        RawData raw = groupImporter.getDataObject();
        doRawData(raw);
      }
    });
  }

  /**
   * Checks if automatic screen data display is active, and if so,
   * displays the currently selected screen dataset.
   */
  public void checkAutoDisplay() {
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    StateManager sm = (StateManager) bio.getManager(StateManager.class);
    if (om == null || sm == null || sm.isRestoring()) return;
    BooleanOption option = (BooleanOption) om.getOption(AUTO_DISPLAY);
    if (!option.getValue()) return;

    // auto-display screen dataset
    setScreenData(dataPanel.getSelectedScreenDataset());
  }

  /**
   * Checks if the dataset represented by the screen data pane's parameters
   * should elicit any warnings, and does so if necessary.
   */
  public boolean checkDataset(ScreenDataPane pane) {
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      int stack = (int) (4 * pane.getImageStackSize() / 1048576);
      String msg = null;
      int stackLimit = getStackSizeLimit();
      if (stack > stackLimit) {
        int exp = (int) Math.ceil(Math.log(stack) / Math.log(2)) + 1;
        int recommend = (int) Math.pow(2, exp);
        if (recommend < 256) recommend = 256;
        boolean success = om.checkWarning(WARN_LARGE, true,
          "The dataset you are creating contains " + stack + " MB of\n" +
          "image stack data. Consider decreasing either the stack\n" +
          "resolution or the number of slices to achieve better\n" +
          "performance. Do not proceed unless your machine has\n" +
          "at least " + recommend + " MB of RAM. Press Ok to continue, or\n" +
          "Cancel to make alterations to the dataset.");
        if (!success) return false;
      }
      int thumb = (int) (4 * pane.getThumbnailSize() / 1048576);
      int thumbLimit = getThumbSizeLimit();
      if (thumb > thumbLimit) {
        int exp = (int) Math.ceil(Math.log(thumb) / Math.log(2)) + 1;
        int recommend = (int) Math.pow(2, exp);
        if (recommend < 256) recommend = 256;
        boolean success = om.checkWarning(WARN_THUMBS, true,
          "The dataset you are creating contains " + thumb + " MB\n" +
          "of thumbnail data. Consider decreasing either the\n" +
          "thumbnail resolution or one or more dimensional\n" +
          "sampling parameters to achieve better performance.\n" +
          "Do not proceed unless your machine has at least\n" +
          recommend + " MB of RAM. Press OK to continue, or Cancel to\n" +
          "make alterations to the dataset.");
        if (!success) return false;
      }
    }
    return true;
  }

  /** Gets the current list of screen datasets. */
  public Vector getScreenDatasets() { return dataPanel.getScreenDatasets(); }

  /** Gets VisBio's current dataset. */
  public RawData getRawData() { return raw; }

  /** Gets VisBio's active screen dataset. */
  public ScreenData getScreenData() { return screen; }

  /** Constructs a new, uninitialized screen dataset object. */
  public ScreenData makeScreenData() {
    ScreenData screen = new ScreenData();
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      BooleanOption option = (BooleanOption) om.getOption(CACHE_THUMBS);
      screen.setUseCache(option.getValue());
    }
    return screen;
  }

  /** Gets default (maximum) resolution of image stack data. */
  public int getDefaultStackRes() { return getNumericOption(STACK_RES); }

  /** Gets default (maximum) resolution of thumbnail data. */
  public int getDefaultThumbRes() { return getNumericOption(THUMB_RES); }

  /** Gets the limit (maximum) of image stack data in megabytes. */
  public int getStackSizeLimit() { return getNumericOption(STACK_LIMIT); }

  /** Gets the limit (maximum) of thumbnail data in megabytes. */
  public int getThumbSizeLimit() { return getNumericOption(THUMB_LIMIT); }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof ExitManager) {
        String msg = evt.getMessage();
        if (msg.equals("shutdown")) {
          // close all open data files
          if (raw != null) {
            try { raw.close(); }
            catch (VisADException exc) { exc.printStackTrace(); }
            catch (IOException exc) { exc.printStackTrace(); }
          }
        }
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 6; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    // save raw dataset
    if (raw == null) fout.println("null");
    else {
      fout.println("Raw:");
      raw.saveState(fout);
    }

    // save screen datasets
    Vector v = dataPanel.getScreenDatasets();
    int num = v.size();
    fout.println(num);
    for (int i=0; i<num; i++) {
      ScreenData screen = (ScreenData) v.elementAt(i);
      ((ScreenData) v.elementAt(i)).saveState(fout);
    }

    // save current screen dataset index
    fout.println(v.indexOf(screen));
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    // restore raw dataset
    String s;
    try { s = fin.readLine(); }
    catch (IOException exc) { throw new SaveException(exc); }
    if (s.equals("null")) setRawData(null);
    else {
      RawData raw = new RawData();
      raw.restoreState(fin);
      if (!raw.matches(this.raw)) {
        raw.initState(null);
        String msg = raw.getErrorMessage();
        if (msg != null) {
          JOptionPane.showMessageDialog(bio, msg,
            "Cannot import data", JOptionPane.ERROR_MESSAGE);
          throw new SaveException(raw.getException());
        }
        setRawData(raw);
      }
    }

    // restore screen datasets
    int num;
    try { num = Integer.parseInt(fin.readLine()); }
    catch (IOException exc) { throw new SaveException(exc); }
    final Vector old_data = dataPanel.getScreenDatasets();
    final Vector new_data = new Vector(num);
    final BioTask[] tasks = new BioTask[num];
    for (int i=0; i<num; i++) {
      ScreenData screen = makeScreenData();
      screen.restoreState(fin);
      tasks[i] = screen.getTask();

      // initialize screen dataset's associated raw dataset
      ScreenDescriptor latest = screen.getLatest();
      if (latest.raw.matches(raw)) latest.raw = raw;
      else latest.raw.initState(null);

      new_data.add(screen);
    }
    final MultiTask task = new MultiTask(tasks);
    Thread t = new Thread(new Runnable() {
      public void run() {
        StateManager.mergeStates(old_data, new_data);
        dataPanel.setScreenDatasets(new_data);
        task.clear();
      }
    });
    t.start();
    task.showProgressDialog(bio);

    // restore current screen dataset
    int cur;
    try { cur = Integer.parseInt(fin.readLine()); }
    catch (IOException exc) { throw new SaveException(exc); }
    if (cur < 0 || cur >= num) setScreenData(null);
    else setScreenData((ScreenData) new_data.elementAt(cur));
  }


  // -- ActionListener API methods --

  /** Handles button presses. */
  public void actionPerformed(ActionEvent e) {
    String cmd = e.getActionCommand();
    if (cmd.equals("clearCache")) {
      // calculate thumbnail disk cache usage
      ThumbCache cache = ScreenData.getThumbCache();
      long usage = cache.getUsage() / 1048576;
      int numThumbs = cache.getThumbCount();

      // confirm clear operation
      int rval = JOptionPane.showConfirmDialog(bio,
        "The thumbnail disk cache contains " + numThumbs +
        " thumbnails totalling " + usage + " MB of data.\n" +
        "Are you sure you wish to clear it?",
        "VisBio", JOptionPane.YES_NO_OPTION);
      if (rval != JOptionPane.YES_OPTION) return;

      // clear cache
      cache.clear();
    }
  }


  // -- Helper methods --

  /** Adds data-related GUI components to VisBio. */
  private void doGUI() {
    // dialogs
    bio.setStatus("Initializing data logic");
    fileImporter = BioUtil.getVisBioFileChooser();
    groupImporter = new ImportGroupPane(fileImporter);
    exporter = new ExportPane();

    // menu items
    bio.setStatus(null);
    bio.addMenuItem("File", "Open file...",
      "loci.visbio.data.DataManager.fileOpenFile", 'f',
      "Imports a 3-D data series from a single file");
    bio.setMenuShortcut("File", "Open file...", KeyEvent.VK_O);
    bio.addMenuItem("File", "Open group...",
      "loci.visbio.data.DataManager.fileOpenGroup", 'g',
      "Imports a multi-dimensional data series from a collection of files");
    bio.setMenuShortcut("File", "Open group...", KeyEvent.VK_G);
    bio.addMenuSeparator("File");
    bio.addMenuItem("File", "Export data...",
      "loci.visbio.data.DataManager.fileExport", 'e',
      "Exports the current multi-dimensional data series to disk");
    bio.setMenuShortcut("File", "Export data...", KeyEvent.VK_E);

    // control panel
    bio.setStatus(null);
    dataPanel = new DataPanel(this);
    PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
    if (pm != null) pm.addPanel(dataPanel);

    // options menu
    bio.setStatus(null);
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      // Cache
      om.addBooleanOption("Cache", CACHE_THUMBS, 'c',
        "Toggles whether VisBio uses a thumbnail disk cache to speed up " +
        "the thumbnail creation process", true);
      JButton clearCache = new JButton("Clear thumbnail cache");
      clearCache.setToolTipText("Erases data in the thumbnail disk cache");
      clearCache.setMnemonic('c');
      clearCache.setActionCommand("clearCache");
      clearCache.addActionListener(this);
      om.addCustomOption("Cache", clearCache);

      // Sampling
      om.addNumericOption("Sampling", STACK_RES, 'i', "pixels",
        "Default (maximum) resolution of image stacks", 192);
      om.addNumericOption("Sampling", THUMB_RES, 't', "pixels",
        "Default (maximum) resolution of thumbnails", 96);
      om.addNumericOption("Sampling", STACK_LIMIT, 'm', "MB",
        "Limit (maximum) on image stack data size", 64);
      om.addNumericOption("Sampling", THUMB_LIMIT, 'h', "MB",
        "Limit (maximum) on thumbnail data size", 128);

      // Automation
      om.addBooleanOption("Automation", AUTO_PURGE, 'p',
        "Toggles whether VisBio should purge existing screen datasets " +
        "when a new raw dataset is loaded", true);
      om.addBooleanOption("Automation", AUTO_CREATE, 'c',
        "Toggles whether VisBio should create screen data automatically," +
        "as soon as new raw data has been loaded", true);
      om.addBooleanOption("Automation", AUTO_DISPLAY, 'd',
        "Toggles whether VisBio should immediately begin visualization of " +
        "a newly created screen dataset", true);

      // Warnings
      om.addBooleanOption("Warnings", WARN_LARGE, 'l',
        "Toggles whether VisBio displays a warning " +
        "if a screen dataset's dimensions might be too large", true);
      om.addBooleanOption("Warnings", WARN_THUMBS, 'l',
        "Toggles whether VisBio displays a warning " +
        "if a screen dataset's thumbnails might be too large", true);
    }

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("Data", "data.html");

    // initialize thumbnail cache to avoid hiccup later
    bio.setStatus("Initializing thumbnail cache");
    ScreenData.getThumbCache();
  }

  /** Sets the given raw data, displaying any errors onscreen. */
  private void doRawData(RawData raw) {
    BioUtil.setWaitCursor(bio, true);
    String msg = raw.getErrorMessage();
    if (msg == null) setRawData(raw);
    else {
      JOptionPane.showMessageDialog(bio, msg,
        "Cannot import data", JOptionPane.ERROR_MESSAGE);
    }
    BioUtil.setWaitCursor(bio, false);
  }

  /** Gets the value of the numeric option with the given text. */
  private int getNumericOption(String text) {
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      NumericOption option = (NumericOption) om.getOption(text);
      return option.getValue();
    }
    return -1;
  }


  // -- Menu commands --

  /** Imports a 3-D data series from a single file. */
  public void fileOpenFile() {
    Util.invoke(false, new Runnable() {
      public void run() {
        // get file from import dialog
        if (fileImporter.showOpenDialog(bio) != JFileChooser.APPROVE_OPTION) {
          return;
        }
        importFile(fileImporter.getSelectedFile().getAbsolutePath());
      }
    });
  }

  /** Imports a multidimensional data series from a collection of files. */
  public void fileOpenGroup() { importFileGroup(null); }

  /** Exports a data series from VisBio to disk. */
  public void fileExport() {
    Util.invoke(false, new Runnable() {
      public void run() {
        if (raw == null) return;
        if (exporter.showDialog(bio) != DialogPane.APPROVE_OPTION) return;
        exporter.export();
      }
    });
  }

}
