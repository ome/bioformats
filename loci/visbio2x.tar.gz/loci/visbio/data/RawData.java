//
// RawData.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.io.*;
import java.rmi.RemoteException;
import java.util.*;

import loci.visbio.*;
import loci.visbio.state.*;
import loci.visbio.util.BioUtil;

import visad.*;
import visad.data.BadFormException;

/**
 * A RawData object encompasses a multidimensional biological image series.
 * Such an object is typically between two and six dimensions as follows:
 * <li>2D: a single image
 * <li>3D: an image stack, or a time series of images
 * <li>4D: a time series of image stacks
 * <li>5D: an image stack with spectral lifetime data at each pixel
 * <li>6D: a time series of image stacks with
 *         spectral lifetime data at each pixel
 * <p>
 * Other configurations are certainly possible, and RawData provides an
 * interface for multidimensional image data of any organization.
 * <p>
 * RawData keeps no data in memory itself, leaving that management to the
 * application, and just loads data as necessary to return whatever the
 * application requests.
 */
public class RawData implements Saveable, Dynamic {

  // -- Constants --

  /** Strings corresponding to dimensional types. */
  public static final String[] DIMS = {
    "TIME", "SLICE", "SPECTRA", "LIFETIME", "POLARIZATION", "OTHER"
  };


  // -- File format constants --

  /** Indicates Bio-Rad PIC format. */
  public static final int BIORAD_FORMAT = 1;
  
  /** Indicates multi-page TIFF stack format. */
  public static final int TIFF_FORMAT = 2;
  
  /** Indicates QuickTime movie format. */
  public static final int QUICKTIME_FORMAT = 3;


  // -- Dimensional index constants --

  /** Indicates dimension represents data over time. */
  public static final int TIME = 0;

  /** Indicates dimension represents a stack of data. */
  public static final int FOCAL_PLANE = 1;

  /** Indicates dimension represents spectral data. */
  public static final int SPECTRA = 2;

  /** Indicates dimension represents lifetime data. */
  public static final int LIFETIME = 3;

  /** Indicates dimension represents polarization data. */
  public static final int POLARIZATION = 4;

  /** Indicates dimension represents some other type of data. */
  public static final int OTHER = -1;


  // -- RealTypes corresponding to various dimensional types --

  /** RealType for time dimension. */
  public static final RealType RT_TIME = RealType.getRealType("bio_time");

  /** RealType for focal plane dimension. */
  public static final RealType RT_PLANE =
    RealType.getRealType("bio_focal_plane");

  /** RealType for spectral dimension. */
  public static final RealType RT_SPECTRA =
    RealType.getRealType("bio_spectra");

  /** RealType for lifetime dimension. */
  public static final RealType RT_LIFETIME =
    RealType.getRealType("bio_lifetime");

  /** RealType for polarization dimension. */
  public static final RealType RT_POLAR =
    RealType.getRealType("bio_polarization");


  // -- Data fields --

  /** Source file array. */
  protected String[] ids;

  /** Length of each dimension in the multidimensional image structure. */
  protected int[] lengths;

  /**
   * Index of the dimension with which each file's image list stacks.
   *
   * For example, if the first dimension is time, and dim_index equals 0,
   * the image series present in each file is part of the time series.
   *
   * If dim_index does not correspond to a legal index (i.e., it is less than
   * 0, or greater than or equal to numDim), the source files'
   * image series are treated as an additional dimension.
   */
  protected int dim_index;

  /**
   * A list of what each dimension in the multidimensional structure means.
   *
   * Each entry of dims should equal one of the following values:
   *    TIME, FOCAL_PLANE, SPECTRA, LIFETIME, POLARIZATION or OTHER.
   */
  protected int[] dims;

  /** A string pattern describing this dataset. */
  protected String pattern;


  // -- Computed fields --

  /** Data loaders, one for each source file in the array. */
  protected ImageFamily[] loaders;

  /** Number of images per source file. */
  protected int numImages;

  /** File format description of source files. */
  protected String format;

  /** MathType representing an image. */
  protected MathType imageType;

  /** Width of each image. */
  protected int res_x;

  /** Height of each image. */
  protected int res_y;

  /** Number of dimensions in the multidimensional image structure. */
  protected int numDim;

  /**
   * True if dim_index indicates that source files contain
   * images that stack with an already specified dimension.
   */
  protected boolean imagesStack;

  /** RealType for each dimension in the multidimensional structure. */
  protected RealType[] types;

  /**
   * A convenience array so that references can be made, such as dim_ndx[TIME],
   * for determining that dimension's index into lengths, etc.
   *
   * Note that dim_ndx[OTHER] is undefined, because it is
   * possible for more than one dimension to be "other."
   */
  protected int[] dim_ndx;

  /** Computed offset coefficients into rasterized source file array. */
  protected int[] offsets;


  // -- Other fields --

  /** Current task. */
  protected BioTask task;

  /** Error message generated while initializing the data object. */
  protected String errorMsg;

  /** Exception generated while initializing the data object. */
  protected Exception errorExc;


  // -- Constructors --

  /** Constructs an uninitialized multidimensional data object. */
  public RawData() { }

  /**
   * Constructs a new multidimensional data object from the given list of
   * source files. Any multidimensional file organization can be specified,
   * rasterized, using the ids source file list coupled with the lengths
   * array, which lists the length of each dimension in the structure.
   * <p>
   * Since each file can contain up to one dimension of images, that
   * dimension must be specified as either corresponding one of the previous
   * dimensions, or as a new dimension. Thus, a dim_index must be given,
   * with a value of 0 to indicate stacking with the 1st dimension (of
   * length lengths[0]), 1 for stacking with the 2nd dimension, etc. A
   * negative value, or one greater than or equal to lengths.length,
   * indicates the file's dimension is a new one.
   * <p>
   * Also, a list of what each dimension in the multidimensional structure
   * means must be provided, using the dims array. dims.length should equal
   * numDim.
   * <p>
   * Each entry of dims should equal one of the following values:
   *    TIME, FOCAL_PLANE, SPECTRA, LIFETIME, POLARIZATION or OTHER.
   *
   * @param pattern String pattern describing the dataset.
   * @param ids List of source files, with dimensions rasterized.
   * @param lengths List of dimension lengths.
   * @param dim_index Dimensional index with which each file's image series
   *   should stack, or -1 for each file's image series to form a new
   *   dimension (also -1 if each file only has one image).
   * @param dims List of each dimension's meaning (TIME, FOCAL_PLANE, etc.).
   */
  public RawData(String pattern, String[] ids, int[] lengths,
    int dim_index, int[] dims)
  {
    this.pattern = pattern;
    this.ids = ids;
    this.lengths = lengths;
    this.dim_index = dim_index;
    this.dims = dims;
    initState(null);
  }


  // -- API methods - core functionality --

  /**
   * Obtains one image from the source(s).
   *
   * @param index Zero-based list of dimensional indices.
   * @param res_x X resolution of returned image (0 for default).
   * @param res_y Y resolution of returned image (0 for default).
   * @param range List of flags indicating whether each range dimension
   *   should constitute part of the returned image.
   *
   * @return Image at the given dimensional index at the specified resolution.
   */
  public FlatField getImage(int[] index, int res_x, int res_y, boolean[] range)
    throws VisADException, IOException
  {
    return getData(index, index, res_x, res_y, range)[0];
  }

  /**
   * Extracts data from the source(s). The returned data will be a block of
   * images from the start image (specified with a list of dimensional
   * indices in the start array) to the end image (specified with a list of
   * dimensional indices in the end array). The images will be of the desired
   * resolution (res_x by res_y), and contain only the desired range
   * components (flagged using the range boolean array).
   *
   * @param start Zero-based dimensional indices indicating the starting image
   *   of the block.
   * @param end Zero-based dimensional indices indicating the ending image
   *   of the block.
   * @param res_x Desired X resolution of returned images (0 for default).
   * @param res_y Desired Y resolution of returned images (0 for default).
   * @param range List of flags indicating whether each range dimension
   *   should constitute part of the returned images.
   *
   * @return A subset of the data at the specified resolution.
   */
  public FlatField[] getData(int[] start, int[] end, int res_x, int res_y,
    boolean[] range) throws VisADException, IOException
  {
    boolean outer = task.isClear();
    int[] len = new int[numDim];
    int numImg = 1;
    for (int i=0; i<numDim; i++) {
      len[i] = end[i] - start[i] + 1;
      numImg *= len[i];
    }

    int[] res = res_x > 0 && res_y > 0 ? new int[] {res_x, res_y} : null;
    FlatField[] ff = new FlatField[numImg];
    if (outer) task.addOperation("Loading data", numImg);
    for (int count=0; count<numImg; count++) {
      int[] ndx = BioUtil.rasterToPosition(len, count);

      // convert array indices to 0-base dataset coordinates
      for (int i=0; i<numDim; i++) ndx[i] += start[i];

      ff[count] = resample(loadImage(ndx), res, range);
      if (outer) task.advance();
    }
    if (outer) task.clear();
    return ff;
  }

  /**
   * Loads the image corresponding to the given dimensional indices.
   *
   * @param indices Zero-based dimensional indices of image to load.
   */
  public FlatField loadImage(int[] indices)
    throws VisADException, IOException
  {
    boolean outer = task.isClear();
    if (outer) task.addOperation("Loading image", 1);
    int file_ndx = 0;
    int img_ndx = 0;
    if (imagesStack) {
      // file images stack with an existing dimension
      for (int i=0; i<offsets.length; i++) {
        int q = indices[i];
        if (i == dim_index) {
          q /= numImages;
          img_ndx = indices[i] % numImages;
        }
        file_ndx += offsets[i] * q;
      }
    }
    else if (numImages > 1) {
      // file images form a new dimension
      for (int i=0; i<offsets.length; i++) file_ndx += offsets[i] * indices[i];
      img_ndx = indices[indices.length - 1];
    }
    else {
      // only one image per file
      for (int i=0; i<offsets.length; i++) file_ndx += offsets[i] * indices[i];
      img_ndx = 0;
    }

    // open ids[file_ndx], get img_ndx'th image from it, and return it
    task.setMessage("Loading " + ids[file_ndx]);
    FlatField ff = null;
    try { ff = (FlatField) loaders[file_ndx].open(ids[file_ndx], img_ndx); }
    catch (IOException exc) {
      // trap for catching rare, elusive "Bad file descriptor" IOException
      System.err.println("The weasels are loose! You have uncovered a very " +
        "rare, nasty bug. The author has been unable to reproduce this bug. " +
        "Please restart VisBio and try whatever you were doing again, to " +
        "see if you can reproduce the bug. If so, please email the author. " +
        "Technical information follows:");
      System.err.println("Exception occurred while attempting to load " +
        "image #" + img_ndx + " from file #" + file_ndx + " (" +
        ids[file_ndx] + ")");
      System.err.print("indices = ( ");
      for (int i=0; i<indices.length; i++) System.err.print(indices[i] + " ");
      System.err.println(")");
      System.err.print("offsets = ( ");
      for (int i=0; i<offsets.length; i++) System.err.print(offsets[i] + " ");
      System.err.println(")");
      System.err.print("lengths = ( ");
      for (int i=0; i<lengths.length; i++) System.err.print(lengths[i] + " ");
      System.err.println(")");
      throw exc;
    }
    if (outer) {
      task.advance();
      task.clear();
    }
    return ff;
  }

  /** Close all open ids. */
  public void close() throws VisADException, IOException {
    for (int i=0; i<ids.length; i++) loaders[i].close();
  }


  // -- API methods - accessors --
  
  /** Gets RealTypes used to construct data objects for this dataset. */
  public RealType[] getTypes() { return types; }

  /** Gets RealType used for each individual image of the dataset. */
  public MathType getImageType() { return imageType; }

  /** Gets the string pattern describing this dataset. */
  public String getPattern() { return pattern; }

  /** Gets filenames of all files in dataset. */
  public String[] getFilenames() { return ids; }

  /** Gets length of each dimension in the multidimensional image structure. */
  public int[] getLengths() { return lengths; }

  /** Gets index of the dimension with which each file's image list stacks. */
  public int getDimIndex() { return dim_index; }

  /** Gets the type of each dimension in the structure. */
  public int[] getDimTypes() { return dims; }

  /** Gets the string description of each dimension type in the structure. */
  public String[] getDimStrings() {
    String[] s = new String[dims.length];
    for (int i=0; i<dims.length; i++) {
      s[i] = dims[i] == OTHER ? DIMS[DIMS.length - 1] : DIMS[dims[i]];
    }
    return s;
  }

  /** Gets the number of images per source file. */
  public int getImagesPerSource() { return numImages; }

  /** Gets a description of the source files' file format. */
  public String getFileFormat() { return format; }

  /** Gets width of each image. */
  public int getImageWidth() { return res_x; }

  /** Gets height of each image. */
  public int getImageHeight() { return res_y; }

  /** Gets number of range components at each pixel. */
  public int getRangeCount() {
    MathType mtype = ((FunctionType) imageType).getRange();
    return mtype instanceof TupleType ?
      ((TupleType) mtype).getNumberOfRealComponents() : 1;
  }

  /** Gets the current task. */
  public BioTask getTask() { return task; }

  /**
   * Gets the error message generated during initialization,
   * or null if initialization was successful.
   */
  public String getErrorMessage() { return errorMsg; }

  /**
   * Gets the exception generated during initialization,
   * or null if initialization was successful.
   */
  public Exception getException() { return errorExc; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    int[] nlen;
    if (imagesStack) {
      nlen = new int[lengths.length];
      System.arraycopy(lengths, 0, nlen, 0, lengths.length);
      nlen[dim_index] /= numImages;
    }
    else if (numImages > 1) {
      nlen = new int[lengths.length - 1];
      System.arraycopy(lengths, 0, nlen, 0, nlen.length);
    }
    else nlen = lengths;
    fout.println(pattern);
    BioUtil.writeArray(ids, fout);
    BioUtil.writeArray(nlen, fout);
    fout.println(dim_index);
    BioUtil.writeArray(dims, fout);
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    try {
      pattern = fin.readLine();
      ids = BioUtil.readArray(ids, fin);
      lengths = BioUtil.readArray(lengths, fin);
      dim_index = Integer.parseInt(fin.readLine());
      dims = BioUtil.readArray(dims, fin);
    }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- Dynamic API methods --

  /** Tests whether two dynamic objects have matching states. */
  public boolean matches(Dynamic dyn) {
    if (!(dyn instanceof RawData)) return false;
    RawData raw = (RawData) dyn;
    if (raw == null) return false;
    return BioUtil.objectsEqual(pattern, raw.pattern) &&
      BioUtil.arraysEqual(ids, raw.ids) &&
      BioUtil.arraysEqual(lengths, raw.lengths) &&
      dim_index == raw.dim_index &&
      BioUtil.arraysEqual(dims, raw.dims);
  }

  /** Modifies this object's state to match that of the given object. */
  public void initState(Dynamic dyn) {
    errorMsg = null;
    errorExc = null;

    if (dyn != null && dyn instanceof RawData) {
      RawData raw = (RawData) dyn;
      pattern = raw.pattern;
      ids = raw.ids;
      lengths = raw.lengths;
      dim_index = raw.dim_index;
      dims = raw.dims;
    }

    // make sure each file exists
    for (int i=0; i<ids.length; i++) {
      File file = new File(ids[i]);
      if (!file.exists()) {
        errorMsg = "File " + file.getName() + " does not exist.";
        errorExc = new VisADException("File " + ids[i] + " not found");
        return;
      }
    }

    imagesStack = dim_index >= 0 && dim_index < lengths.length;
    numDim = dims.length;

    // initialize data loaders
    loaders = new ImageFamily[ids.length];
    for (int i=0; i<ids.length; i++) loaders[i] = new ImageFamily();

    // initialize offsets convenience array
    offsets = new int[lengths.length];
    if (lengths.length > 0) offsets[0] = 1;
    for (int i=1; i<lengths.length; i++) {
      offsets[i] = offsets[i - 1] * lengths[i - 1];
    }

    // determine number of images per source file
    try {
      numImages = loaders[0].getBlockCount(ids[0]);
      format = loaders[0].getFormatString();
      if (format.startsWith("TIFF")) {
        format = (numImages > 1 ? "multi-page " : "single-image ") + format;
      }
      if (ids.length > 1) format += "s";
    }
    catch (BadFormException exc) {
      if (ids[0].toLowerCase().endsWith(".mov")) {
        if (loaders[0].canDoQT()) {
          errorMsg = "The file seems to be in QuickTime format, but the " +
            "data appears\ncorrupt or invalid. It may use an unsupported " +
            "codec or other feature.";
        }
        else {
          errorMsg = "The file seems to be in QuickTime format, but " +
            "QuickTime for Java does not appear to be installed.\n" +
            "Please install QuickTime for Java from: " +
            "http://www.apple.com/quicktime/download/";
        }
      }
      else {
        errorMsg = "The file format is not supported, " +
          "or the file data is corrupt or invalid.";
      }
      errorExc = exc;
      return;
    }
    catch (IOException exc) {
      errorMsg = "Could not determine number of images per file.\n" +
        "\"" + new File(ids[0]).getName() + "\" may be corrupt or invalid.";
      errorExc = exc;
      return;
    }
    catch (VisADException exc) {
      errorMsg = "Could not determine number of images per file.\n" +
        "\"" + new File(ids[0]).getName() + "\" may be corrupt or invalid.";
      errorExc = exc;
      return;
    }
    if (imagesStack) lengths[dim_index] *= numImages;
    else if (numImages > 1) {
      int[] nlen = new int[lengths.length + 1];
      System.arraycopy(lengths, 0, nlen, 0, lengths.length);
      nlen[lengths.length] = numImages;
      this.lengths = nlen;
    }

    // determine image RealType
    FieldImpl img = null;
    try { img = (FieldImpl) loaders[0].open(ids[0], 0); }
    catch (BadFormException exc) {
      errorMsg = "Could not read the first image.\n" +
        "\"" + new File(ids[0]).getName() + "\" may be corrupt or invalid.";
      errorExc = exc;
      return;
    }
    catch (IOException exc) {
      errorMsg = "Could not read the first image.\n" +
        "\"" + new File(ids[0]).getName() + "\" may be corrupt or invalid.";
      errorExc = exc;
      return;
    }
    catch (VisADException exc) {
      errorMsg = "Could not read the first image.\n" +
        "\"" + new File(ids[0]).getName() + "\" may be corrupt or invalid.";
      errorExc = exc;
      return;
    }
    catch (NullPointerException exc) {
      errorMsg = "Could not read the first image.\n" +
        "\"" + new File(ids[0]).getName() + "\" may be corrupt or invalid.";
      errorExc = exc;
      return;
    }
    imageType = img.getType();

    // determine image dimensions
    GriddedSet set = (GriddedSet) img.getDomainSet();
    int[] set_len = set.getLengths();
    res_x = set_len[0];
    res_y = set_len[1];

    // initialize types list of RealTypes
    int numOther = 0;
    types = new RealType[numDim];
    for (int i=0; i<numDim; i++) {
      if (dims[i] == TIME) types[i] = RT_TIME;
      else if (dims[i] == FOCAL_PLANE) types[i] = RT_PLANE;
      else if (dims[i] == SPECTRA) types[i] = RT_SPECTRA;
      else if (dims[i] == LIFETIME) types[i] = RT_LIFETIME;
      else if (dims[i] == POLARIZATION) types[i] = RT_POLAR;
      else types[i] = RealType.getRealType("bio_other_" + numOther++);
    }

    // initialize dim_ndx convenience array
    dim_ndx = new int[5];
    for (int i=0; i<dim_ndx.length; i++) dim_ndx[i] = -1;
    for (int i=0; i<numDim; i++) {
      if (dims[i] >= 0) dim_ndx[dims[i]] = i;
    }

    task = new BioTask();
  }

  /**
   * Called when this object is being discarded in favor of
   * another object with a matching state.
   */
  public void discard() { task.clear(); }



  // -- Utility methods --

  /**
   * Resamples the given FlatField to the specified resolution,
   * keeping only the flagged range components (or null to keep them all).
   */
  public static FlatField resample(FlatField f, int[] res, boolean[] range)
    throws VisADException, RemoteException
  {
    GriddedSet set = (GriddedSet) f.getDomainSet();
    double[][] samples = f.getValues(false);
    FunctionType function = (FunctionType) f.getType();
    MathType frange = function.getRange();
    RealType[] rt = frange instanceof RealTupleType ?
      ((RealTupleType) frange).getRealComponents() :
      new RealType[] {(RealType) frange};

    int keep = 0;
    if (range != null) for (int i=0; i<range.length; i++) if (range[i]) keep++;

    FlatField ff;
    if (range == null || keep == range.length) ff = f;
    else {
      double[][] samps = new double[keep][];
      RealType[] reals = new RealType[keep];
      int count = 0;
      for (int i=0; i<range.length; i++) {
        if (range[i]) {
          samps[count] = samples[i];
          reals[count] = rt[i];
          count++;
        }
      }
      MathType func_range = count == 1 ?
        (MathType) reals[0] : (MathType) new RealTupleType(reals);
      FunctionType func = new FunctionType(function.getDomain(), func_range);
      ff = new FlatField(func, set);
      ff.setSamples(samps, false);
    }

    int[] len = set.getLengths();
    boolean same = true;
    float[] lo = set.getLow();
    float[] hi = set.getHi();
    double[] nlo = new double[len.length];
    double[] nhi = new double[len.length];
    for (int i=0; i<len.length; i++) {
      if (res != null && len[i] != res[i]) same = false;
      nlo[i] = (double) lo[i];
      nhi[i] = (double) hi[i];
    }
    return same ? ff : (FlatField) ff.resample(new LinearNDSet(set.getType(),
      nlo, nhi, res), Data.WEIGHTED_AVERAGE, Data.NO_ERRORS);
  }

}
