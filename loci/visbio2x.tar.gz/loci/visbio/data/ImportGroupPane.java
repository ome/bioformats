//
// ImportGroupPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.math.BigInteger;
import java.util.StringTokenizer;

import javax.swing.*;

import loci.visbio.util.*;

import visad.VisADException;
import visad.data.BadFormException;

/**
 * ImportGroupPane provides a full-featured set of options
 * for importing a multidimensional data series into VisBio.
 */
public class ImportGroupPane extends WizardPane {

  // -- GUI components, page 1 --

  /** Choose file dialog box. */
  private JFileChooser fileBox;

  /** File group text field. */
  private JTextField groupField;


  // -- GUI components, page 2 --

  /** Label for file group. */
  private JLabel groupLabel;

  /** Panel for dimensional ranges. */
  private JPanel dimPanel;

  /** Button for indicating files' images form a new dimension. */
  private JRadioButton newDim;

  /** Button for indicating files' images stack with existing dimension. */
  private JRadioButton stackDim;

  /** Combo box for selecting each file's dimensional content. */
  private JComboBox newDimBox;

  /** Combo box for selecting dimensional stacking. */
  private JComboBox stackDimBox;

  /** Dimensional widgets. */
  private ImportGroupWidget[] widgets;


  // -- Other fields --

  /** File pattern. */
  private FilePattern fp;

  /** List of data files. */
  private String[] ids;

  /** Raw dataset created from import pane state. */
  private RawData raw;


  // -- Constructor --

  /** Creates a file group import dialog. */
  public ImportGroupPane() { this(BioUtil.getVisBioFileChooser()); }

  /** Creates a file group import dialog with the given file chooser. */
  public ImportGroupPane(JFileChooser fileChooser) {
    super("Open file group");
    fileBox = fileChooser;

    // first page
    JPanel first = new JPanel();
    first.setLayout(new BoxLayout(first, BoxLayout.X_AXIS));
    groupField = new JTextField();
    first.add(groupField);
    JButton select = new JButton("Select file");
    select.setMnemonic('s');
    select.setActionCommand("select");
    select.addActionListener(this);
    first.add(select);

    // second page
    JPanel second = new JPanel();
    second.setLayout(new BoxLayout(second, BoxLayout.Y_AXIS));
    groupLabel = BioUtil.makeLabel("");
    groupLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
    second.add(groupLabel);
    second.add(Box.createVerticalStrut(5));
    dimPanel = new JPanel();
    dimPanel.setLayout(new BoxLayout(dimPanel, BoxLayout.Y_AXIS));
    second.add(dimPanel);
    second.add(Box.createVerticalStrut(5));

    JPanel newDimPanel = new JPanel();
    newDimPanel.setLayout(new BoxLayout(newDimPanel, BoxLayout.X_AXIS));
    newDim = new JRadioButton("File's images define a new dimension: ", true);
    newDim.setMnemonic('d');
    newDimPanel.add(newDim);
    newDimBox = new JComboBox();
    for (int i=0; i<RawData.DIMS.length; i++) {
      newDimBox.addItem(RawData.DIMS[i]);
    }
    newDimBox.setSelectedIndex(1);
    newDimPanel.add(newDimBox);
    second.add(newDimPanel);

    JPanel stackDimPanel = new JPanel();
    stackDimPanel.setLayout(new BoxLayout(stackDimPanel, BoxLayout.X_AXIS));
    stackDim = new JRadioButton("File's images stack with dimension: ");
    stackDim.setMnemonic('s');
    stackDimPanel.add(stackDim);
    stackDimBox = new JComboBox();
    stackDimPanel.add(stackDimBox);
    second.add(stackDimPanel);

    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(newDim);
    buttonGroup.add(stackDim);

    // lay out pages
    setPages(new JPanel[] {first, second});
  }


  // -- New API methods --

  /** Gets the RawData object created from the import pane state. */
  public RawData getDataObject() { return raw; }

  /** Examines the given file to determine if it is part of a file group. */
  public void selectFile(File file) {
    if (file == null || file.isDirectory()) {
      groupField.setText("");
      return;
    }
    String pattern = FilePattern.findPattern(file);
    if (pattern == null) {
      groupField.setText(file.getAbsolutePath());
      return;
    }
    groupField.setText(pattern);
  }

  /** Uses the group importer to import a single file. */
  public void importFile(File file) {
    if (file == null || file.isDirectory()) {
      groupField.setText("");
      return;
    }
    groupField.setText(file.getAbsolutePath());
    next.doClick();
    raw = null;
    if (ok.isEnabled()) ok.doClick();
  }


  // -- ActionListener API methods --

  /** Handles button press events. */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("select")) {
      int returnVal = fileBox.showOpenDialog(this);
      if (returnVal != JFileChooser.APPROVE_OPTION) return;
      selectFile(fileBox.getSelectedFile());
    }
    else if (command.equals("next")) {
      // lay out page 2
      String pattern = groupField.getText();
      groupLabel.setText(pattern);

      fp = new FilePattern(pattern);
      if (!fp.isValid()) {
        JOptionPane.showMessageDialog(dialog, fp.getErrorMessage(),
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }
      BigInteger[] min = fp.getFirst();
      BigInteger[] max = fp.getLast();
      BigInteger[] step = fp.getStep();
      ids = fp.getFiles();
      if (ids.length < 1) {
        JOptionPane.showMessageDialog(dialog, "No files match the pattern.",
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }
      int blocks = min.length;

      // determine number of images per file
      int numImages = 0;
      ImageFamily loader = new ImageFamily();
      try { numImages = loader.getBlockCount(ids[0]); }
      catch (BadFormException exc) { }
      catch (IOException exc) { }
      catch (VisADException exc) { }
      if (numImages < 1) {
        JOptionPane.showMessageDialog(dialog,
          "Cannot determine number of images per file.\n" +
          "\"" + ids[0] + "\" may be corrupt or invalid.",
          "VisBio", JOptionPane.ERROR_MESSAGE);
        return;
      }

      // autodetect each dimension's type
      int[] kind;
      if (blocks == 0) kind = new int[0];
      else if (blocks == 1) kind = new int[] {RawData.TIME};
      else if (blocks == 2) {
        kind = new int[] {RawData.SPECTRA, RawData.LIFETIME};
      }
      else {
        kind = new int[blocks];
        kind[0] = RawData.TIME;
        kind[1] = RawData.SPECTRA;
        kind[2] = RawData.LIFETIME;
        for (int i=3; i<blocks; i++) kind[i] = RawData.OTHER;
      }

      // construct widget for each dimension
      dimPanel.removeAll();
      widgets = new ImportGroupWidget[blocks];
      for (int i=0; i<blocks; i++) {
        widgets[i] = new ImportGroupWidget(i + 1,
          kind[i], min[i], max[i], step[i]);
        dimPanel.add(widgets[i]);
      }

      // populate dimensional stacking combo box
      stackDimBox.removeAllItems();

      if (numImages == 1) {
        newDim.setEnabled(false);
        newDimBox.setEnabled(false);
        stackDim.setEnabled(false);
        stackDimBox.setEnabled(false);
        stackDim.setSelected(true);
      }
      else {
        for (int i=0; i<blocks; i++) stackDimBox.addItem("<" + (i + 1) + ">");
        newDim.setEnabled(true);
        newDimBox.setEnabled(true);
        boolean b = blocks > 0;
        stackDim.setEnabled(b);
        stackDimBox.setEnabled(b);
        newDim.setSelected(true);
      }

      super.actionPerformed(e);
    }
    else if (command.equals("ok")) {
      Container parent = dialog == null ? null : dialog.getParent();
      if (parent != null) BioUtil.setWaitCursor(parent, true);
      String pattern = groupField.getText();
      int[] lengths = fp.getCount();
      String[] ids = fp.getFiles();
      int len = lengths.length;

      // compile information on dimensional types
      int dim_index;
      int[] dims;
      if (newDim.isSelected()) {
        // files' images define a new dimension
        dims = new int[len + 1];
        dim_index = -1;
        int ndx = newDimBox.getSelectedIndex();
        dims[len] = RawData.DIMS[ndx].equals("OTHER") ? RawData.OTHER : ndx;
      }
      else {
        // files' images stack with existing dimension
        dims = new int[len];
        dim_index = stackDimBox.getSelectedIndex();
      }
      for (int i=0; i<len; i++) dims[i] = widgets[i].getDimType();

      // construct data object
      raw = new RawData(groupField.getText(), ids, lengths, dim_index, dims);
      if (parent != null) BioUtil.setWaitCursor(parent, false);

      super.actionPerformed(e);
    }
    else super.actionPerformed(e);
  }

}
