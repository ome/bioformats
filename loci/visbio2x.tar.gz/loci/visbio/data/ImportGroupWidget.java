//
// ImportGroupWidget.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.math.BigInteger;

import javax.swing.*;

import loci.visbio.util.BioUtil;

/** ImportGroupWidget is a helper widget for ImportGroupPane. */
public class ImportGroupWidget extends JPanel {

  // -- Fields --

  /** Type of dimension combo box. */
  private JComboBox dimType;


  // -- Constructor --

  /** Creates a file group import dialog. */
  public ImportGroupWidget(int num, int type,
    BigInteger min, BigInteger max, BigInteger step)
  {
    setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
    String s = "<" + num + "> (min=" + min +
      "; max=" + max + "; step=" + step + ") ";
    JLabel label = BioUtil.makeLabel(s);
    if (num < 10) label.setDisplayedMnemonic('0' + num);
    add(label);

    dimType = new JComboBox(RawData.DIMS);
    if (type == RawData.OTHER) {
      for (int i=0; i<RawData.DIMS.length; i++) {
        if (RawData.DIMS[i].equals("OTHER")) {
          type = i;
          break;
        }
      }
    }
    label.setLabelFor(dimType);
    dimType.setSelectedIndex(type);
    add(dimType);
  }


  // -- API methods --

  /** Gets the type of dimension from the combo box. */
  public int getDimType() {
    int ndx = dimType.getSelectedIndex();
    return RawData.DIMS[ndx].equals("OTHER") ? RawData.OTHER : ndx;
  }

}
