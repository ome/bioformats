//
// ExportPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.*;

import javax.swing.*;
import javax.swing.text.BadLocationException;

import loci.visbio.state.BioTask;
import loci.visbio.util.*;

import visad.*;

/**
 * ExportPane provides a full-featured set of options for exporting a
 * multidimensional data series from VisBio to several different formats.
 */
public class ExportPane extends WizardPane {

  // -- GUI components, page 1 --

  /** File pattern text field. */
  private JTextField patternField;

  /** File format combo box. */
  private JComboBox formatBox;


  // -- GUI components, page 2 --

  /** Label indicating chosen file pattern. */
  private JLabel patternLabel2;

  /** Check box indicating whether file numbering should use leading zeroes. */
  private JCheckBox leadingZeroes;

  /** Panel for frames per second GUI components. */
  private JPanel fpsPanel;

  /** Frames per second for movie formats. */
  private JTextField fps;

  /** Panel containing combo boxes for dimensional mappings. */
  private JPanel letterPanel;

  /** Text fields for specifying image resolution. */
  private JTextField imageX, imageY;

  /** Panel containing text fields for dimensional sampling. */
  private JPanel dimPanel;

  /** Panel containing range checkboxes. */
  private JPanel rangePanel;

  /** Combo boxes for mapping each star to corresponding dimensional index. */
  private JComboBox[] letterBoxes;

  /** Text fields for specifying dimensional sampling information. */
  private JTextField[] min, max, step;

  /** Checkboxes for specifying included range values. */
  private JCheckBox[] rangeBoxes;


  // -- GUI components, page 3 --

  /** Pane containing export summary. */
  private JEditorPane summary;


  // -- Other fields --

  /** File adapter for exporting VisAD data to disk. */
  private ImageFamily saver;

  /** Raw dataset from which exportable data will be derived. */
  private RawData raw;

  /** File pattern, divided into tokens. */
  private String[] tokens;

  /** Number of "stars" in the file pattern. */
  private int stars;

  /** Mapping from each star to corresponding dimensional index. */
  private int[] maps;

  /** Dimensional sampling information. */
  private int[] lo, hi, st, num;

  /** Excluded index (not mapped to a star). */
  private int excl;

  /** Width and height of each exported image. */
  private int res_x, res_y;

  /** Included range values for each exported image. */
  private boolean[] range;

  /** Number of total files to export. */
  private int numFiles;


  // -- Constructor --

  /** Creates a multidimensional data export dialog. */
  public ExportPane() {
    super("Export data");
    saver = new ImageFamily();

    // first page
    JPanel first = new JPanel();
    first.setLayout(new BoxLayout(first, BoxLayout.X_AXIS));

    // pattern label
    JLabel patternLabel = BioUtil.makeLabel("Pattern: ");
    patternLabel.setDisplayedMnemonic('p');
    first.add(patternLabel);

    // pattern field
    patternField = new JTextField();
    patternLabel.setLabelFor(patternField);
    first.add(patternField);
    first.add(Box.createHorizontalStrut(5));

    // format label
    JLabel formatLabel = BioUtil.makeLabel("Format: ");
    formatLabel.setDisplayedMnemonic('f');
    first.add(formatLabel);

    // format combo box
    formatBox = new JComboBox(new String[] {"PIC", "TIFF", "AVI", "MOV"});
    formatLabel.setLabelFor(formatBox);
    first.add(formatBox);

    // second page
    JPanel second = new JPanel();
    second.setLayout(new BoxLayout(second, BoxLayout.Y_AXIS));

    // pattern label, with stars converted to letters
    patternLabel2 = BioUtil.makeLabel("");
    patternLabel2.setAlignmentX(JLabel.CENTER_ALIGNMENT);
    second.add(BioUtil.pad(patternLabel2));
    second.add(Box.createVerticalStrut(5));

    // pad file numbering with leading zeroes checkbox
    leadingZeroes = new JCheckBox("Pad file numbering with leading zeroes");
    leadingZeroes.setMnemonic('p');
    second.add(BioUtil.pad(leadingZeroes));

    // frames per second label
    fpsPanel = new JPanel();
    fpsPanel.setLayout(new BoxLayout(fpsPanel, BoxLayout.X_AXIS));
    JLabel fpsLabel = BioUtil.makeLabel("Frames per second: ");
    fpsLabel.setDisplayedMnemonic('f');
    fpsPanel.add(fpsLabel);

    // frames per second text field
    fps = BioUtil.makeField(4);
    fpsLabel.setLabelFor(fps);
    fpsPanel.add(fps);
    second.add(fpsPanel);
    second.add(Box.createVerticalStrut(5));

    // panel for <A>, <B>, etc.
    letterPanel = new JPanel();
    letterPanel.setLayout(new BoxLayout(letterPanel, BoxLayout.Y_AXIS));
    second.add(letterPanel);
    second.add(Box.createVerticalStrut(5));

    // image resolution label
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    second.add(Box.createVerticalStrut(5));
    JLabel imageLabel = BioUtil.makeLabel("Image resolution: ");
    imageLabel.setDisplayedMnemonic('i');
    p.add(imageLabel);

    // image resolution text fields
    imageX = BioUtil.makeField(4);
    imageLabel.setLabelFor(imageX);
    p.add(imageX);
    p.add(BioUtil.makeLabel(" by "));
    imageY = BioUtil.makeField(4);
    p.add(imageY);
    second.add(p);

    // panel for <1>, <2>, etc.
    dimPanel = new JPanel();
    dimPanel.setLayout(new BoxLayout(dimPanel, BoxLayout.Y_AXIS));
    second.add(dimPanel);
    second.add(Box.createVerticalStrut(5));

    // range components label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    JLabel rangeLabel = BioUtil.makeLabel("Range components: ");
    p.add(rangeLabel);

    // range components panel
    rangePanel = new JPanel();
    rangePanel.setLayout(new BoxLayout(rangePanel, BoxLayout.X_AXIS));
    p.add(rangePanel);
    second.add(BioUtil.pad(p));

    // third page
    JPanel third = new JPanel();
    third.setLayout(new BoxLayout(third, BoxLayout.Y_AXIS));

    // summary label
    JLabel summaryLabel = BioUtil.makeLabel("Summary:");
    summaryLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
    third.add(summaryLabel);
    third.add(Box.createVerticalStrut(5));

    // summary text area
    summary = new JEditorPane();
    summary.setEditable(false);
    summary.setContentType("text/html");
    third.add(summary);

    // lay out pages
    setPages(new JPanel[] {first, second, third});
  }


  // -- New API methods --

  /** Associates the given raw data with the export pane. */
  public void setRawData(RawData raw) {
    this.raw = raw;
    if (raw == null) return;

    // populate dimensional sampling panel
    dimPanel.removeAll();
    String[] dims = raw.getDimStrings();
    min = new JTextField[dims.length];
    max = new JTextField[dims.length];
    step = new JTextField[dims.length];
    for (int i=0; i<dims.length; i++) {
      JPanel p = new JPanel();
      p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
      p.add(BioUtil.makeLabel("<" + (i + 1) + "> " + dims[i] + ": "));
      min[i] = BioUtil.makeField(4);
      p.add(min[i]);
      p.add(BioUtil.makeLabel(" to "));
      max[i] = BioUtil.makeField(4);
      p.add(max[i]);
      p.add(BioUtil.makeLabel(" step "));
      step[i] = BioUtil.makeField(4);
      p.add(step[i]);
      dimPanel.add(p);
    }

    // populate range component panel with checkboxes
    rangePanel.removeAll();
    int rangeCount = raw.getRangeCount();
    rangeBoxes = new JCheckBox[rangeCount];
    for (int i=0; i<rangeCount; i++) {
      char c = (char) ('1' + i);
      rangeBoxes[i] = new JCheckBox("" + c, true);
      rangeBoxes[i].setMnemonic(c);
      rangePanel.add(rangeBoxes[i]);
    }
  }

  /** Exports the data according to the current input parameters. */
  public void export() {
    final BioTask task = new BioTask();
    final int numImages = excl < 0 ? 1 : num[excl];
    final int numTotal = numFiles * numImages;
    task.addOperation("Exporting data", numTotal + numFiles);

    Thread t = new Thread(new Runnable() {
      public void run() {
        try {
          RealType[] types = raw.getTypes();
          boolean padZeroes = leadingZeroes.isSelected();
          int[] pnum = new int[stars];
          for (int i=0; i<stars; i++) pnum[i] = num[maps[i]];

          FunctionType imageType = (FunctionType) raw.getImageType();

          // purge unused range components
          MathType imageRange = imageType.getRange();
          RealType[] rt = imageRange instanceof RealTupleType ?
            ((RealTupleType) imageRange).getRealComponents() :
            new RealType[] {(RealType) imageRange};
          Vector rangeTypes = new Vector();
          for (int j=0; j<rt.length; j++) {
            if (range[j]) rangeTypes.add(rt[j]);
          }
          rt = new RealType[rangeTypes.size()];
          rangeTypes.copyInto(rt);

          if (rt.length > 1) {
            imageType = new FunctionType(imageType.getDomain(),
              new RealTupleType(rt));
          }
          else if (rt.length == 1) {
            imageType = new FunctionType(imageType.getDomain(), rt[0]);
          }
          else return;

          for (int i=0; i<numFiles; i++) {
            int[] pos = BioUtil.rasterToPosition(pnum, i);
            int[] index = new int[types.length];
            for (int j=0; j<stars; j++) {
              int q = maps[j];
              index[q] = lo[q] + st[q] * pos[j] - 1;
            }

            // construct data object
            FieldImpl data;
            if (excl < 0) {
              task.setMessage("Reading image #" + (i + 1) + "/" + numTotal);
              data = raw.getImage(index, res_x, res_y, range);
              task.advance();
            }
            else {
              FunctionType ftype = new FunctionType(types[excl], imageType);
              Linear1DSet fset = new Linear1DSet(types[excl], lo[excl],
                lo[excl] + st[excl] * (num[excl] - 1), num[excl]);
              data = new FieldImpl(ftype, fset);
              for (int j=0; j<num[excl]; j++) {
                int img = numImages * i + j + 1;
                task.setMessage("Reading image #" + img + "/" + numTotal);
                index[excl] = lo[excl] + st[excl] * j - 1;
                FlatField image = raw.getImage(index, res_x, res_y, range);
                data.setSample(j, image, false);
                task.advance();
              }
            }

            // construct filename
            StringBuffer sb = new StringBuffer();
            for (int j=0; j<stars; j++) {
              sb.append(tokens[j]);
              if (padZeroes) {
                int len = ("" + num[maps[j]]).length() -
                  ("" + (pos[j] + 1)).length();
                for (int k=0; k<len; k++) sb.append("0");
              }
              sb.append(pos[j] + 1);
            }
            sb.append(tokens[stars]);

            // save data to file
            String filename = sb.toString();
            task.setMessage("Exporting file " + filename);
            saver.save(filename, data, false);
            task.advance();
          }
          task.clear();
        }
        catch (VisADException exc) {
          task.clear();
          exc.printStackTrace();
          JOptionPane.showMessageDialog(dialog,
            "Error exporting data: " + exc.getMessage(),
            "VisBio", JOptionPane.ERROR_MESSAGE);
        }
        catch (IOException exc) {
          task.clear();
          exc.printStackTrace();
          JOptionPane.showMessageDialog(dialog,
            "Error exporting data: " + exc.getMessage(),
            "VisBio", JOptionPane.ERROR_MESSAGE);
        }
      }
    });
    t.start();
    task.showProgressDialog(dialog);
  }


  // -- DialogPane API methods --

  /** Resets the wizard pane's components to their default states. */
  public void resetComponents() {
    super.resetComponents();
    patternField.setText("");
    formatBox.setSelectedIndex(0);
  }


  // -- ActionListener API methods --

  /** Handles button press events. */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("next")) {
      if (page == 0) { // lay out page 2
        // ensure file pattern ends with appropriate format extension
        // also set visibility of "frames per second" GUI components
        String pattern = patternField.getText();
        String format = (String) formatBox.getSelectedItem();
        String plow = pattern.toLowerCase();
        if (format.equals("PIC")) {
          if (!plow.endsWith(".pic")) pattern += ".pic";
          fpsPanel.setVisible(false);
        }
        else if (format.equals("TIFF")) {
          if (!plow.endsWith(".tiff") && !plow.endsWith(".tif")) {
            pattern += ".tiff";
          }
          fpsPanel.setVisible(false);
        }
        else if (format.equals("AVI")) {
          if (!plow.endsWith(".avi")) pattern += ".avi";
          fpsPanel.setVisible(true);
        }
        else if (format.equals("MOV")) {
          if (!plow.endsWith(".mov")) pattern += ".mov";
          fpsPanel.setVisible(true);
        }
        else fpsPanel.setVisible(false);

        // parse file pattern
        StringTokenizer st = new StringTokenizer("#" + pattern + "#", "*");
        tokens = new String[st.countTokens()];
        for (int i=0; i<tokens.length; i++) {
          String t = st.nextToken();
          if (i == 0) t = t.substring(1);
          if (i == tokens.length - 1) t = t.substring(0, t.length() - 1);
          tokens[i] = t;
        }
        stars = tokens.length - 1;
        String[] dims = raw.getDimStrings();
        int q = dims.length - stars;
        if (q < 0 || q > 1) {
          JOptionPane.showMessageDialog(dialog, "Invalid number of asterisks.",
            "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }

        // set visibility of "leading zeroes" checkbox
        leadingZeroes.setVisible(stars > 0);

        // populate letter panel
        letterBoxes = new JComboBox[stars];
        String[] dimChoices = new String[dims.length];
        for (int i=0; i<dims.length; i++) {
          dimChoices[i] = "<" + (i + 1) + "> " + dims[i];
        }
        letterPanel.removeAll();
        StringBuffer sb = new StringBuffer();
        for (int i=0; i<stars; i++) {
          char letter = (char) ('A' + i);
          String s = "<" + letter + ">";
          sb.append(tokens[i]);
          sb.append(s);
          JPanel p = new JPanel();
          p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
          p.add(BioUtil.makeLabel(s + ": "));
          letterBoxes[i] = new JComboBox(dimChoices);
          letterBoxes[i].setSelectedIndex(i);
          p.add(letterBoxes[i]);
          letterPanel.add(p);
        }
        sb.append(tokens[stars]);

        // set pattern label appropriately
        patternLabel2.setText(sb.toString());

        // fill in sampling values
        imageX.setText("" + raw.getImageWidth());
        imageY.setText("" + raw.getImageHeight());

        // fill in min, max and step values
        int[] lengths = raw.getLengths();
        for (int i=0; i<lengths.length; i++) {
          min[i].setText("1");
          max[i].setText("" + lengths[i]);
          step[i].setText("1");
        }
      }
      else if (page == 1) { // lay out page 3
        String[] dims = raw.getDimStrings();
        int[] lengths = raw.getLengths();

        // extract dimensional sampling values
        lo = new int[dims.length];
        hi = new int[dims.length];
        st = new int[dims.length];
        num = new int[dims.length];
        for (int i=0; i<dims.length; i++) {
          int len = lengths[i];
          lo[i] = -1;
          hi[i] = -1;
          st[i] = -1;
          try {
            lo[i] = Integer.parseInt(min[i].getText());
            hi[i] = Integer.parseInt(max[i].getText());
            st[i] = Integer.parseInt(step[i].getText());
            num[i] = (hi[i] - lo[i] + 1) / st[i];
          }
          catch (NumberFormatException exc) { }
          if (lo[i] < 1 || lo[i] > len) {
            JOptionPane.showMessageDialog(dialog,
              "Invalid minimum value #" + (i + 1) + ".",
              "VisBio", JOptionPane.ERROR_MESSAGE);
            return;
          }
          if (hi[i] < lo[i] || hi[i] > len) {
            JOptionPane.showMessageDialog(dialog,
              "Invalid maximum value #" + (i + 1) + ".",
              "VisBio", JOptionPane.ERROR_MESSAGE);
            return;
          }
          if (st[i] < 1) {
            JOptionPane.showMessageDialog(dialog,
              "Invalid step value #" + (i + 1) + ".",
              "VisBio", JOptionPane.ERROR_MESSAGE);
            return;
          }
        }

        // file pattern
        StringBuffer sb = new StringBuffer("<html><body>\n");
        for (int i=0; i<stars; i++) {
          sb.append(tokens[i]);
          char letter = (char) ('A' + i);
          sb.append("&lt;");
          sb.append(letter);
          sb.append("&gt;");
        }
        sb.append(tokens[stars]);

        // file format
        sb.append("<br>\nFormat: ");
        String format = (String) formatBox.getSelectedItem();
        if (format.equals("PIC")) sb.append("Bio-Rad PIC");
        else if (format.equals("TIFF")) sb.append("Multi-page TIFF stack");
        else if (format.equals("AVI")) sb.append("AVI movie");
        else if (format.equals("MOV")) sb.append("QuickTime movie");
        else sb.append("Unknown");
        sb.append("\n\n");

        // dimensional mappings
        maps = new int[stars];
        if (stars > 0) {
          sb.append("<ul>\n");
          for (int i=0; i<stars; i++) {
            char letter = (char) ('A' + i);
            sb.append("<li>&lt;");
            sb.append(letter);
            sb.append("&gt; numbered across dimension: ");
            maps[i] = letterBoxes[i].getSelectedIndex();
            sb.append("&lt;");
            sb.append(maps[i] + 1);
            sb.append("&gt; ");
            sb.append(dims[maps[i]]);
            sb.append("\n");
          }
          sb.append("</ul>\n");
        }
        else sb.append("<p>\n");

        // file contents
        sb.append("Each file will contain ");
        excl = -1;
        int q = dims.length - stars;
        if (q == 0) sb.append("one image.<br>\n\n");
        else { // q == 1
          boolean[] b = new boolean[dims.length];
          for (int i=0; i<stars; i++) b[maps[i]] = true;
          int exclude = 0;
          for (int i=0; i<dims.length; i++) {
            if (!b[i]) {
              excl = i;
              exclude++;
            }
          }
          if (exclude != 1) {
            JOptionPane.showMessageDialog(dialog,
              "Please map each letter to a different dimensional axis.",
              "VisBio", JOptionPane.ERROR_MESSAGE);
            return;
          }
          int len = lengths[excl];
          if (len == 1) sb.append("one image: ");
          else {
            sb.append(num[excl]);
            sb.append(" image");
            if (num[excl] != 1) sb.append("s");
            sb.append(" across dimension: ");
          }
          sb.append("&lt;");
          sb.append(excl + 1);
          sb.append("&gt; ");
          sb.append(dims[excl]);
          sb.append("<br>\n\n");
        }

        // image resolution
        sb.append("Each image will be ");
        res_x = 0;
        res_y = 0;
        try {
          res_x = Integer.parseInt(imageX.getText());
          res_y = Integer.parseInt(imageY.getText());
        }
        catch (NumberFormatException exc) { }
        if (res_x <= 0 || res_y <= 0) {
          JOptionPane.showMessageDialog(dialog, "Invalid image resolution.",
            "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }
        sb.append(res_x);
        sb.append(" x ");
        sb.append(res_y);
        sb.append(" pixels.<p>\n\n");

        // dimensional axis samplings
        if (dims.length > 0) {
          sb.append("Dimensional axes sampled as follows:<ul>\n");
          for (int i=0; i<dims.length; i++) {
            sb.append("<li>&lt;");
            sb.append(i + 1);
            sb.append("&gt; ");
            sb.append(dims[i]);
            sb.append(": ");
            sb.append(lo[i]);
            sb.append(" to ");
            sb.append(hi[i]);
            sb.append(" step ");
            sb.append(st[i]);
            sb.append(" (");
            sb.append(num[i]);
            sb.append(" total)\n");
          }
          sb.append("</ul>\n\n");
        }

        // range components
        sb.append("Each image will contain range components:");
        int rangeCount = 0;
        range = new boolean[rangeBoxes.length];
        for (int i=0; i<rangeBoxes.length; i++) {
          range[i] = rangeBoxes[i].isSelected();
          if (range[i]) {
            sb.append(" ");
            sb.append(i + 1);
            rangeCount++;
          }
        }
        if (rangeCount == 0) {
          JOptionPane.showMessageDialog(dialog,
            "Please select at least one range component for export.",
            "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }
        else if (format.equals("PIC") && rangeCount != 1) {
          JOptionPane.showMessageDialog(dialog,
            "Please choose a single range component for Bio-Rad PIC format.",
            "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }
        else if (rangeCount != 1 && rangeCount != 3) {
          JOptionPane.showMessageDialog(dialog,
            "Please choose either one or three range components for " +
            format + " format.", "VisBio", JOptionPane.ERROR_MESSAGE);
          return;
        }

        // number of files
        boolean padZeroes = leadingZeroes.isSelected();
        sb.append("<p>First file: ");
        for (int i=0; i<stars; i++) {
          sb.append(tokens[i]);
          if (padZeroes) {
            int len = ("" + num[maps[i]]).length() - 1;
            for (int j=0; j<len; j++) sb.append("0");
          }
          sb.append("1");
        }
        sb.append(tokens[stars]);
        sb.append("<br>\nLast file: ");
        numFiles = 1;
        for (int i=0; i<stars; i++) {
          sb.append(tokens[i]);
          sb.append(num[maps[i]]);
          numFiles *= num[maps[i]];
        }
        sb.append(tokens[stars]);
        sb.append("<br>\nTotal number of files: ");
        sb.append(numFiles);
        sb.append("\n</body></html>");

        summary.setText(sb.toString());

        // crazy hack so that summary text area is sized properly
        summary.setSize(summary.getPreferredSize().width, 1);
        try  { summary.modelToView(1); }
        catch (BadLocationException exc) { exc.printStackTrace(); }
      }

      super.actionPerformed(e);
    }
    else super.actionPerformed(e);
  }

}
