//
// ThumbIndexEntry.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free
Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA
*/

package loci.visbio.data;

import java.io.*;

import loci.visbio.util.BioUtil;

import visad.FlatField;

/** A thumbnail cache index entry. */
public class ThumbIndexEntry {

  // -- Fields --

  private String pattern;
  private String[] ids;
  private int[] lengths;
  private int dim_index;
  private int[] dims;
  private int[] pos;
  private int res_x, res_y;
  private boolean[] range;
  private long offset;
  private int len;


  // -- Constructor --

  /** Constructs an uninitialized thumbnail cache index entry. */
  protected ThumbIndexEntry() { }

  /** Constructs a thumbnail cache that uses the given index and data files. */
  public ThumbIndexEntry(RawData raw, int[] pos, int res_x, int res_y,
    boolean[] range, long offset, int len)
  {
    this.pattern = raw.getPattern();
    this.ids = raw.getFilenames();
    this.lengths = raw.getLengths();
    this.dim_index = raw.getDimIndex();
    this.dims = raw.getDimTypes();
    this.pos = pos;
    this.res_x = res_x;
    this.res_y = res_y;
    this.range = range;
    this.offset = offset;
    this.len = len;
  }


  // -- API methods --

  /** Gets the index entry's offset parameter. */
  public long getOffset() { return offset; }

  /** Gets the index entry's length parameter. */
  public int getLength() { return len; }

  /** Tests whether this index entry matches the given parameters. */
  public boolean matches(RawData raw, int[] pos,
    int res_x, int res_y, boolean[] range)
  {
    return BioUtil.objectsEqual(pattern, raw.getPattern()) &&
      BioUtil.arraysEqual(ids, raw.getFilenames()) &&
      BioUtil.arraysEqual(lengths, raw.getLengths()) &&
      this.dim_index == raw.getDimIndex() &&
      BioUtil.arraysEqual(dims, raw.getDimTypes()) &&
      BioUtil.arraysEqual(this.pos, pos) && this.res_x == res_x &&
      this.res_y == res_y && BioUtil.arraysEqual(this.range, range);
  }

  /** Reads an index entry from the given input stream. */
  public static ThumbIndexEntry readEntry(BufferedReader fin) {
    RawData raw = new RawData();
    ThumbIndexEntry entry;
    try {
      entry = new ThumbIndexEntry();
      entry.pattern = fin.readLine();
      if (entry.pattern == null) return null; // eof
      entry.ids = BioUtil.readArray(entry.ids, fin);
      entry.lengths = BioUtil.readArray(entry.lengths, fin);
      entry.dim_index = Integer.parseInt(fin.readLine());
      entry.dims = BioUtil.readArray(entry.dims, fin);
      entry.pos = BioUtil.readArray(entry.pos, fin);
      entry.res_x = Integer.parseInt(fin.readLine());
      entry.res_y = Integer.parseInt(fin.readLine());
      entry.range = BioUtil.readArray(entry.range, fin);
      entry.offset = Long.parseLong(fin.readLine());
      entry.len = Integer.parseInt(fin.readLine());
    }
    catch (IOException exc) { entry = null; }
    return entry;
  }

  /** Writes this index entry to the given output stream. */
  public void writeEntry(PrintWriter fout) {
    fout.println(pattern);
    BioUtil.writeArray(ids, fout);
    BioUtil.writeArray(lengths, fout);
    fout.println(dim_index);
    BioUtil.writeArray(dims, fout);
    BioUtil.writeArray(pos, fout);
    fout.println(res_x);
    fout.println(res_y);
    BioUtil.writeArray(range, fout);
    fout.println(offset);
    fout.println(len);
  }

}
