//
// ScreenData.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.data;

import java.io.*;
import java.rmi.RemoteException;
import java.util.*;

import loci.visbio.*;
import loci.visbio.state.*;
import loci.visbio.util.BioUtil;
import visad.*;

/**
 * A ScreenData object represents a particular sampling of a
 * RawData object. The entire sampling is kept in memory in a
 * rasterized array of images.
 */
public class ScreenData implements Saveable, Dynamic {

  // -- Static fields --

  /** Disk cache for existing thumbnails. */
  protected static ThumbCache cache =
    new ThumbCache("thumbs.index", "thumbs.cache");


  // -- Input fields --

  /** Initialized sampling parameters. */
  protected ScreenDescriptor desc = new ScreenDescriptor();

  /** Latest sampling parameters. */
  protected ScreenDescriptor latest;


  // -- Computed fields (in constructor) --

  /** Number of dimensions. */
  protected int numDim;

  /** MathTypes for image stack data object. */
  protected FunctionType[] stackTypes;


  // -- Computed fields (in setSampling) --

  /**
   * Number of samples along each dimension
   * (computed from min, max and step).
   */
  protected int[] len;

  /** Number of samples along each dimension, excluding the stack axis. */
  protected int[] slen;

  /** Linear sets for use with 1-D function domains. */
  protected Linear1DSet[] sets;

  /** Number of images in total. */
  protected int numImg;


  // -- Sampled screen data --

  /** Current image. */
  protected FlatField image;

  /** Current image stack. */
  protected FieldImpl stack;

  /** Rasterized array of thumbnail images. */
  protected FlatField[] thumbs;

  /** Rasterized array of thumbnail image stacks. */
  protected FieldImpl[] thumbStacks;


  // -- Other fields --

  /** Current task. */
  protected BioTask task = new BioTask();

  /** List of data listeners. */
  protected Vector listeners = new Vector();

  /**
   * Current position within the multidimensional structure,
   * in zero-based raw dataset coordinates.
   */
  protected int[] pos;

  /** Separate thread for recomputing current image. */
  protected Thread imageThread;

  /** Separate thread for recomputing current stack. */
  protected Thread stackThread;

  /** Indicates current image is obsolete and needs to be recomputed. */
  protected boolean imageDirty;

  /** Indicates current stack is obsolete and needs to be recomputed. */
  protected boolean stackDirty;

  /** Whether to use the thumbnail disk cache when computing thumbnails. */
  protected boolean useCache = true;


  // -- Constructor --

  /** Constructs an uninitialized sampling of a dataset. */
  public ScreenData() { }

  /** Constructs a screen dataset from the given sampling parameters. */
  public ScreenData(ScreenDescriptor desc) { setSampling(desc); }


  // -- API methods: set parameters --

  /** Changes sampling parameters for the screen dataset. */
  public void setSampling(ScreenDescriptor desc) {
    latest = desc;
    initState(null);
  }

  /** Sets the current position within the multidimensional image structure. */
  public void setCurrentPos(int[] pos) throws VisADException {
    if (pos.length != numDim) throw new VisADException("bad pos array length");

    // convert screen dataset coordinates to 0-based raw dataset coordinates
    int[] p = new int[numDim];
    for (int i=0; i<numDim; i++) p[i] = pos[i] - 1; // 1-based -> 0-based

    boolean doImage = !BioUtil.arraysEqual(this.pos, p);
    boolean doStack = false;
    if (desc.stackAxis >= 0) {
      for (int i=0; i<numDim; i++) {
        if (i == desc.stackAxis) continue;
        if (this.pos[i] != p[i]) {
          doStack = true;
          break;
        }
      }
    }
    this.pos = p;
    if (doImage) makeImage();
    else notifyListeners(new DataEvent(this, DataEvent.IMAGE_COMPUTED));
    if (doStack) makeStack();
    else notifyListeners(new DataEvent(this, DataEvent.STACK_COMPUTED));
  }

  /** Sets whether to use thumbnail disk caching when computing thumbnails. */
  public void setUseCache(boolean useCache) { this.useCache = useCache; }

  /**
   * Registers a data listener, to be notified when current image
   * or current stack has been successfully recomputed.
   */
  public void addDataListener(DataListener l) {
    synchronized (listeners) { listeners.add(l); }
  }

  /** Removes a data listener. */
  public void removeDataListener(DataListener l) {
    synchronized (listeners) { listeners.remove(l); }
  }


  // -- API methods: parameter accessors --

  /** Gets descriptor describing this screen dataset's sampling. */
  public ScreenDescriptor getDescriptor() { return desc; }

  /** Gets the latest (possibly uninitialized) screen descriptor. */
  public ScreenDescriptor getLatest() { return latest; }

  /** Gets number of samples along each dimension. */
  public int[] getLengths() { return len; }

  /**
   * Returns current position within multidimensional dataset
   * (in screen dataset coordinates).
   */
  public int[] getCurrentPos() {
    // convert 0-based raw dataset coordinates to screen dataset coordinates
    int[] p = new int[numDim];
    for (int i=0; i<p.length; i++) p[i] = pos[i] + 1; // 0-based -> 1-based
    return p;
  }


  // -- API methods: data accessors --

  /** Gets the current image within the multidimensional image structure. */
  public FlatField getCurrentImage() { return image; }

  /** Gets the current stack within the multidimensional image structure. */
  public FieldImpl getCurrentStack() { return stack; }

  /** Gets whether this dataset has low-resolution thumbnails. */
  public boolean hasThumbs() { return thumbs != null; }

  /** Gets the thumbnail image at the given dimensional position. */
  public FlatField getThumbImage(int[] pos) throws VisADException {
    if (pos.length != numDim) throw new VisADException("bad pos array length");
    if (thumbs == null) return null;

    // convert screen dataset coordinates to array indices
    int[] p = new int[numDim];
    for (int i=0; i<numDim; i++) p[i] = (pos[i] - desc.min[i]) / desc.step[i];

    int j = BioUtil.positionToRaster(len, p);
    if (j < 0 || j >= thumbs.length) {
      StringBuffer sb = new StringBuffer("bad position:");
      for (int i=0; i<pos.length; i++) {
        sb.append(" ");
        sb.append(pos[i]);
      }
      throw new VisADException(sb.toString());
    }
    return thumbs[j];
  }

  /** Gets the thumbnail image stack at the given dimensional position. */
  public FieldImpl getThumbStack(int[] pos) throws VisADException {
    if (pos.length != numDim) throw new VisADException("bad pos array length");
    if (thumbs == null) return null;

    // convert screen dataset coordinates to array indices
    int axis = desc.stackAxis;
    int[] p;
    if (axis < 0) {
      p = new int[numDim];
      for (int i=0; i<numDim; i++) {
        p[i] = (pos[i] - desc.min[i]) / desc.step[i];
      }
    }
    else {
      p = new int[numDim - 1];
      int c = 0;
      for (int i=0; i<numDim; i++) {
        if (i == axis) continue;
        p[c++] = (pos[i] - desc.min[i]) / desc.step[i];
      }
    }

    int j = BioUtil.positionToRaster(slen, p);
    if (j < 0 || j >= thumbStacks.length) {
      StringBuffer sb = new StringBuffer("bad position:");
      for (int i=0; i<pos.length; i++) {
        sb.append(" ");
        sb.append(pos[i]);
      }
      throw new VisADException(sb.toString());
    }
    return thumbStacks[j];
  }

  /** Gets MathTypes used for stack construction. */
  public FunctionType[] getStackTypes() { return stackTypes; }

  /** Gets Sets used for 1-D function construction. */
  public Linear1DSet[] getSets() { return sets; }


  // -- API methods: other --

  /** Gets estimate of screen dataset memory use in bytes. */
  public long getMemoryUse() {
    int numRange = 0;
    if (len == null || desc.range == null) return 0;
    for (int i=0; i<desc.range.length; i++) if (desc.range[i]) numRange++;
    int memUse = desc.image_x * desc.image_y;
    if (desc.stackAxis >= 0) {
      memUse += desc.stack_x * desc.stack_y * len[desc.stackAxis];
    }
    memUse += desc.thumb_x * desc.thumb_y * numImg;
    memUse *= 4 * numRange;
    return memUse;
  }

  /** Gets the current task. */
  public BioTask getTask() { return task; }

  /** Gets a string representation of the screen dataset (just its name). */
  public String toString() { return desc.name; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    latest.saveState(fout);
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    latest = new ScreenDescriptor();
    latest.restoreState(fin);
  }


  // -- Dynamic API methods --

  /** Tests whether two dynamic objects have matching states. */
  public boolean matches(Dynamic dyn) {
    if (!(dyn instanceof ScreenData)) return false;
    ScreenData screen = (ScreenData) dyn;
    return latest.raw.matches(screen.latest.raw) &&
      BioUtil.objectsEqual(latest.name, screen.latest.name) &&
      BioUtil.arraysEqual(latest.min, screen.latest.min) &&
      BioUtil.arraysEqual(latest.max, screen.latest.max) &&
      BioUtil.arraysEqual(latest.step, screen.latest.step) &&
      latest.image_x == screen.latest.image_x &&
      latest.image_y == screen.latest.image_y &&
      latest.stack_x == screen.latest.stack_x &&
      latest.stack_y == screen.latest.stack_y &&
      latest.thumb_x == screen.latest.thumb_x &&
      latest.thumb_y == screen.latest.thumb_y &&
      BioUtil.arraysEqual(latest.range, screen.latest.range) &&
      latest.stackAxis == screen.latest.stackAxis;
  }

  /** Modifies this object's state to match that of the given object. */
  public void initState(Dynamic dyn) {
    if (dyn != null && dyn instanceof ScreenData) {
      ScreenData screen = (ScreenData) dyn;
      latest = screen.latest;
    }

    if (!BioUtil.objectsEqual(latest.raw, desc.raw)) {
      // recompute parameters from new raw dataset
      numDim = latest.raw.getLengths().length;
      len = new int[numDim];
      sets = new Linear1DSet[numDim];
      stackTypes = new FunctionType[numDim];

      // construct stack function types
      RealType[] types = latest.raw.getTypes();
      MathType imageType = latest.raw.getImageType();
      for (int i=0; i<numDim; i++) {
        try { stackTypes[i] = new FunctionType(types[i], imageType); }
        catch (VisADException exc) { exc.printStackTrace(); }
      }

      // invalidate old descriptor, so that everything gets recomputed
      desc = new ScreenDescriptor();
    }

    boolean doImage = false;
    boolean doStack = false;
    boolean doThumbs = false;

    if (!BioUtil.arraysEqual(latest.min, desc.min) ||
      !BioUtil.arraysEqual(latest.max, desc.max) ||
      !BioUtil.arraysEqual(latest.step, desc.step))
    {
      // compute dimension lengths
      RealType[] types = latest.raw.getTypes();
      for (int i=0; i<numDim; i++) {
        len[i] = (latest.max[i] - latest.min[i]) / latest.step[i] + 1;
        try {
          sets[i] = new Linear1DSet(types[i], latest.min[i],
            latest.min[i] + (len[i] - 1) * latest.step[i], len[i]); 
        }
        catch (VisADException exc) { exc.printStackTrace(); }
      }
      numImg = 1;
      for (int i=0; i<numDim; i++) numImg *= len[i];

      doStack = true;
      doThumbs = true;
    }

    // set image resolution
    if (latest.image_x != desc.image_x || latest.image_y != desc.image_y) {
      doImage = true;
    }

    // set stack resolution
    if (latest.stack_x != desc.stack_x || latest.stack_y != desc.stack_y) {
      doStack = true;
    }

    // set thumbnail resolution
    if (latest.thumb_x != desc.thumb_x || latest.thumb_y != desc.thumb_y) {
      doThumbs = true;
    }

    // set range
    if (!BioUtil.arraysEqual(latest.range, desc.range)) {
      doImage = true;
      doStack = true;
      doThumbs = true;
    }

    // set stack axis
    if (latest.stackAxis != desc.stackAxis) doStack = true;

    // set initial position to first image in multidimensional structure
    pos = new int[numDim];
    for (int i=0; i<numDim; i++) {
      pos[i] = latest.min[i] - 1; // 1-based -> 0-based
    }

    if (latest.stackAxis < 0) doStack = false;

    if (doImage) task.addOperation("Loading current image", 1);
    if (doStack) {
      task.addOperation("Loading current stack", len[latest.stackAxis]);
    }
    if (doThumbs && latest.thumb_x > 0 && latest.thumb_y > 0) {
      task.addOperation("Loading thumbnails", numImg);
    }

    desc = latest;
    try {
      if (doImage) image = doImage(true);
      if (doStack) stack = doStack(true);
      if (doThumbs) doThumbs();
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (IOException exc) { exc.printStackTrace(); }

    task.clear();
  }

  /**
   * Called when this object is being discarded in favor of
   * another object with a matching state.
   */
  public void discard() {
    if (this == null) System.out.println("WHAT THE FUCK!!");
    task.clear();
  }


  // -- Helper methods --

  /** Creates a multidimensional function object. */
  protected FieldImpl makeField(int index, FunctionType[] ftypes)
    throws VisADException, RemoteException
  {
    FieldImpl field = new FieldImpl(ftypes[index], sets[index]);
    if (index < ftypes.length - 1) {
      for (int i=0; i<len[index]; i++) {
        field.setSample(i, makeField(index + 1, ftypes), false);
      }
    }
    return field;
  }

  /**
   * Creates current image data object in a separate thread.
   * If this method is called a second time before the image is
   * finished being computed the first time, it aborts the first
   * computation to begin the second one.
   */
  protected void makeImage() {
    imageDirty = true;
    final ScreenData screen = this;
    if (imageThread == null) {
      imageThread = new Thread(new Runnable() {
        public void run() {
          FlatField ff = null;
          while (imageDirty) {
            imageDirty = false;
            try { ff = doImage(false); }
            catch (VisADException exc) { exc.printStackTrace(); }
            catch (IOException exc) { exc.printStackTrace(); }
          }
          imageThread = null;
          image = ff;
          notifyListeners(new DataEvent(screen, DataEvent.IMAGE_COMPUTED));
        }
      });
      imageThread.setPriority(Thread.MIN_PRIORITY);
      imageThread.start();
    }
  }

  /**
   * Creates current stack data object in a separate thread.
   * If this method is called a second time before the stack is
   * finished being computed the first time, it aborts the first
   * computation to begin the second one.
   */
  protected void makeStack() {
    if (desc.stackAxis < 0) {
      stack = null;
      return;
    }
    stackDirty = true;
    final ScreenData screen = this;
    if (stackThread == null) {
      stackThread = new Thread(new Runnable() {
        public void run() {
          FieldImpl f = null;
          while (stackDirty) {
            stackDirty = false;
            try { f = doStack(false); }
            catch (VisADException exc) { exc.printStackTrace(); }
            catch (IOException exc) { exc.printStackTrace(); }
          }
          stackThread = null;
          stack = f;
          notifyListeners(new DataEvent(screen, DataEvent.STACK_COMPUTED));
        }
      });
      stackThread.setPriority(Thread.MIN_PRIORITY);
      stackThread.start();
    }
  }

  /** Creates current image by loading data from disk. */
  protected FlatField doImage(boolean doTask)
    throws VisADException, IOException
  {
    if (imageDirty) return null;
    FlatField ff = desc.raw.getImage(pos,
      desc.image_x, desc.image_y, desc.range);
    if (doTask) task.advance();
    return ff;
  }

  /** Creates current stack by loading data from disk. */
  protected FieldImpl doStack(boolean doTask)
    throws VisADException, IOException
  {
    int axis = desc.stackAxis;
    FieldImpl f = new FieldImpl(stackTypes[axis], sets[axis]);
    int[] ndx = new int[numDim];
    System.arraycopy(pos, 0, ndx, 0, numDim);
    ndx[axis] = desc.min[axis] - 1; // 1-base -> 0-base
    for (int i=0; i<len[axis]; i++) {
      if (stackDirty) return null;
      if (doTask) {
        task.setMessage("Loading current stack (" +
          (i + 1) + "/" + len[axis] + ")");
      }
      FlatField ff = desc.raw.getImage(ndx,
        desc.stack_x, desc.stack_y, desc.range);
      f.setSample(i, ff, false);
      ndx[axis] += desc.step[axis];
      if (doTask) task.advance();
    }
    return f;
  }

  /** Creates thumbnails by loading data from disk. */
  protected void doThumbs() throws VisADException, IOException {
    if (desc.thumb_x > 0 && desc.thumb_y > 0) {
      // load data
      thumbs = new FlatField[numImg];
      int axis = desc.stackAxis;
      if (axis >= 0) {
        slen = stripAxis(len, axis);
        int numStk = numImg / len[axis];
        thumbStacks = new FieldImpl[numStk];
        for (int j=0; j<numStk; j++) {
          thumbStacks[j] = new FieldImpl(stackTypes[axis], sets[axis]);
        }
      }
      else {
        slen = len;
        thumbStacks = thumbs;
      }

      String op = "Loading";
      for (int j=0; j<numImg; j++) {
        String paren = "(" + (j + 1) + "/" + numImg + ")";
        task.setMessage(op + " thumbnails " + paren);
        int[] ndx = BioUtil.rasterToPosition(len, j);

        // convert array indices to 0-base dataset coordinates
        int[] p = new int[numDim];
        for (int i=0; i<numDim; i++) {
          p[i] = desc.min[i] + desc.step[i] * ndx[i] - 1;
        }

        // try to restore the thumbnail from the cache
        thumbs[j] = cache.retrieveThumb(desc.raw,
          p, desc.thumb_x, desc.thumb_y, desc.range);

        if (thumbs[j] == null) {
          // cache is empty; compute thumbnail from dataset on disk
          thumbs[j] = desc.raw.getImage(p,
            desc.thumb_x, desc.thumb_y, desc.range);

          if (useCache) {
            // store newly computed thumbnail in the cache
            op = "Caching";
            cache.storeThumb(thumbs[j], desc.raw,
              p, desc.thumb_x, desc.thumb_y, desc.range);
          }
        }
        else op = "Loading";

        if (axis >= 0) {
          // populate proper thumbnail stack object
          int[] sndx = stripAxis(ndx, axis);
          int k = BioUtil.positionToRaster(slen, sndx);
          thumbStacks[k].setSample(ndx[axis], thumbs[j], false);
        }

        task.advance();
      }
    }
    else thumbs = null;
  }

  /** Notifies data listeners of the given data event. */
  protected void notifyListeners(DataEvent evt) {
    DataListener[] dl;
    synchronized (listeners) {
      dl = new DataListener[listeners.size()];
      listeners.copyInto(dl);
    }
    for (int i=0; i<dl.length; i++) dl[i].dataComputed(evt);
  }


  // -- Utility methods --

  /** Gets the thumbnail disk cache object. */
  public static ThumbCache getThumbCache() { return cache; }

  /**
   * Strips the given axis from the given dimensional
   * position or lengths array.
   */
  public static int[] stripAxis(int[] a, int axis) {
    if (axis < 0 || axis >= a.length) return a;
    else {
      int[] aa = new int[a.length - 1];
      System.arraycopy(a, 0, aa, 0, axis);
      System.arraycopy(a, axis + 1, aa, axis, a.length - axis - 1);
      return aa;
    }
  }

}
