//
// OptionManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.state;

import java.awt.Component;
import java.io.*;
import java.util.Vector;

import javax.swing.*;

import loci.visbio.*;
import loci.visbio.util.WarningPane;

/** OptionManager is the class encapsulating VisBio's options. */
public class OptionManager extends LogicManager {

  // -- Constants --

  /** Configuration file for storing VisBio options. */
  private static final String CONFIG_FILE = "visbio.ini";

  /** String for status bar visibility option. */
  private static final String STATUS_BAR = "Status bar";


  // -- Fields --

  /** Option pane. */
  private OptionPane options;

  /** List of options. */
  private Vector list;


  // -- Constructor --

  /** Constructs an options manager. */
  public OptionManager(VisBio biovis) {
    super(biovis);
    options = new OptionPane(this);
    list = new Vector();
  }


  // -- New API methods --

  /** Adds an option to VisBio's options dialog. */
  public void addBooleanOption(String tab, String text,
    char mnemonic, String tip, boolean value)
  {
    BooleanOption option = new BooleanOption(text, mnemonic, tip, value);
    options.addOption(tab, option);
    list.add(option);
    bio.generateEvent(this, "add option", false);
  }

  /** Adds an option allowing the user to enter a numerical value. */
  public void addNumericOption(String tab, String text,
    char mnemonic, String unit, String tip, int value)
  {
    NumericOption option = new NumericOption(text, mnemonic, unit, tip, value);
    options.addOption(tab, option);
    list.add(option);
    bio.generateEvent(this, "add option", false);
  }

  /**
   * Adds a custom GUI component to VisBio's options dialog.
   * Such options will not be saved in the INI file automatically.
   */
  public void addCustomOption(String tab, Component c) {
    CustomOption option = new CustomOption(c);
    options.addOption(tab, option);
    bio.generateEvent(this, "add option", false);
  }

  /** Gets the VisBio option with the given text. */
  public BioOption getOption(String text) {
    for (int i=0; i<list.size(); i++) {
      BioOption option = (BioOption) list.elementAt(i);
      if (option.getText().equals(text)) return option;
    }
    return null;
  }

  /** Reads in configuration from configuration file. */
  public void readIni() {
    File ini = new File(CONFIG_FILE);
    if (!ini.exists()) { }
    try {
      BufferedReader fin = new BufferedReader(new FileReader(ini));
      try { restoreState(fin); }
      catch (SaveException exc) { exc.printStackTrace(); }
      fin.close();
      bio.generateEvent(this, "read ini file", false);
    }
    catch (IOException exc) { exc.printStackTrace(); }
  }

  /** Writes out configuration to configuration file. */
  public void writeIni() {
    try {
      PrintWriter fout = new PrintWriter(new FileWriter(CONFIG_FILE));
      saveState(fout);
      fout.close();
    }
    catch (IOException exc) { exc.printStackTrace(); }
    catch (SaveException exc) { exc.printStackTrace(); }
  }

  /** Checks whether to display a warning, and does so if necessary. */
  public boolean checkWarning(String warn, boolean allowCancel, String text) {
    BioOption option = getOption(warn);
    if (!(option instanceof BooleanOption)) return true;
    BooleanOption b = (BooleanOption) option;
    if (!b.getValue()) return true;
    JCheckBox box = (JCheckBox) b.getComponent();
    WarningPane pane = new WarningPane(text, this, box, allowCancel);
    return pane.showDialog(bio) == WarningPane.APPROVE_OPTION;
  }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
      else if (lm instanceof ExitManager) {
        // hack so that options menu item appears in the proper location
        if (!VisBio.MAC_OS_X) {
          // file menu
          bio.addMenuSeparator("File");
          bio.addMenuItem("File", "Options...",
            "loci.visbio.state.OptionManager.fileOptions", 'o',
            "Configures VisBio");
        }
      }
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof OptionManager) {
        OptionManager om = (OptionManager) lm;
        BooleanOption option = (BooleanOption) om.getOption(STATUS_BAR);
        bio.setStatusVisible(option.getValue());
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 1; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    for (int i=0; i<list.size(); i++) {
      BioOption option = (BioOption) list.elementAt(i);
      fout.println(option.toString());
    }
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    while (true) {
      // parse configuration file line
      String line;
      try { line = fin.readLine(); }
      catch (IOException exc) { throw new SaveException(exc); }
      if (line == null) break;
      line = line.trim();
      if (line.equals("")) break;
      int eq = line.indexOf("=");
      if (eq < 0) continue;
      String var = line.substring(0, eq).trim();
      String expr = line.substring(eq + 1).trim();

      // search for matching option
      BioOption option = getOption(var);
      if (option == null) continue;

      // found match--set state appropriately
      option.setValue(expr);
    }
  }


  // -- Helper methods --

  /** Adds options-related GUI components to VisBio. */
  private void doGUI() {
    // options menu
    bio.setStatus("Initializing options logic");
    addBooleanOption("General", STATUS_BAR, 's',
      "Toggles visibility of the VisBio status bar", true);
  }


  // -- Menu commands --

  /** Brings up the options dialog box. */
  public void fileOptions() {
    readIni();
    int rval = options.showDialog(bio);
    if (rval == OptionPane.APPROVE_OPTION) writeIni();
    else readIni();
    bio.generateEvent(this, "tweak options", true);
  }

}
