//
// BioTask.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.state;

import java.awt.*;
import java.util.Vector;

import loci.visbio.util.ProgressDialog;

import visad.util.Util;

/** BioTask represents a time-consuming task, such as loading data. */
public class BioTask {

  // -- Fields --

  /** Descriptive message for each operation in the task. */
  private Vector messages;

  /** Number of ticks for each operation in the task. */
  private Vector numTicks;

  /** Total number of ticks for the task. */
  private int totalTicks;

  /** Current tick. */
  private int tick;

  /** Current operation index. */
  private int op;

  /** Current task message. */
  private String msg;

  /** Progress dialog associated with the task. */
  private ProgressDialog dialog;

  /** List of task event listeners. */
  private Vector listeners;


  // -- Constructor --

  /** Constructs a new task. */
  public BioTask() {
    messages = new Vector();
    numTicks = new Vector();
    msg = "";
    listeners = new Vector();
  }


  // -- API methods for driving the task --

  /**
   * Adds an operation to the task with the given descriptive message,
   * taking the given number of ticks to complete.
   */
  public synchronized void addOperation(String msg, int ticks) {
    messages.add(msg);
    totalTicks += ticks;
    numTicks.add(new Integer(totalTicks));
    notifyListeners(new TaskEvent(this, TaskEvent.OPERATION_ADDED));
  }

  /** Advances the task by one tick. */
  public synchronized void advance() {
    tick++;
    final BioTask task = this;
    final boolean nextop =
      tick == ((Integer) numTicks.elementAt(op)).intValue();
    if (nextop) {
      op++; // next operation
      msg = messages.size() > op ?
        (String) messages.elementAt(op) : "Finishing";
      notifyListeners(new TaskEvent(this, TaskEvent.MESSAGE_CHANGED));
    }
    if (dialog != null) {
      Util.invoke(true, new Runnable() {
        public void run() {
          if (nextop) dialog.setText(msg);
          dialog.setPercent((int) task.getPercent());
        }
      });
    }
    notifyListeners(new TaskEvent(this, TaskEvent.TASK_ADVANCED));
  }

  /** Overrides the default operation's message with the given one. */
  public synchronized void setMessage(String message) {
    msg = message;
    if (dialog != null) {
      Util.invoke(true, new Runnable() {
        public void run() { dialog.setText(msg); }
      });
    }
    notifyListeners(new TaskEvent(this, TaskEvent.MESSAGE_CHANGED));
  }

  /** Resets the task to empty. */
  public synchronized void clear() {
    messages.removeAllElements();
    numTicks.removeAllElements();
    totalTicks = 0;
    tick = 0;
    op = 0;
    msg = "";
    if (dialog != null) {
      Util.invoke(true, new Runnable() {
        public void run() {
          ProgressDialog pd = dialog;
          dialog = null;
          pd.kill();
        }
      });
    }
    notifyListeners(new TaskEvent(this, TaskEvent.TASK_CLEARED));
  }


  // -- API methods task event notification --

  /** Adds a task listener to those informed of task events. */
  public void addListener(TaskListener l) {
    synchronized (listeners) { listeners.add(l); }
  }

  /** Removes a task listener from those informed of task events. */
  public void removeListener(TaskListener l) {
    synchronized (listeners) { listeners.remove(l); }
  }

  /** Clears the list of task listeners informed of task events. */
  public void removeAllListeners() {
    synchronized (listeners) { listeners.removeAllElements(); }
  }

  /** Notifies all task listeners of the given task event. */
  protected void notifyListeners(TaskEvent e) {
    synchronized (listeners) {
      int size = listeners.size();
      for (int i=0; i<size; i++) {
        TaskListener l = (TaskListener) listeners.elementAt(i);
        l.taskUpdated(e);
      }
    }
  }


  // -- API methods for displaying task status onscreen --

  /** Displays a progress dialog indicating current task operations. */
  public void showProgressDialog(Frame parent) {
    synchronized (this) {
      if (tick > 0 && tick == totalTicks) return; // task already complete
      dialog = new ProgressDialog(parent, "Working");
      dialog.setPercent(0);
    }
    if (dialog != null) dialog.show();
  }

  /** Displays a progress dialog indicating current task operations. */
  public void showProgressDialog(Dialog parent) {
    synchronized (this) {
      if (tick > 0 && tick == totalTicks) return; // task already complete
      dialog = new ProgressDialog(parent, "Working");
      dialog.setPercent(0);
    }
    if (dialog != null) dialog.show();
  }


  // -- API methods for querying the task --

  /** Gets the default message describing current task operations. */
  public String getMessage() { return msg; }

  /** Gets the percentage complete for the current task. */
  public double getPercent() {
    return totalTicks > 1 ? 100.0 * tick / (totalTicks - 1) : -1;
  }

  /** Gets whether the current task is empty. */
  public boolean isClear() { return totalTicks == 0; }

  /** Gets the total number of ticks for the task. */
  public int getNumberOfTicks() { return totalTicks; }

  /** Gets the task's current tick. */
  public int getTick() { return tick; }

}
