//
// MultiTask.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.state;

import java.awt.*;

import loci.visbio.util.ProgressDialog;

import visad.util.Util;

/** MultiTask represents a collection of time-consuming tasks. */
public class MultiTask implements TaskListener {

  // -- Fields --

  /** Collection of tasks. */
  private BioTask[] tasks;

  /** Number of tasks cleared. */
  private int numClear;

  /** Progress dialog associated with the tasks. */
  private ProgressDialog dialog;

  /** Synchronization object to indicate dialog blocking is complete. */
  private Object doneSync;

  private boolean done;


  // -- Constructor --

  /** Constructs a new collection of tasks. */
  public MultiTask(BioTask[] tasks) {
    this.tasks = tasks;
    for (int i=0; i<tasks.length; i++) tasks[i].addListener(this);
    doneSync = new Object();
  }


  // -- TaskListener API methods --

  /** Called when a BioTask object is updated in some way. */
  public synchronized void taskUpdated(TaskEvent e) {
    final BioTask task = (BioTask) e.getSource();
    int evt = e.getEventType();
    if (evt == TaskEvent.TASK_ADVANCED) {
      notifyAll(); // allow dialog to pop up
      if (dialog != null) {
        Util.invoke(true, new Runnable() {
          public void run() {
            int percent = (int)
              ((100 * numClear + task.getPercent()) / tasks.length);
            dialog.setPercent(percent);
          }
        });
      }
    }
    else if (evt == TaskEvent.MESSAGE_CHANGED) {
      notifyAll(); // allow dialog to pop up
      if (dialog != null) {
        final String msg = task.getMessage();
        Util.invoke(true, new Runnable() {
          public void run() { dialog.setText(msg); }
        });
      }
    }
    else if (evt == TaskEvent.TASK_CLEARED) {
      numClear++;
      if (numClear == tasks.length) {
        // all tasks are complete; abort dialog pop-up
        notifyAll();
        if (dialog != null) {
          Util.invoke(true, new Runnable() {
            public void run() {
              ProgressDialog pd = dialog;
              dialog = null;
              pd.kill();
            }
          });
        }
      }
    }
  }


  // -- API methods for driving the task --

  /** Resets the task to empty. */
  public void clear() {
    synchronized (doneSync) {
      doneSync.notifyAll();
      done = true;
    }
  }


  // -- API methods for displaying task status onscreen --

  /** Displays a progress dialog indicating current task operations. */
  public void showProgressDialog(Frame parent) {
    synchronized (this) {
      if (numClear < tasks.length) {
        // wait for first task update before popping up the dialog
        try { wait(); }
        catch (InterruptedException exc) { exc.printStackTrace(); }
        if (numClear < tasks.length) {
          dialog = new ProgressDialog(parent, "Working");
          dialog.setPercent(0);
        }
      }
    }
    if (dialog != null) dialog.show();
    // wait until clear() has been called
    synchronized (doneSync) {
      if (!done) {
        try { doneSync.wait(); }
        catch (InterruptedException exc) { exc.printStackTrace(); }
      }
    }
  }

  /** Displays a progress dialog indicating current task operations. */
  public void showProgressDialog(Dialog parent) {
    synchronized (this) {
      if (numClear < tasks.length) {
        // wait for first task update before popping up the dialog
        try { wait(); }
        catch (InterruptedException exc) { exc.printStackTrace(); }
        if (numClear < tasks.length) {
          dialog = new ProgressDialog(parent, "Working");
          dialog.setPercent(0);
        }
      }
    }
    if (dialog != null) dialog.show();
    // wait until clear() is called
    synchronized (doneSync) {
      if (!done) {
        try { doneSync.wait(); }
        catch (InterruptedException exc) { exc.printStackTrace(); }
      }
    }
  }

}
