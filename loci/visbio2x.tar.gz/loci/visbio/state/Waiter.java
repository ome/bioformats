//
// Waiter.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.state;

import java.awt.*;

import loci.visbio.util.ProgressDialog;

import visad.*;

/**
 * A progress dialog that is displayed while
 * VisAD displays perform data transforms.
 */
public class Waiter extends ProgressDialog implements DisplayListener {

  // -- Fields --

  /** Number of TRANSFORM_DONE events to wait for. */
  private int wait;


  // -- Constructor --

  /** Constructs a waiter object tied to the given frame. */
  public Waiter(Frame f) { super(f, "Please wait"); }

  /** Constructs a waiter object tied to the given dialog. */
  public Waiter(Dialog d) { super(d, "Please wait"); }


  // -- API methods --

  /** Initializes the waiter. */
  public void init(String msg) {
    live = true;
    wait = 0;
    setText(msg);
  }

  /**
   * Adds a display to the list of displays that
   * will be generating TRANSFORM_DONE events.
   */
  public void addDisplay(DisplayImpl d) {
    d.addDisplayListener(this);
    wait++;
  }


  // -- DisplayListener API methods --

  /** Called to notify the display listener of a display event. */
  public void displayChanged(DisplayEvent e) {
    int id = e.getId();
    if (id == DisplayEvent.TRANSFORM_DONE) {
      if (wait > 0) {
        wait--;
        if (wait == 0) kill();
      }
      DisplayImpl d = (DisplayImpl) e.getDisplay();
      d.removeDisplayListener(this);
    }
  }

}
