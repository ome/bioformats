//
// MeasureList.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.*;
import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

import loci.visbio.VisBio;
import loci.visbio.data.*;
import loci.visbio.state.*;
import loci.visbio.util.*;
import loci.visbio.view.ViewManager;

import visad.*;

/**
 * MeasureList represents measurements corresponding to
 * a particular screen dataset.
 */
public class MeasureList implements Saveable, Dynamic {

  // -- Fields --

  /** Name of the group. */
  private MeasureManager mm;

  /** Screen dataset to which this measurement list corresponds. */
  private ScreenData screen;

  /** List of measurement points. */
  private Vector points;

  /** List of measurement flags. */
  private Vector flags;

  /** List of measurement lines. */
  private Vector lines;

  /** Whether measurements automatically snap to closest slice. */
  private boolean snap;

  /** First free id number for standard measurements. */
  private int maxSID;

  /** Whether next measurement action will perform a merge. */
  private boolean merge;


  // -- Fields: derived from screen dataset --

  /** Real types composing measurement domain. */
  private RealType[] types;

  /** 2-D domain for measurements. */
  private RealTupleType domain2;

  /** 3-D domain for measurements. */
  private RealTupleType domain3;

  /** Current position within multidimensional structure. */
  private int[] pos;

  /** Positional index for Z-stack. */
  private int stackAxis;


  // -- Constructor --

  /** Constructs a measurement list. */
  public MeasureList(MeasureManager mm, ScreenData screen) {
    this.mm = mm;
    this.screen = screen;
    points = new Vector();
    flags = new Vector();
    lines = new Vector();
    snap = true;
    merge = false;
    maxSID = -1;

    types = new RealType[3];
    ScreenDescriptor desc = screen.getDescriptor();
    FunctionType imageType = (FunctionType) desc.raw.getImageType();
    RealType[] imageTypes = imageType.getDomain().getRealComponents();
    types[0] = imageTypes[0];
    types[1] = imageTypes[1];
    stackAxis = desc.stackAxis;
    types[2] = stackAxis >= 0 ?
      desc.raw.getTypes()[stackAxis] : RealType.getRealType("bio_z_axis");
    try {
      domain2 = new RealTupleType(types[0], types[1]);
      domain3 = new RealTupleType(types[0], types[1], types[2]);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    pos = screen.getCurrentPos();
  }


  // -- API methods: mutators --

  /** Sets position within multidimensional structure. */
  public void setPos(int[] pos) {
    this.pos = pos;
    mm.refreshPools(true);
  }

  /** Adds a new line. */
  public void addLine() {
    double[] e1, e2;
    VisBio bio = mm.getVisBio();
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    DisplayImpl display2 = vm.getDisplay2D();
    if (display2.getComponent().isVisible()) {
      Dimension d = display2.getComponent().getSize();
      e1 = BioUtil.pixelToDomain(display2, 0, 0);
      e2 = BioUtil.pixelToDomain(display2, d.width, d.height);
    }
    else {
      e1 = new double[] {0, 0};
      e2 = new double[] {getResX(), getResY()};
    }

    // generate random acceptable endpoint start locations;
    // endpoints bisect a circle on the given Z-slice value
    double cx = (e1[0] + e2[0]) / 2;
    double cy = (e1[1] + e2[1]) / 2;
    double rx = Math.abs(e2[0] - cx);
    double ry = Math.abs(e2[1] - cy);
    double r = 0.75 * (rx < ry ? rx : ry);
    double theta = 2 * Math.PI * Math.random();
    double inc = Math.PI;
    double t1 = theta;
    double x1 = r * Math.cos(t1) + cx;
    double y1 = r * Math.sin(t1) + cy;
    double t2 = theta + Math.PI;
    double x2 = r * Math.cos(t2) + cx;
    double y2 = r * Math.sin(t2) + cy;
    double[] dpos = new double[pos.length];
    for (int i=0; i<pos.length; i++) dpos[i] = pos[i];

    // create two new endpoints and link them
    MeasureGroup none = mm.getNoneGroup();
    MeasurePoint ep1 = new MeasurePoint(x1, y1, dpos, Color.white, none);
    MeasurePoint ep2 = new MeasurePoint(x2, y2, dpos, Color.white, none);
    MeasureLine line = new MeasureLine(ep1, ep2, Color.white, none, false);
    addLine(line);
  }

  /** Adds the specified line. */
  public void addLine(MeasureLine line) { addLine(line, true); }

  /** Adds the specified line. */
  public void addLine(MeasureLine line, boolean refresh) {
    if (!points.contains(line.ep1)) points.add(line.ep1);
    if (!points.contains(line.ep2)) points.add(line.ep2);
    lines.add(line);
    if (refresh) mm.refreshPools(false);
  }

  /** Adds a new marker. */
  public void addMarker() {
    // generate random acceptable endpoint start location
    // endpoint lies within central 75% of display
    VisBio bio = mm.getVisBio();
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    DisplayImpl display2 = vm.getDisplay2D();
    Dimension size = display2.getComponent().getSize();
    double[] e1 = BioUtil.pixelToDomain(display2, 0, 0);
    double[] e2 = BioUtil.pixelToDomain(display2, size.width, size.height);
    double w = 0.75 * (e2[0] - e1[0]);
    double h = 0.75 * (e2[1] - e1[1]);
    double cx = (e1[0] + e2[0]) / 2;
    double cy = (e1[1] + e2[1]) / 2;
    double x = cx + w * (Math.random() - 0.5);
    double y = cy + h * (Math.random() - 0.5);
    double[] dpos = new double[pos.length];
    for (int i=0; i<pos.length; i++) dpos[i] = pos[i];

    // create one new endpoint
    MeasurePoint point = new MeasurePoint(x, y, dpos,
      Color.white, mm.getNoneGroup());
    addMarker(point);
  }

  /** Adds the specified marker. */
  public void addMarker(MeasurePoint point) { addMarker(point, true); }

  /** Adds the specified marker. */
  public void addMarker(MeasurePoint point, boolean refresh) {
    points.add(point);
    if (refresh) mm.refreshPools(false);
  }

  /** Adds a new flag. */
  public void addFlag() {
    // generate random acceptable endpoint start location
    // endpoint lies within central 75% of display
    VisBio bio = mm.getVisBio();
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    DisplayImpl display2 = vm.getDisplay2D();
    Dimension size = display2.getComponent().getSize();
    double[] e1 = BioUtil.pixelToDomain(display2, 0, 0);
    double[] e2 = BioUtil.pixelToDomain(display2, size.width, size.height);
    double w = 0.75 * (e2[0] - e1[0]);
    double h = 0.75 * (e2[1] - e1[1]);
    double cx = (e1[0] + e2[0]) / 2;
    double cy = (e1[1] + e2[1]) / 2;
    double x = cx + w * (Math.random() - 0.5);
    double y = cy + h * (Math.random() - 0.5);
    double[] dpos = new double[pos.length];
    for (int i=0; i<pos.length; i++) dpos[i] = pos[i];

    // create one new endpoint
    MeasureFlag flag = new MeasureFlag(x, y, Color.white, mm.getNoneGroup());
    addFlag(flag);
  }
  public void addFlag(MeasureFlag flag) { addFlag(flag, true); }
  public void addFlag(MeasureFlag flag, boolean refresh) {
    flags.add(flag);
    if (refresh) mm.refreshPools(false);
  }

  /** Removes the specified line. */
  public void removeLine(MeasureLine line) { removeLine(line, true); }

  /** Removes the specified line. */
  public void removeLine(MeasureLine line, boolean refresh) {
    if (!lines.contains(line)) return;
    remove(line);
    if (refresh) mm.refreshPools(true);
  }

  /** Removes the specified marker. */
  public void removeMarker(MeasurePoint point) { removeMarker(point, true); }

  /** Removes the specified marker. */
  public void removeMarker(MeasurePoint point, boolean refresh) {
    if (!points.contains(point)) return;
    remove(point);
    if (refresh) mm.refreshPools(true);
  }

  /** Removes selected measurements. */
  public void removeSelected() { remove(false); }

  /** Removes all measurements. */
  public void removeAll() { remove(true); }

  /** Exports measurements to the given file. */
  public void export(File file) {
    PrintWriter fout;
    try { fout = new PrintWriter(new FileWriter(file)); }
    catch (IOException exc) {
      JOptionPane.showMessageDialog(mm.getVisBio(),
        "Could not export measurements: " + exc.getMessage(),
        "VisBio", JOptionPane.ERROR_MESSAGE);
      return;
    }

    // compile table headers
    ScreenDescriptor desc = screen.getDescriptor();
    RawData raw = desc.raw;
    String[] dimStr = raw.getDimStrings();
    int stackAxis = desc.stackAxis;
    String pos = "";
    for (int i=0; i<dimStr.length; i++) {
      if (i != stackAxis) pos = pos + dimStr[i] + " (" + (i + 1) + ")\t";
    }
    String xy = "x\ty\t";
    String xy1 = "x1\ty1\t";
    String xy2 = "x2\ty2\t";
    String ztype = "", ztype1 = "", ztype2 = "";
    if (stackAxis >= 0) {
      String s = " (" + dimStr[stackAxis] + ")\t";
      ztype = "z" + s;
      ztype1 = "z1" + s;
      ztype2 = "z2" + s;
    }
    String dist = "dist\t";
    String stuff = "red\tgreen\tblue\tgroup_id";
    String lhead2d = pos + xy1 + xy2 + ztype + dist + stuff;
    String lhead = pos + xy1 + ztype1 + xy2 + ztype2 + dist + stuff;
    String phead = pos + xy + ztype + stuff;
    String fhead = xy + stuff;

    // compute measurement unit info
    double mx = 1, my = 1, sd = 1;
    String unit = "pixels";
    boolean use = mm.isUsingMicrons();
    double mw = mm.getMicronWidth();
    double mh = mm.getMicronHeight();
    double z = mm.getSliceDistance();
    int res_x = mm.getResX();
    int res_y = mm.getResY();
    double x = mw / res_x;
    double y = mh / res_y;
    if (use && x == x && y == y && z == z) {
      mx = x;
      my = y;
      sd = z;
      unit = "microns";
    }

    // compile standard measurement lists
    Vector[] std = new Vector[maxSID >= 0 ? maxSID : 0];
    for (int i=0; i<maxSID; i++) std[i] = new Vector();
    Vector lnon = new Vector();
    Vector pnon = new Vector();
    int lsize = lines.size();
    int psize = points.size();
    for (int i=0; i<lsize; i++) {
      MeasureLine line = (MeasureLine) lines.elementAt(i);
      if (line.stdId < 0) lnon.add(line);
      else std[line.stdId].add(line);
    }
    for (int i=0; i<psize; i++) {
      MeasurePoint point = (MeasurePoint) points.elementAt(i);
      if (point.lines.size() > 0) continue;
      if (point.stdId < 0) pnon.add(point);
      else std[point.stdId].add(point);
    }

    // output measurement unit header
    fout.println("Unit = " + unit);
    fout.println();

    // output measurement group list
    fout.println("[groups]");
    fout.println("group_id\tname\tdescription");
    Vector groups = mm.getMeasureGroups();
    int gsize = groups.size();
    for (int i=0; i<gsize; i++) {
      MeasureGroup group = (MeasureGroup) groups.elementAt(i);
      fout.print(group.getId());
      fout.print("\t");
      fout.print(group.getName());
      fout.print("\t");
      StringTokenizer st = new StringTokenizer(group.getDescription());
      if (st.hasMoreTokens()) fout.print(st.nextToken());
      while (st.hasMoreTokens()) fout.print("|" + st.nextToken());
      fout.println();
    }
    fout.println();

    // output standard measurement lists
    for (int i=0; i<maxSID; i++) {
      int size = std[i].size();
      if (size == 0) continue;

      // determine standard type from first element
      MeasureThing first = (MeasureThing) std[i].elementAt(0);
      boolean std2d = first.stdType == MeasureManager.STD_2D;
      fout.println("[standard #" + (i + 1) + ": " +
        (std2d ? "2-D" : "3-D") + "]");

      // output appropriate header
      if (first instanceof MeasurePoint) fout.println(phead);
      else if (std2d) fout.println(lhead2d);
      else fout.println(lhead);

      // output table entries
      for (int j=0; j<size; j++) {
        MeasureThing thing = (MeasureThing) std[i].elementAt(j);
        export(fout, thing, std2d, stackAxis, mx, my, sd);
      }
      fout.println();
    }

    // output other measurement lines
    int lnonsize = lnon.size();
    if (lnonsize > 0) {
      fout.println("[other lines]");
      fout.println(lhead);
      for (int i=0; i<lnonsize; i++) {
        MeasureThing thing = (MeasureThing) lnon.elementAt(i);
        export(fout, thing, false, stackAxis, mx, my, sd);
      }
      fout.println();
    }

    // output other measurement markers
    int pnonsize = pnon.size();
    if (pnonsize > 0) {
      fout.println("[other markers]");
      fout.println(phead);
      for (int i=0; i<pnonsize; i++) {
        MeasureThing thing = (MeasureThing) pnon.elementAt(i);
        export(fout, thing, false, stackAxis, mx, my, sd);
      }
      fout.println();
    }

    // output measurement flags
    int flagsize = flags.size();
    if (flagsize > 0) {
      fout.println("[flags]");
      fout.println(fhead);
      for (int i=0; i<flagsize; i++) {
        MeasureFlag flag = (MeasureFlag) flags.elementAt(i);
        export(fout, flag, false, stackAxis, mx, my, sd);
      }
      fout.println();
    }
    fout.close();
  }

  /** Snaps all measurements to closest slice. */
  public void snapNow() {
    int min = getStackMin();
    int max = getStackMax();
    int step = getStackStep();
    int size = points.size();
    for (int i=0; i<size; i++) {
      MeasurePoint point = (MeasurePoint) points.elementAt(i);
      point.pos[stackAxis] =
        BioUtil.getNearest(point.pos[stackAxis], min, max, step);
    }
    size = lines.size();
    for (int i=0; i<size; i++) {
      MeasureLine line = (MeasureLine) lines.elementAt(i);
      line.ep1.pos[stackAxis] =
        BioUtil.getNearest(line.ep1.pos[stackAxis], min, max, step);
      line.ep2.pos[stackAxis] =
        BioUtil.getNearest(line.ep2.pos[stackAxis], min, max, step);
    }
    mm.refreshPools(true);
  }

  /** Sets whether measurements automatically snap to closest slice. */
  public void setSnap(boolean snap) {
    this.snap = snap;
    if (snap) snapNow();
  }

  /** Sets the selected measurements to the given standard type. */
  public void setStandard(int stdType) {
    MeasurePool pool2 = mm.getPool2D();
    if (stdType == MeasureManager.STD_SINGLE) {
      int type = MeasureManager.STD_SINGLE;
      MeasureThing[] things = pool2.getSelection();
      for (int i=0; i<things.length; i++) {
        int q = things[i].stdType;
        if (q != MeasureManager.STD_SINGLE) {
          type = q;
          break;
        }
      }
      if (stdType == type) return; // no change
      int ans = JOptionPane.showConfirmDialog(mm.getVisBio(),
        "Are you sure?", "Unset standard", JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);
      if (ans == JOptionPane.YES_OPTION) {
        for (int i=0; i<things.length; i++) {
          doStandard(things[i], MeasureManager.STD_SINGLE);
        }
      }
      else mm.updateStandard(stdType);
    }
    else if (stdType == MeasureManager.STD_2D) {
      MeasureThing[] things = pool2.getSelection();
      for (int i=0; i<things.length; i++) {
        doStandard(things[i], MeasureManager.STD_2D);
      }
    }
    else if (stdType == MeasureManager.STD_3D) {
      MeasureThing[] things = pool2.getSelection();
      for (int i=0; i<things.length; i++) {
        doStandard(things[i], MeasureManager.STD_3D);
      }
    }
    mm.refreshPools(true);
  }

  /** Sets the color of the selected measurements. */
  public void setColor(Color color) {
    MeasureThing[] things = mm.getPool2D().getSelection();
    for (int i=0; i<things.length; i++) things[i].setColor(color);
  }

  /** Sets the group of the selected measurements. */
  public void setGroup(MeasureGroup group) {
    MeasureThing[] things = mm.getPool2D().getSelection();
    for (int i=0; i<things.length; i++) things[i].group = group;
  }

  /** Sets merge state. */
  public void setMerge(boolean merge) { this.merge = merge; }


  // -- API methods: accessors --

  /** Gets position within multidimensional structure. */
  public int[] getPos() { return pos; }

  /** Gets positional index for Z-stack. */
  public int getStackAxis() { return stackAxis; }

  /** Gets position along Z-stack. */
  public int getStackPos() { return stackAxis < 0 ? -1 : pos[stackAxis]; }

  /** Gets all lines in the list. */
  public Vector getLines() { return lines; }

  /** Gets all markers in the list. */
  public Vector getPoints() { return points; }

  /** Gets all flags in the list. */
  public Vector getFlags() { return flags; }

  /** Gets whether measurements should automatically snap to closest slice. */
  public boolean isSnap() { return snap; }

  /** Gets merge state. */
  public boolean isMerge() { return merge; }

  /** Gets X resolution of screen dataset. */
  public int getResX() { return screen.getDescriptor().raw.getImageWidth(); }

  /** Gets Y resolution of screen dataset. */
  public int getResY() { return screen.getDescriptor().raw.getImageHeight(); }

  /** Gets number of slices in screen dataset. */
  public int getNumberOfSlices() {
    return stackAxis < 0 ? 1 : screen.getLengths()[stackAxis];
  }

  /** Gets minimum slice value of screen dataset. */
  public int getStackMin() {
    return stackAxis < 0 ? 1 : screen.getDescriptor().min[stackAxis];
  }

  /** Gets maximum slice value of screen dataset. */
  public int getStackMax() {
    return stackAxis < 0 ? 1 : screen.getDescriptor().max[stackAxis];
  }

  /** Gets stack step value for screen dataset. */
  public int getStackStep() {
    return stackAxis < 0 ? 1 : screen.getDescriptor().step[stackAxis];
  }

  /** Gets RealType list for domain of measurement list. */
  public RealType[] getTypes() { return types; }

  /** Gets 2-D domain for measurement list. */
  public RealTupleType getDomain2D() { return domain2; }

  /** Gets 3-D domain for measurement list. */
  public RealTupleType getDomain3D() { return domain3; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    // points
    int psize = points.size();
    fout.println(psize);
    for (int i=0; i<psize; i++) {
      MeasurePoint point = (MeasurePoint) points.elementAt(i);
      fout.println(point.x);
      fout.println(point.y);
      BioUtil.writeArray(point.pos, fout);
      BioUtil.writeColor(point.preferredColor, fout);

      // associated lines
      int q = point.lines.size();
      fout.println(q);
      for (int j=0; j<q; j++) {
        fout.println(lines.indexOf(point.lines.elementAt(j)));
      }

      BioUtil.writeColor(point.color, fout);
      fout.println(point.group.getId());
      fout.println(point.stdType);
      fout.println(point.stdId);
    }

    // flags
    int fsize = flags.size();
    fout.println(fsize);
    for (int i=0; i<fsize; i++) {
      MeasureFlag flag = (MeasureFlag) flags.elementAt(i);
      fout.println(flag.x);
      fout.println(flag.y);
      BioUtil.writeColor(flag.preferredColor, fout);
      BioUtil.writeColor(flag.color, fout);
      fout.println(flag.group.getId());
    }

    // lines
    int lsize = lines.size();
    fout.println(lsize);
    for (int i=0; i<lsize; i++) {
      MeasureLine line = (MeasureLine) lines.elementAt(i);
      fout.println(points.indexOf(line.ep1));
      fout.println(points.indexOf(line.ep2));
      BioUtil.writeColor(line.color, fout);
      fout.println(line.group.getId());
      fout.println(line.stdType);
      fout.println(line.stdId);
    }

    fout.println(snap);
    fout.println(maxSID);
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    Vector groups = mm.getMeasureGroups();
    int gsize = groups.size();

    try {
      // points
      points.removeAllElements();
      int psize = Integer.parseInt(fin.readLine());
      int[][] pndx = new int[psize][];
      for (int i=0; i<psize; i++) {
        // location
        double x = BioUtil.readDouble(fin);
        double y = BioUtil.readDouble(fin);
        double[] pos = null;
        pos = BioUtil.readArray(pos, fin);

        // preferred color
        Color prefColor = BioUtil.readColor(fin);

        // associated lines
        int q = Integer.parseInt(fin.readLine());
        pndx[i] = new int[q];
        for (int j=0; j<q; j++) pndx[i][j] = Integer.parseInt(fin.readLine());

        // color
        Color color = BioUtil.readColor(fin);

        // group
        int gid = Integer.parseInt(fin.readLine());
        MeasureGroup group = null;
        for (int j=0; j<gsize; j++) {
          MeasureGroup mg = (MeasureGroup) groups.elementAt(j);
          if (mg.getId() == gid) {
            group = mg;
            break;
          }
        }

        // standard info
        int stdType = Integer.parseInt(fin.readLine());
        int stdId = Integer.parseInt(fin.readLine());

        // construct measurement point
        MeasurePoint point = new MeasurePoint(x, y, pos, color, group);
        point.preferredColor = prefColor;
        point.stdType = stdType;
        point.stdId = stdId;
        points.add(point);
      }

      // flags
      flags.removeAllElements();
      int fsize = Integer.parseInt(fin.readLine());
      for (int i=0; i<fsize; i++) {
        // location
        double x = BioUtil.readDouble(fin);
        double y = BioUtil.readDouble(fin);

        // preferred color
        Color prefColor = BioUtil.readColor(fin);

        // color
        Color color = BioUtil.readColor(fin);

        // group
        int gid = Integer.parseInt(fin.readLine());
        MeasureGroup group = null;
        for (int j=0; j<gsize; j++) {
          MeasureGroup mg = (MeasureGroup) groups.elementAt(j);
          if (mg.getId() == gid) {
            group = mg;
            break;
          }
        }

        // construct measurement flag
        MeasureFlag flag = new MeasureFlag(x, y, color, group);
        flag.preferredColor = prefColor;
        flags.add(flag);
      }

      // lines
      lines.removeAllElements();
      int lsize = Integer.parseInt(fin.readLine());
      for (int i=0; i<lsize; i++) {
        // endpoints
        int ndx1 = Integer.parseInt(fin.readLine());
        int ndx2 = Integer.parseInt(fin.readLine());
        MeasurePoint ep1 = (MeasurePoint) points.elementAt(ndx1);
        MeasurePoint ep2 = (MeasurePoint) points.elementAt(ndx2);

        // color
        Color color = BioUtil.readColor(fin);

        // group
        int gid = Integer.parseInt(fin.readLine());
        MeasureGroup group = null;
        for (int j=0; j<gsize; j++) {
          MeasureGroup mg = (MeasureGroup) groups.elementAt(j);
          if (mg.getId() == gid) {
            group = mg;
            break;
          }
        }

        // standard info
        int stdType = Integer.parseInt(fin.readLine());
        int stdId = Integer.parseInt(fin.readLine());

        // construct measurement line
        MeasureLine line = new MeasureLine(ep1, ep2, color, group, false);
        line.stdType = stdType;
        line.stdId = stdId;
        lines.add(line);
      }

      // link points to associated lines
      for (int i=0; i<psize; i++) {
        MeasurePoint point = (MeasurePoint) points.elementAt(i);
        for (int j=0; j<pndx[i].length; j++) {
          MeasureLine line = (MeasureLine) lines.elementAt(pndx[i][j]);
          point.lines.add(line);
        }
      }

      snap = fin.readLine().equals("true");
      maxSID = Integer.parseInt(fin.readLine());
    }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- Dynamic API methods --

  /** Tests whether two dynamic objects have matching states. */
  public boolean matches(Dynamic dyn) { return this == dyn; }

  /** Modifies this object's state to match that of the given object. */
  public void initState(Dynamic dyn) {
    if (dyn != null && dyn instanceof MeasureList) {
      MeasureList list = (MeasureList) dyn;
      lines = list.lines;
      points = list.points;
      snap = list.snap;
      maxSID = list.maxSID;
    }
  }

  /**
   * Called when this object is being discarded in favor of
   * another object with a matching state.
   */
  public void discard() { }



  // -- Helper methods --

  /** Removes measurements from the measurement pool. */
  private void remove(boolean all) {
    int i = 0;
    while (i < lines.size()) {
      MeasureLine line = (MeasureLine) lines.elementAt(i);
      if (all || line.selected) remove(line);
      else i++;
    }
    i = 0;
    while (i < points.size()) {
      MeasurePoint point = (MeasurePoint) points.elementAt(i);
      if (all || point.selected > 0) remove(point);
      else i++;
    }
    i = 0;
    while (i < flags.size()) {
      MeasureFlag flag = (MeasureFlag) flags.elementAt(i);
      if (all || flag.selected > 0) remove(flag);
      else i++;
    }

    mm.refreshPools(true);
  }

  /** Removes the given measurement line from the measurement pool. */
  private void remove(MeasureLine line) {
    line.ep1.lines.remove(line);
    line.ep2.lines.remove(line);
    if (line.ep1.lines.isEmpty()) remove(line.ep1);
    if (line.ep2.lines.isEmpty()) remove(line.ep2);
    mm.getPool2D().deselect(line);
    MeasurePool pool3 = mm.getPool3D();
    if (pool3 != null) pool3.deselect(line);
    lines.remove(line);
  }

  /** Removes the given measurement endpoint from the measurement pool. */
  private void remove(MeasurePoint point) {
    MeasurePool pool2 = mm.getPool2D();
    pool2.deselect(point);
    pool2.release(point);
    MeasurePool pool3 = mm.getPool3D();
    if (pool3 != null) {
      pool3.deselect(point);
      pool3.release(point);
    }
    if (point instanceof MeasureFlag) flags.remove(point);
    else points.remove(point);
  }

  /** Sets or unsets the given measurement as standard. */
  private void doStandard(MeasureThing thing, int std) {
    if (thing.stdType == std) return;
    ScreenDescriptor desc = screen.getDescriptor();
    int[] min = desc.min;
    int[] max = desc.max;
    int[] step = desc.step;
    int[] lengths = screen.getLengths();

    // convert dataset coordinates to raster
    int[] pos = mm.getPos();
    int[] curpos = new int[pos.length];
    for (int i=0; i<pos.length; i++) curpos[i] = (pos[i] - min[i]) / step[i];
    int cur = BioUtil.positionToRaster(lengths, curpos);

/*
    // determine whether alignment transformation is necessary
    AlignManager am = (AlignManager)
      mm.getVisBio().getManager(AlignManager.class);
    boolean trans = false;
    AlignmentPlane align = null;
    if (am != null) {
      align = am.getAlignmentPlane();
      if (align != null) trans = align.getMode() == AlignmentPlane.APPLY_MODE;
    }
*/

    boolean isLine = thing instanceof MeasureLine;
    if (std == MeasureManager.STD_SINGLE) {
      // unset standard
      undoStandard(thing);
    }
    else if (std == MeasureManager.STD_2D) {
      // set 2-D standard
      int id;
      if (thing.stdType == MeasureManager.STD_3D) {
        id = thing.stdId;
        undoStandard(thing);
      }
      else id = maxSID++; // thing.stdType == MeasureManager.STD_SINGLE
      thing.setStandard(MeasureManager.STD_2D, id);

      // loop through all positions, except the current one
      int len = BioUtil.getRasterLength(lengths);
      for (int i=0; i<len; i++) {
        if (i == cur) continue;

        // convert raster to dataset coordinates
        int[] dest = BioUtil.rasterToPosition(lengths, i);
        double[] p = new double[dest.length];
        for (int j=0; j<dest.length; j++) p[j] = min[j] + step[j] * dest[j];
        int[] src = new int[curpos.length];
        for (int j=0; j<src.length; j++) {
          src[j] = j == stackAxis ? dest[j] : curpos[j];
        }

        if (isLine) {
          MeasureLine line =
/*
            trans ? transformLine((MeasureLine) thing, src, dest, align) :
*/
            new MeasureLine((MeasureLine) thing, p);
          addLine(line, false);
        }
        else {
          MeasurePoint point =
/*
            trans ? transformPoint((MeasurePoint) thing, src, dest, align) :
*/
            new MeasurePoint((MeasurePoint) thing, p);
          addMarker(point, false);
        }
      }
    }
    else if (std == MeasureManager.STD_3D) {
      // set 3-D standard
      int id;
      if (thing.stdType == MeasureManager.STD_2D) {
        id = thing.stdId;
        undoStandard(thing);
      }
      else id = maxSID++; // thing.stdType == MeasureManager.STD_SINGLE
      thing.setStandard(MeasureManager.STD_3D, id);

      // loop through all positions, but only on the current slice
      int len = BioUtil.getRasterLength(lengths);
      for (int i=0; i<len; i++) {
        if (i == cur) continue;

        // convert raster to dataset coordinates
        int[] dest = BioUtil.rasterToPosition(lengths, i);
        double[] p = new double[dest.length];
        for (int j=0; j<dest.length; j++) p[j] = min[j] + step[j] * dest[j];
        if (stackAxis >= 0 && pos[stackAxis] != p[stackAxis]) continue;

        if (isLine) {
          MeasureLine line =
/*
            trans ? transformLine((MeasureLine) thing, curpos, dest, align) :
*/
            new MeasureLine((MeasureLine) thing, p);
          addLine(line, false);
        }
        else {
          MeasurePoint point =
/*
            trans ? transformPoint((MeasurePoint) thing, curpos, dest, align) :
*/
            new MeasurePoint((MeasurePoint) thing, p);
          addMarker(point, false);
        }
      }
    }
    mm.updateRemove();
  }

  /** Unsets the given measurement as standard. */
  private void undoStandard(MeasureThing thing) {
    if (thing.stdType == MeasureManager.STD_SINGLE) {
      // line not standard; skip it
      return;
    }
    int stdId = thing.stdId;
    thing.setStandard(MeasureManager.STD_SINGLE, -1);
    int k = 0;
    while (k < lines.size()) {
      MeasureLine line = (MeasureLine) lines.elementAt(k);
      if (line.stdId == stdId) removeLine(line, false);
      else k++;
    }
    Vector points = getPoints();
    k = 0;
    while (k < points.size()) {
      MeasurePoint point = (MeasurePoint) points.elementAt(k);
      if (point.stdId == stdId) removeMarker(point, false);
      else k++;
    }
  }

  /** Exports the specified measurement to the given output stream. */
  private void export(PrintWriter fout, MeasureThing thing,
    boolean std2d, int stackAxis, double mx, double my, double sd)
  {
    if (thing instanceof MeasureFlag) {
      MeasureFlag flag = (MeasureFlag) thing;
      fout.print(mx * flag.x);
      fout.print("\t");
      fout.print(my * flag.y);
      fout.print("\t");
    }
    else if (thing instanceof MeasurePoint) {
      MeasurePoint point = (MeasurePoint) thing;
      for (int j=0; j<point.pos.length; j++) {
        if (j == stackAxis) continue;
        fout.print(point.pos[j]);
        fout.print("\t");
      }
      fout.print(mx * point.x);
      fout.print("\t");
      fout.print(my * point.y);
      fout.print("\t");
      if (stackAxis >= 0) {
        fout.print(sd * point.pos[stackAxis]);
        fout.print("\t");
      }
    }
    else {
      MeasureLine line = (MeasureLine) thing;
      double z1 = 0, z2 = 0;
      for (int j=0; j<line.ep1.pos.length; j++) {
        if (j == stackAxis) continue;
        fout.print(line.ep1.pos[j]);
        fout.print("\t");
      }
      fout.print(mx * line.ep1.x);
      fout.print("\t");
      fout.print(my * line.ep1.y);
      fout.print("\t");
      if (stackAxis >= 0 && !std2d) {
        z1 = line.ep1.pos[stackAxis];
        fout.print(sd * z1);
        fout.print("\t");
      }
      fout.print(mx * line.ep2.x);
      fout.print("\t");
      fout.print(my * line.ep2.y);
      fout.print("\t");
      if (stackAxis >= 0) {
        z2 = line.ep2.pos[stackAxis];
        fout.print(sd * z2);
        fout.print("\t");
      }
      double[] p = {line.ep1.x, line.ep1.y, z1};
      double[] q = {line.ep2.x, line.ep2.y, z2};
      double[] m = {mx, my, sd};
      fout.print(BioUtil.getDistance(p, q, m));
      fout.print("\t");
    }
    fout.print(thing.color.getRed());
    fout.print("\t");
    fout.print(thing.color.getGreen());
    fout.print("\t");
    fout.print(thing.color.getBlue());
    fout.print("\t");
    fout.println(thing.group.getId());
  }

  /**
   * Transforms a measurement line according
   * to the alignment plane orientation.
   */
/*
  private MeasureLine transformLine(MeasureLine l,
    int[] curpos, int[] destpos, AlignmentPlane align)
  {
    ScreenDescriptor desc = screen.getDescriptor();
    int[] min = desc.min;
    int[] step = desc.step;

    // transform first endpoint
    double[] v1 = {l.ep1.x, l.ep1.y, curpos[stackAxis]};
    v1 = align.transform(v1, curpos, destpos);
    double[] pos1 = new double[destpos.length];
    for (int i=0; i<pos1.length; i++) {
      double q = i == stackAxis ? v1[2] : destpos[i];
      // convert raster to dataset coordinates
      pos1[i] = min[i] + step[i] * q;
    }

    // transform second endpoint
    double[] v2 = {l.ep2.x, l.ep2.y, curpos[stackAxis]};
    v2 = align.transform(v2, curpos, destpos);
    double[] pos2 = new double[destpos.length];
    for (int i=0; i<pos2.length; i++) {
      double q = i == stackAxis ? v2[2] : destpos[i];
      // convert raster to dataset coordinates
      pos2[i] = min[i] + step[i] * q;
    }

    return new MeasureLine(l, v1[0], v1[1], pos1, v2[0], v2[1], pos2);
  }
*/

  /**
   * Transforms a measurement marker according
   * to the alignment plane orientation.
   */
/*
  private MeasurePoint transformPoint(MeasurePoint p,
    int[] curpos, int[] destpos, AlignmentPlane align)
  {
    ScreenDescriptor desc = screen.getDescriptor();
    int[] min = desc.min;
    int[] step = desc.step;

    // transform endpoint
    double[] v = {p.x, p.y, curpos[stackAxis]};
    v = align.transform(v, curpos, destpos);
    double[] pos = new double[destpos.length];
    for (int i=0; i<pos.length; i++) {
      double q = i == stackAxis ? v[2] : destpos[i];
      // convert raster to dataset coordinates
      pos[i] = min[i] + step[i] * q;
    }

    return new MeasurePoint(p, v[0], v[1], pos);
  }
*/

}
