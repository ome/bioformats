//
// MeasureGroup.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.io.*;

import loci.visbio.state.*;
import loci.visbio.util.BioUtil;

/** MeasureGroup represents a possible grouping for measurements. */
public class MeasureGroup implements Saveable, Dynamic {

  // -- Constants --

  /** Tag indicating end of group description output. */
  private static final String DESC_END = "[group description end]";


  // -- Static fields --

  /** Next free id number. */
  private static int nextId = 0;


  // -- Fields --

  /** Name of the group. */
  private String name;

  /** Description of the group. */
  private String description;

  /** Id number for the group. */
  private int gid;


  // -- Constructor --

  /** Constructs an uninitialized measurement group. */
  public MeasureGroup() { }

  /** Constructs a measurement group. */
  public MeasureGroup(String name) {
    this.name = name;
    description = "";
    gid = nextId++;
  }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    fout.println(name);
    fout.println(description);
    fout.println(DESC_END);
    fout.println(gid);
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    try {
      name = fin.readLine();
      description = fin.readLine();
      while (true) {
        String s = fin.readLine();
        if (s.equals(DESC_END)) break;
        description = description + "\n" + s;
      }
      gid = Integer.parseInt(fin.readLine());
      if (nextId <= gid) nextId = gid + 1;
    }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- Dynamic API methods --

  /** Tests whether two dynamic objects have matching states. */
  public boolean matches(Dynamic dyn) {
    if (dyn == null || !(dyn instanceof MeasureGroup)) return false;
    MeasureGroup group = (MeasureGroup) dyn;
    return BioUtil.objectsEqual(name, group.name) &&
      BioUtil.objectsEqual(description, group.description) && gid == group.gid;
  }

  /** Modifies this object's state to match that of the given object. */
  public void initState(Dynamic dyn) {
    if (dyn != null && dyn instanceof MeasureGroup) {
      MeasureGroup group = (MeasureGroup) dyn;
      name = group.name;
      description = group.description;
      gid = group.gid;
    }
  }

  /**
   * Called when this object is being discarded in favor of
   * another object with a matching state.
   */
  public void discard() { }


  // -- New API methods --

  /** Sets the group's description. */
  public void setDescription(String desc) { description = desc; }

  /** Gets the group's string representation (name). */
  public String toString() { return name; }

  /** Gets the group's name. */
  public String getName() { return name; }

  /** Gets the group's description. */
  public String getDescription() { return description; }

  /** Gets the id number of the group. */
  public int getId() { return gid; }

}
