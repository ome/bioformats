//
// MeasurePoint.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.Color;
import java.io.PrintWriter;
import java.util.Vector;

import loci.visbio.VisBio;
import loci.visbio.util.BioUtil;

/** An endpoint in the list of measurements. */
public class MeasurePoint extends MeasureThing {

  // -- Fields --

  /** Coordinates of this endpoint. */
  public double x, y;

  /** Position of this endpoint within the multidimensional structure. */
  public double[] pos;

  /** Preferred color of this endpoint. */
  public Color preferredColor;

  /** The number of times this endpoint is selected. */
  public int selected;

  /** List of measurement lines that use this endpoint. */
  public Vector lines;

  /** Linked pool points from measurement pools. */
  public PoolPoint[] pt;


  // -- Constructors --

  /**
   * Constructs an endpoint with the given
   * coordinates, position, color and group.
   */
  public MeasurePoint(double x, double y, double[] pos,
    Color color, MeasureGroup group)
  {
    init(x, y, pos, color, color, group, stdType, stdId);
  }

  /** Constructs an endpoint cloned from the given endpoint. */
  public MeasurePoint(MeasurePoint point) {
    init(point.x, point.y, point.pos, point.preferredColor,
      point.color, point.group, point.stdType, point.stdId);
  }

  /**
   * Constructs an endpoint cloned from the given endpoint,
   * but with a (possibly) different dimensional position.
   */
  public MeasurePoint(MeasurePoint point, double[] pos) {
    init(point.x, point.y, pos, point.preferredColor,
      point.color, point.group, point.stdType, point.stdId);
  }

  /**
   * Constructs an endpoint cloned from the given endpoint,
   * but with a (possibly) different set of coordinates.
   */
  public MeasurePoint(MeasurePoint point, double x, double y, double[] pos) {
    init(x, y, pos, point.preferredColor, point.color,
      point.group, point.stdType, point.stdId);
  }


  // -- New API methods --

  /** Sets the coordinates of the endpoint to match those given. */
  public void setCoordinates(PoolPoint p, double x, double y, double[] pos) {
    if (this.x == x && this.y == y && BioUtil.arraysEqual(this.pos, pos)) {
      return;
    }
    this.x = x;
    this.y = y;
    this.pos = pos;
    for (int i=0; i<pt.length; i++) {
      if (pt[i] != null && pt[i] != p) pt[i].refresh();
    }
  }

  /** Sets the point's color to match its associated lines. */
  public void refreshColor() {
    if (lines.isEmpty()) color = preferredColor;
    else {
      int size = lines.size();
      Color c = ((MeasureLine) lines.elementAt(0)).color;
      for (int i=1; i<size; i++) {
        MeasureLine line = (MeasureLine) lines.elementAt(i);
        if (line.color != c) {
          color = Color.white;
          return;
        }
      }
      color = c;
    }
  }


  // -- MeasureThing API methods --

  /** Sets the point's preferred color to the given one. */
  public void setColor(Color color) {
    preferredColor = color;
    refreshColor();
  }


  // -- Object API methods --

  /** Gets a string representation of this measurement point. */
  public String toString() {
    StringBuffer sb = new StringBuffer();
    for (int i=0; i<pos.length; i++) {
      if (i > 0) sb.append(" ");
      sb.append(pos[i]);
    }
    return super.toString() + ":\n" +
      "    color=" + color + "\n" +
      "    group=" + group + "\n" +
      "    stdType=" + stdType + "\n" +
      "    stdId=" + stdId + "\n" +
      "    selected=" + selected + "\n" +
      "    preferredColor=" + preferredColor + "\n" +
      "    x=" + x + "\n" +
      "    y=" + y + "\n" +
      "    pos=" + sb.toString();
  }


  // -- Helper methods --

  /** Initializes the measurement point with the given values. */
  private void init(double x, double y, double[] pos, Color preferredColor,
    Color color, MeasureGroup group, int stdType, int stdId)
  {
    this.x = x;
    this.y = y;
    this.pos = pos;
    this.preferredColor = preferredColor;
    this.color = color;
    this.group = group;
    this.stdType = stdType;
    this.stdId = stdId;
    lines = new Vector();
    pt = new PoolPoint[MeasureManager.MAX_POOLS];
  }

}
