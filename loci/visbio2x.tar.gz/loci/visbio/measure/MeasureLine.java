//
// MeasureLine.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.Color;
import java.util.Vector;

import loci.visbio.util.BioUtil;

/** A connecting line in the list of measurements. */
public class MeasureLine extends MeasureThing {

  // -- Fields --

  /** Endpoints of this line. */
  public MeasurePoint ep1, ep2;

  /** Whether this line is selected. */
  public boolean selected;


  // -- Constructors --

  /**
   * Constructs a line with the given endpoints,
   * color, group and selection status.
   */
  public MeasureLine(MeasurePoint ep1, MeasurePoint ep2,
    Color color, MeasureGroup group, boolean selected)
  {
    this.ep1 = ep1;
    this.ep2 = ep2;
    init(color, group, selected, stdType, stdId);
  }

  /** Constructs a line cloned from the given line. */
  public MeasureLine(MeasureLine line) {
    ep1 = new MeasurePoint(line.ep1);
    ep2 = new MeasurePoint(line.ep2);
    init(line.color, line.group, false, line.stdType, line.stdId);
  }

  /**
   * Constructs a line cloned from the given line,
   * but with a (possibly) different dimensional position.
   */
  public MeasureLine(MeasureLine line, double[] pos) {
    ep1 = new MeasurePoint(line.ep1, pos);
    ep2 = new MeasurePoint(line.ep2, pos);
    init(line.color, line.group, false, line.stdType, line.stdId);
  }

  /**
   * Constructs a line cloned from the given line, but
   * with a (possibly) different set of endpoint values.
   */
  public MeasureLine(MeasureLine line, double x1, double y1, double[] pos1,
    double x2, double y2, double[] pos2)
  {
    ep1 = new MeasurePoint(line.ep1, x1, y1, pos1);
    ep2 = new MeasurePoint(line.ep2, x2, y2, pos2);
    init(line.color, line.group, false, line.stdType, line.stdId);
  }


  // -- MeasureThing API methods --

  /** Sets the line's color to match the given one. */
  public void setColor(Color color) {
    this.color = color;
    ep1.refreshColor();
    ep2.refreshColor();
  }

  /** Sets the line's standard id to match the given id. */
  public void setStandard(int stdType, int stdId) {
    super.setStandard(stdType, stdId);
    ep1.setStandard(stdType, stdId);
    ep2.setStandard(stdType, stdId);
  }


  // -- Object API methods --

  /** Gets a string representation of this measurement line. */
  public String toString() {
    return super.toString() + ":\n" +
      "  color=" + color + "\n" +
      "  group=" + group + "\n" +
      "  stdType=" + stdType + "\n" +
      "  stdId=" + stdId + "\n" +
      "  selected=" + selected + "\n" +
      "  ep1=" + ep1 + "\n" +
      "  ep2=" + ep2;
  }


  // -- Helper methods --

  /** Initializes this measurement line with the given information. */
  private void init(Color color, MeasureGroup group, boolean selected,
    int stdType, int stdId)
  {
    this.color = color;
    this.group = group;
    this.selected = selected;
    this.stdType = stdType;
    this.stdId = stdId;
    ep1.lines.add(this);
    ep2.lines.add(this);
  }

}
