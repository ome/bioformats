//
// MeasurePanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.rmi.RemoteException;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;

import loci.visbio.*;
import loci.visbio.util.*;

import visad.*;
import visad.browser.*;
import visad.util.*;

/**
 * MeasurePanel is the control panel for
 * managing measurements between data points.
 */
public class MeasurePanel extends ControlPanel {

  // -- Constants --

  /** Placeholder for measurement coordinates label. */
  private static final String COORD_LABEL =
    " (0000.000, 0000.000)-(0000.000, 0000.000)";

  /** Placeholder for measurement distance label. */
  private static final String DIST_LABEL = "distance = 0000.000 pix";


  // -- Micron GUI components --

  /**
   * Check box for indicating file should be saved or restored
   * using a micron-pixel conversion of the given width and height.
   */
  private DoubleTextCheckBox useMicrons;

  /** Label for distance between slices. */
  private JLabel sliceDistLabel;

  /** Text field for specifying distance (in microns) between slices. */
  private JTextField sliceDistance;

  /** Toggle for using micron information to compute Z aspect ratio. */
  private JCheckBox zAspect;


  // -- Measurement GUI components (global) --

  /** Button for adding lines. */
  private JButton addLine;

  /** Button for adding points. */
  private JButton addMarker;

  /** Button for adding flags. */
  private JButton addFlag;

  /** Button for toggling whether SHIFT + right click does a merge. */
  private JToggleButton merge;

  /** Button for clearing all measurements. */
  private JButton clearAll;

  /** Button for exporting measurements to Excel-friendly text format. */
  private JButton export;

  /** File chooser for exporting measurements. */
  private JFileChooser exportBox;

  /** Checkbox for snapping measurement endpoints to nearest slice. */
  private JCheckBox snap;

  /** Button for snapping all measurement endpoints now. */
  private JButton snapNow;


  // -- Measurement GUI components (selected) --

  /** Label for displaying measurement coordinates. */
  private JLabel measureCoord;

  /** Label for displaying measurement distance. */
  private JLabel measureDist;

  /** Button for standalone measurement (this focal plane/timestep only). */
  private JRadioButton single;

  /**
   * Button for distributing measurement through
   * all focal planes of all timesteps.
   */
  private JRadioButton standard2D;

  /** Button for distributing measurement through all timesteps. */
  private JRadioButton standard3D;

  /** Button for removing objects. */
  private JButton removeSelected;

  /** Label for color list. */
  private JLabel colorLabel;

  /** List of valid colors. */
  private JComboBox colorList;

  /** Label for group list. */
  private JLabel groupLabel;

  /** List of valid groups. */
  private JComboBox groupList;

  /** Button for adding a new group to the list. */
  private JButton newGroup;

  /** Label for description box. */
  private JLabel descriptionLabel;

  /** Text area for group description. */
  private JTextArea descriptionBox;


  // -- Other fields --

  /** Computation cell for linking selection with measurement object. */
  private CellImpl cell;

  /** Flag marking whether to ignore next set standard checkbox toggle. */
  private boolean ignoreStandard = false;


  // -- Constructor --

  /** Constructs a tool panel for performing measurement operations. */
  public MeasurePanel(LogicManager logic) {
    super(logic, "Measure", "Controls for measuring data");
    final MeasureManager mm = (MeasureManager) lm;
    final VisBio bio = mm.getVisBio();

    // microns vs pixels checkbox
    useMicrons = new DoubleTextCheckBox(
      "Use microns instead of pixels", "by", "", "", false);
    useMicrons.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        boolean b = useMicrons.isSelected();
        sliceDistLabel.setEnabled(b);
        sliceDistance.setEnabled(b);
        mm.setUseMicrons(b, getMicronWidth(), getMicronHeight());
      }
    });
    useMicrons.setMnemonic('m');
    useMicrons.setToolTipText("Computes distances in terms of microns",
      "Width of each image in microns",
      "Height of each image in microns");
    useMicrons.setEnabled(false);
    controls.add(BioUtil.pad(useMicrons));

    // slice distance label
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    sliceDistLabel = BioUtil.makeLabel("Microns between slices: ");
    sliceDistLabel.setDisplayedMnemonic('b');
    String sliceDistToolTip =
      "Specifies the distance between image slices, in microns";
    BioUtil.setTip(bio, sliceDistLabel, sliceDistToolTip);
    sliceDistLabel.setEnabled(false);
    p.add(sliceDistLabel);

    // distance between slices text box
    sliceDistance = BioUtil.makeField(4);
    Util.adjustTextField(sliceDistance);
    sliceDistance.getDocument().addDocumentListener(new DocumentListener() {
      public void changedUpdate(DocumentEvent e) {
        mm.setSliceDistance(getSliceDistance());
      }
      public void insertUpdate(DocumentEvent e) {
        mm.setSliceDistance(getSliceDistance());
      }
      public void removeUpdate(DocumentEvent e) {
        mm.setSliceDistance(getSliceDistance());
      }
    });
    sliceDistLabel.setLabelFor(sliceDistance);
    BioUtil.setTip(bio, sliceDistance, sliceDistToolTip);
    sliceDistance.setEnabled(false);
    p.add(sliceDistance);
    controls.add(BioUtil.pad(p));

    // Z-aspect toggle
    zAspect = new JCheckBox("Use micron information for Z-scale", true);
    zAspect.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        mm.setZAspect(zAspect.isSelected());
      }
    });
    zAspect.setMnemonic('z');
    BioUtil.setTip(bio, zAspect,
      "Adjusts slice spacing to match distance between slices");
    zAspect.setEnabled(false);
    controls.add(BioUtil.pad(zAspect));

    // divider between micron functions and drift correction functions
    controls.add(Box.createVerticalStrut(10));
    controls.add(new Divider());
    controls.add(Box.createVerticalStrut(10));

    // add line button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    addLine = new JButton("New line");
    addLine.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { mm.addLine(); }
    });
    addLine.setMnemonic('l');
    addLine.setToolTipText("Adds a line to the current slice");
    addLine.setEnabled(false);
    p.add(addLine);
    p.add(Box.createHorizontalStrut(5));

    // add marker button
    addMarker = new JButton("New marker");
    addMarker.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { mm.addMarker(); }
    });
    addMarker.setMnemonic('k');
    addMarker.setToolTipText("Adds a marker to the current slice");
    addMarker.setEnabled(false);
    p.add(addMarker);
    p.add(Box.createHorizontalStrut(5));

    // add flag button
    addFlag = new JButton("New flag");
    addFlag.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { mm.addFlag(); }
    });
    addFlag.setToolTipText("Adds a flag to the dataset");
    addFlag.setEnabled(false);
    p.add(addFlag);
    controls.add(BioUtil.pad(p));

    // spacing
    controls.add(Box.createVerticalStrut(5));

    // merge button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    merge = new JToggleButton("Merge");
    merge.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mm.setMerge(merge.isSelected());
      }
    });
    merge.setMnemonic('m');
    merge.setToolTipText("Allows for merging multiple measurement endpoints");
    merge.setEnabled(false);
    p.add(merge);
    p.add(Box.createHorizontalStrut(5));

    // remove button
    removeSelected = new JButton("Remove");
    removeSelected.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { mm.removeSelected(); }
    });
    removeSelected.setMnemonic('r');
    removeSelected.setToolTipText("Removes the selected measurements");
    removeSelected.setEnabled(false);
    p.add(removeSelected);
    p.add(Box.createHorizontalStrut(5));

    // clear all measurements button
    clearAll = new JButton("Clear all");
    clearAll.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        int ans = JOptionPane.showConfirmDialog(bio,
          "Really clear all measurements?", "VisBio",
          JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ans != JOptionPane.YES_OPTION) return;
        mm.removeAll();
      }
    });
    clearAll.setMnemonic('a');
    clearAll.setToolTipText("Removes all measurements");
    clearAll.setEnabled(false);
    p.add(clearAll);
    controls.add(BioUtil.pad(p));

    // spacing
    controls.add(Box.createVerticalStrut(5));

    // export measurements button
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    export = new JButton("Export measurements");
    final Component panel = this;
    export.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        int rval = exportBox.showSaveDialog(bio);
        if (rval != JFileChooser.APPROVE_OPTION) return;
        File file = exportBox.getSelectedFile();
        if (file.getName().indexOf(".") < 0) {
          file = new File(file.getAbsolutePath() + ".txt");
        }
        mm.export(file);
      }
    });
    export.setMnemonic('x');
    export.setToolTipText(
      "Exports measurements to Excel-friendly text format");
    export.setEnabled(false);
    p.add(export);
    p.add(Box.createHorizontalStrut(5));

    // export measurements file chooser
    exportBox = new JFileChooser();
    exportBox.addChoosableFileFilter(new ExtensionFileFilter(
      "txt", "VisBio measurements"));

    // snap now button
    snapNow = new JButton("Snap now");
    snapNow.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) { mm.snapNow(); }
    });
    snapNow.setMnemonic('w');
    snapNow.setToolTipText("Systematically snaps measurements " +
      "to the closest slices.");
    snapNow.setEnabled(false);
    p.add(snapNow);
    controls.add(BioUtil.pad(p));

    // snap to slices checkbox
    snap = new JCheckBox("Snap endpoints to nearest slice", true);
    snap.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        mm.setSnap(snap.isSelected());
      }
    });
    snap.setMnemonic('p');
    snap.setToolTipText("Prevents measurement endpoints " +
      "from lying between slices.");
    snap.setEnabled(false);
    controls.add(BioUtil.pad(snap));

    // divider between global functions and measurement-specific functions
    controls.add(Box.createVerticalStrut(10));
    controls.add(new Divider());
    controls.add(Box.createVerticalStrut(10));

    // measurement information label
    measureCoord = new JLabel(" ") {
      public Dimension getPreferredSize() {
        FontMetrics fm = getFontMetrics(getFont());
        int width = fm.stringWidth("    " + COORD_LABEL);
        Dimension d = super.getPreferredSize();
        return new Dimension(width, d.height);
      }
    };
    measureCoord.setForeground(Color.black);
    measureCoord.setToolTipText("Coordinates " +
      "of the current measurement");
    controls.add(BioUtil.pad(measureCoord));
    measureDist = new JLabel(" ") {
      public Dimension getPreferredSize() {
        FontMetrics fm = getFontMetrics(getFont());
        int width = fm.stringWidth("    " + DIST_LABEL);
        Dimension d = super.getPreferredSize();
        return new Dimension(width, d.height);
      }
    };
    measureDist.setForeground(Color.black);
    measureDist.setToolTipText("Distance between " +
      "the current line's endpoints");
    controls.add(BioUtil.pad(measureDist));
    controls.add(Box.createVerticalStrut(10));

    cell = new CellImpl() {
      public void doAction() { updateMeasureInfo(); }
    };

    // single measurement button
    ButtonGroup group = new ButtonGroup();
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    single = new JRadioButton("Single", true);
    single.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (ignoreStandard) ignoreStandard = false;
        else mm.setStandard(MeasureManager.STD_SINGLE);
      }
    });
    group.add(single);
    single.setMnemonic('s');
    single.setToolTipText("Sets selected measurements " +
      "to this slice & timestep only");
    single.setEnabled(false);
    p.add(single);
    p.add(Box.createHorizontalStrut(5));

    // 2-D standard button
    standard2D = new JRadioButton("2-D standard");
    standard2D.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (ignoreStandard) ignoreStandard = false;
        else mm.setStandard(MeasureManager.STD_2D);
      }
    });
    group.add(standard2D);
    standard2D.setMnemonic('2');
    standard2D.setToolTipText("Distributes selected " +
      "measurements across all slices & timesteps");
    standard2D.setEnabled(false);
    p.add(standard2D);
    p.add(Box.createHorizontalStrut(5));

    // 3-D standard button
    standard3D = new JRadioButton("3-D standard");
    standard3D.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (ignoreStandard) ignoreStandard = false;
        else mm.setStandard(MeasureManager.STD_3D);
      }
    });
    group.add(standard3D);
    standard3D.setMnemonic('3');
    standard3D.setToolTipText("Distributes selected " +
      "measurements across all slices & timesteps");
    standard3D.setEnabled(false);
    p.add(standard3D);
    controls.add(BioUtil.pad(p));
    controls.add(Box.createVerticalStrut(5));

    // color label
    p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
    colorLabel = BioUtil.makeLabel("Color: ");
    colorLabel.setDisplayedMnemonic('c');
    String colorToolTip = "Changes the color of the selected measurements";
    colorLabel.setToolTipText(colorToolTip);
    colorLabel.setEnabled(false);
    p.add(colorLabel);

    // color list
    colorList = new JComboBox(new Color[] {
      Color.white, Color.red, Color.orange, Color.green,
      Color.cyan, Color.blue, Color.magenta, Color.pink,
      Color.lightGray, Color.gray, Color.darkGray, Color.black
    });
    colorList.setRenderer(new ColorRenderer());
    colorList.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        Color color = (Color) colorList.getSelectedItem();
        mm.setColor(color);
      }
    });
    colorLabel.setLabelFor(colorList);
    colorList.setToolTipText(colorToolTip);
    colorList.setEnabled(false);
    p.add(colorList);
    p.add(Box.createHorizontalStrut(5));

    // group label
    groupLabel = BioUtil.makeLabel("Group: ");
    groupLabel.setDisplayedMnemonic('g');
    String groupToolTip = "Changes the group of the selected measurements";
    groupLabel.setToolTipText(groupToolTip);
    groupLabel.setEnabled(false);
    p.add(groupLabel);

    // group list
    groupList = new JComboBox();
    groupList.addItem(mm.getNoneGroup());
    groupList.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        MeasureGroup mgroup = (MeasureGroup) groupList.getSelectedItem();
        if (mgroup == null) return;
        mm.setGroup(mgroup);
      }
    });
    groupLabel.setLabelFor(groupList);
    groupList.setToolTipText(groupToolTip);
    groupList.setEnabled(false);
    p.add(groupList);

    // new group button
    newGroup = new JButton("New");
    newGroup.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        String nextGroup = "group" + groupList.getItemCount();
        String value = (String) JOptionPane.showInputDialog(bio,
          "Group name:", "Create measurement group",
          JOptionPane.INFORMATION_MESSAGE, null, null, nextGroup);
        if (value == null) return;
        MeasureGroup mgroup = new MeasureGroup(value);
        groupList.addItem(mgroup);
        groupList.setSelectedItem(mgroup);
      }
    });
    newGroup.setMnemonic('n');
    newGroup.setToolTipText("Creates a new measurement group");
    newGroup.setEnabled(false);
    p.add(newGroup);
    controls.add(p);

    // spacing
    controls.add(Box.createVerticalStrut(5));

    // description label
    descriptionLabel = BioUtil.makeLabel("Group description:");
    descriptionLabel.setAlignmentX(SwingConstants.LEFT);
    descriptionLabel.setDisplayedMnemonic('d');
    String descriptionToolTip =
      "Edits the description of the current measurement group";
    descriptionLabel.setToolTipText(descriptionToolTip);
    descriptionLabel.setEnabled(false);
    controls.add(BioUtil.pad(descriptionLabel));

    // description box
    descriptionBox = new JTextArea();
    descriptionBox.setRows(4);
    descriptionBox.setLineWrap(true);
    descriptionBox.setWrapStyleWord(true);
    descriptionBox.getDocument().addDocumentListener(new DocumentListener() {
      public void changedUpdate(DocumentEvent e) { update(e); }
      public void insertUpdate(DocumentEvent e) { update(e); }
      public void removeUpdate(DocumentEvent e) { update(e); }
      public void update(DocumentEvent e) {
        MeasureGroup mgroup = (MeasureGroup) groupList.getSelectedItem();
        mgroup.setDescription(descriptionBox.getText());
      }
    });
    descriptionLabel.setLabelFor(descriptionBox);
    descriptionBox.setToolTipText(descriptionToolTip);
    descriptionBox.setEnabled(false);
    controls.add(new JScrollPane(descriptionBox));
  }


  // -- New API methods --

  /** Gets the currently selected measurement group. */
  public MeasureGroup getSelectedGroup() {
    Object o = groupList.getSelectedItem();
    return o instanceof MeasureGroup ? (MeasureGroup) o : null;
  }

  /** Sets the currently selected measurement group. */
  public void setSelectedGroup(MeasureGroup group) {
    groupList.setSelectedItem(group);
  }

  /** Gets the current list of measurement groups. */
  public Vector getMeasureGroups() {
    int size = groupList.getItemCount();
    Vector v = new Vector(size);
    for (int i=0; i<size; i++) v.add(groupList.getItemAt(i));
    return v;
  }

  /** Sets the current list of measurement groups. */
  public void setMeasureGroups(Vector v) {
    int ndx = groupList.getSelectedIndex();
    groupList.removeAllItems();
    int size = v.size();
    for (int i=0; i<size; i++) groupList.addItem(v.elementAt(i));
    if (ndx < groupList.getItemCount()) {
      groupList.setSelectedIndex(ndx);
    }
  }

  /** Enables or disables this tool panel. */
  public void setEnabled(boolean enabled) {
    useMicrons.setEnabled(enabled);
    sliceDistLabel.setEnabled(enabled);
    sliceDistance.setEnabled(enabled);
    zAspect.setEnabled(enabled);
    addLine.setEnabled(enabled);
    addMarker.setEnabled(enabled);
    addFlag.setEnabled(enabled);
    merge.setEnabled(enabled);
    clearAll.setEnabled(enabled);
    export.setEnabled(enabled);
    snap.setEnabled(enabled);
    snapNow.setEnabled(enabled);
  }

  /** Updates the GUI to match the current micron information. */
  public void updateAspect() {
    MeasureManager mm = (MeasureManager) lm;
    useMicrons.setSelected(mm.isUsingMicrons());
    double mw = mm.getMicronWidth();
    double mh = mm.getMicronHeight();
    useMicrons.setValues(mw == mw ? "" + mw : "", mh == mh ? "" + mh : "");
    double sd = mm.getSliceDistance();
    sliceDistance.setText(sd == sd ? "" + sd : "");
    zAspect.setSelected(mm.isUsingZAspect());
  }

  /** Updates the GUI to match currently selected measurements. */
  public void updateSelection() {
    MeasureManager mm = (MeasureManager) lm;
    MeasurePool pool2 = mm.getPool2D();
    boolean enabled = pool2.hasSelection();
    single.setEnabled(enabled);
    if (!enabled) standard2D.setEnabled(false);
    standard3D.setEnabled(enabled);
    updateRemove();
    colorLabel.setEnabled(enabled);
    colorList.setEnabled(enabled);
    groupLabel.setEnabled(enabled);
    groupList.setEnabled(enabled);
    newGroup.setEnabled(enabled);
    descriptionLabel.setEnabled(enabled);
    descriptionBox.setEnabled(enabled);
    if (enabled) {
      int stdType = pool2.getSelectionStandardType();
      if (stdType == MeasureManager.STD_SINGLE && !single.isSelected()) {
        ignoreStandard = true;
        single.setSelected(true);
      }
      else if (stdType == MeasureManager.STD_2D && !standard2D.isSelected()) {
        ignoreStandard = true;
        standard2D.setSelected(true);
      }
      else if (stdType == MeasureManager.STD_3D && !standard3D.isSelected()) {
        ignoreStandard = true;
        standard3D.setSelected(true);
      }
      Color c = pool2.getSelectionColor();
      if (colorList.getSelectedItem() != c) colorList.setSelectedItem(c);
      MeasureGroup g = pool2.getSelectionGroup();
      if (groupList.getSelectedItem() != g) groupList.setSelectedItem(g);
    }
    synchronized (cell) {
      try {
        cell.disableAction();
        cell.removeAllReferences();
        boolean trigger = !enabled;
        if (enabled) {
          PoolPoint[] pts = pool2.getSelectionPts();
          for (int i=0; i<pts.length; i++) {
            if (pts[i] != null) cell.addReference(pts[i].ref);
          }
          if (pts.length == 0) trigger = true;
        }
        cell.enableAction();
        if (trigger) cell.doAction();
      }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
    }
  }

  /** Updates GUI to match given standard value. */
  public void updateStandard(int stdType) {
    ignoreStandard = true;
    if (stdType == MeasureManager.STD_2D) standard2D.setSelected(true);
    else if (stdType == MeasureManager.STD_3D) standard3D.setSelected(true);
  }

  /** Updates the remove button. */
  public void updateRemove() {
    MeasureManager mm = (MeasureManager) lm;
    MeasureThing[] selThings = mm.getPool2D().getSelection();
    boolean noStd = selThings.length > 0;
    for (int i=0; i<selThings.length; i++) {
      if (selThings[i].stdId >= 0) {
        noStd = false;
        break;
      }
    }
    removeSelected.setEnabled(noStd);
  }


  // -- Helper methods --

  /** Updates the text in the measurement information box. */
  private void updateMeasureInfo() {
    String coord = "";
    String dist = "";
    MeasureManager mm = (MeasureManager) lm;
    MeasurePool pool2 = mm.getPool2D();
    int stackAxis = mm.getStackAxis();
    if (pool2.hasSingleSelection()) {
      Object thing = pool2.getSelection()[0];

      // compute measurement unit info
      double mx = 1, my = 1, sd = 1;
      String unit = "pix";
      VisBio bio = lm.getVisBio();
      boolean use = mm.isUsingMicrons();
      double mw = mm.getMicronWidth();
      double mh = mm.getMicronHeight();
      double z = mm.getSliceDistance();
      int res_x = mm.getResX();
      int res_y = mm.getResY();
      double x = mw / res_x;
      double y = mh / res_y;
      if (use && x == x && y == y && z == z) {
        mx = x;
        my = y;
        sd = z;
        unit = "�";
      }

      // compute measurement information
      if (thing instanceof MeasureLine) {
        MeasureLine line = (MeasureLine) thing;
        String vx = Convert.shortString(mx * line.ep1.x);
        String vy = Convert.shortString(my * line.ep1.y);
        String v2x = Convert.shortString(mx * line.ep2.x);
        String v2y = Convert.shortString(my * line.ep2.y);
        double z1 = 0, z2 = 0;
        if (stackAxis >= 0) {
          z1 = line.ep1.pos[stackAxis];
          z2 = line.ep2.pos[stackAxis];
        }
        double[] p = {line.ep1.x, line.ep1.y, z1};
        double[] q = {line.ep2.x, line.ep2.y, z2};
        double[] m = {mx, my, sd};
        String d = Convert.shortString(BioUtil.getDistance(p, q, m));
        coord = "(" + vx + ", " + vy + ")-(" + v2x + ", " + v2y + ")";
        dist = "distance = " + d + " " + unit;
      }
      else if (thing instanceof MeasurePoint) {
        MeasurePoint point = (MeasurePoint) thing;
        String vx = Convert.shortString(mx * point.x);
        String vy = Convert.shortString(my * point.y);
        coord = "(" + vx + ", " + vy + ")";
      }
    }

    // update 2-D and 3-D standard choices
    if (pool2.hasSelection()) {
      boolean std2d = true;
      MeasureThing[] selection = pool2.getSelection();
      for (int i=0; i<selection.length; i++) {
        MeasureThing m = selection[i];
        if (m instanceof MeasureLine) {
          MeasureLine line = (MeasureLine) m;
          double z1 = 0, z2 = 0;
          if (stackAxis >= 0) {
            z1 = line.ep1.pos[stackAxis];
            z2 = line.ep2.pos[stackAxis];
          }
          if (z1 != z2 || z1 != (int) z1) {
            // cannot set multi-slice lines to 2-D standard
            std2d = false;
          }
          MeasurePoint pt1 = line.ep1;
        }
      }
      standard2D.setEnabled(std2d);
    }

    // construct measurement info strings
    StringBuffer sb = new StringBuffer();
    int space = (COORD_LABEL.length() - coord.length()) / 2;
    for (int i=0; i<space; i++) sb.append(" ");
    String coordSpace = sb.toString();

    sb = new StringBuffer();
    space = (DIST_LABEL.length() - dist.length()) / 2;
    for (int i=0; i<space; i++) sb.append(" ");
    String distSpace = sb.toString();

    measureCoord.setText(coordSpace + coord + coordSpace);
    measureDist.setText(distSpace + dist + distSpace);
  }

  /** Gets the image width in microns entered by the user. */
  private double getMicronWidth() {
    double d = Convert.getDouble(useMicrons.getFirstValue());
    return d <= 0 ? Double.NaN : d;
  }

  /** Gets the image height in microns entered by the user. */
  private double getMicronHeight() {
    double d = Convert.getDouble(useMicrons.getSecondValue());
    return d <= 0 ? Double.NaN : d;
  }

  /** Gets the micron distance between slices entered by the user. */
  private double getSliceDistance() {
    double d = Convert.getDouble(sliceDistance.getText());
    return d <= 0 ? Double.NaN : d;
  }

}
