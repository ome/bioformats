//
// MeasureManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.Color;
import java.io.*;
import java.rmi.RemoteException;
import java.util.*;

import loci.visbio.*;
import loci.visbio.data.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.*;
import loci.visbio.util.BioUtil;
import loci.visbio.view.ViewManager;

import visad.*;

/** MeasureManager is the class encapsulating VisBio's measurement logic. */
public class MeasureManager extends LogicManager {

  // -- Constants --

  /** Constant for single measurement mode. */
  public static final int STD_SINGLE = 1;

  /** Constant for "2-D standard" measurement mode. */
  public static final int STD_2D = 2;

  /** Constant for "3-D standard" measurement mode. */
  public static final int STD_3D = 3;

  /** Maximum number of measurement pools. */
  public static final int MAX_POOLS = 2;


  // -- Control panel --

  /** Measure control panel. */
  private MeasurePanel measurePanel;


  // -- Micron fields --

  /** Whether to use micron distances to set display's aspect ratio. */
  private boolean useMicrons;

  /** Dimensions of each image in microns. */
  private double mw, mh;

  /** Distance between each slice in microns. */
  private double sd;

  /** Whether to use micron information for display's Z-scale. */
  private boolean zAspect;


  // -- Data fields --

  /** Resolution of each image. */
  private int res_x, res_y;
  
  /** Number of Z-axis slices. */
  private int slices;


  // -- Measurement fields --

  /** Measurement lists corresponding to screen datasets. */
  private Hashtable lists;

  /** Active measurement list. */
  private MeasureList active;

  /** Measurement pool for 2-D display. */
  private MeasurePool pool2;

  /** Measurement pool for 3-D display. */
  private MeasurePool pool3;


  // -- Other fields --

  /** Tuple type for (r, g, b) range. */
  private RealTupleType colorRange;

  /** Default measurement group. */
  private MeasureGroup noneGroup;


  // -- Constructor --

  /** Constructs a measurement manager. */
  public MeasureManager(VisBio biovis) { super(biovis); }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      String msg = evt.getMessage();
      if (lm instanceof DataManager) {
        DataManager dm = (DataManager) lm;
        if (msg.equals("create screen dataset")) {
          Vector screens = dm.getScreenDatasets();
          int size = screens.size();
          for (int i=0; i<size; i++) {
            ScreenData screen = (ScreenData) screens.elementAt(i);
            MeasureList list = (MeasureList) lists.get(screen);
            if (list == null) {
              list = new MeasureList(this, screen);
              lists.put(screen, list);
            }
          }
        }
      }
      if (lm instanceof ViewManager) {
        ViewManager vm = (ViewManager) lm;
        if (msg.equals("displays ready")) {
          pool2.uninit();
          if (pool3 != null) pool3.uninit();
          ScreenData screen = vm.getScreenData();
          if (screen == null) {
            setActiveList(null);
            measurePanel.setEnabled(false);
          }
          else {
            // get screen dataset resolution
            ScreenDescriptor desc = screen.getDescriptor();
            int stackAxis = desc.stackAxis;
            res_x = desc.raw.getImageWidth();
            res_y = desc.raw.getImageHeight();
            slices = stackAxis < 0 ? 1 : screen.getLengths()[stackAxis];

            // set active measurement list
            setActiveList((MeasureList) lists.get(screen));
            measurePanel.setEnabled(true);
          }
        }
        else if (msg.equals("position change")) setPos(vm.getPos());
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 4; }


  // -- Saveable API methods --

  /** Writes the current state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    // save micron information
    fout.println(useMicrons);
    fout.println(mw);
    fout.println(mh);
    fout.println(sd);
    fout.println(zAspect);

    // save measurement groups
    Vector groups = measurePanel.getMeasureGroups();
    int num = groups.size();
    fout.println(num);
    for (int i=0; i<num; i++) {
      ((MeasureGroup) groups.elementAt(i)).saveState(fout);
    }

    // save current measurement group index
    MeasureGroup group = measurePanel.getSelectedGroup();
    fout.println(groups.indexOf(group));

    // save measurement lists
    DataManager dm = (DataManager) bio.getManager(DataManager.class);
    Vector screens = dm.getScreenDatasets();
    int size = screens.size();
    for (int i=0; i<size; i++) {
      ScreenData screen = (ScreenData) screens.elementAt(i);
      MeasureList list = (MeasureList) lists.get(screen);
      list.saveState(fout);
    }
  }

  /** Restores the current state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    // restore micron information
    try {
      useMicrons = fin.readLine().equals("true");
      mw = BioUtil.readDouble(fin);
      mh = BioUtil.readDouble(fin);
      sd = BioUtil.readDouble(fin);
      zAspect = fin.readLine().equals("true");
      updateAspect();
      measurePanel.updateAspect();
    }
    catch (IOException exc) { exc.printStackTrace(); }

    // restore measurement groups
    int num;
    try { num = Integer.parseInt(fin.readLine()); }
    catch (IOException exc) { throw new SaveException(exc); }
    Vector old_groups = measurePanel.getMeasureGroups();
    Vector new_groups = new Vector(num);
    for (int i=0; i<num; i++) {
      MeasureGroup group = new MeasureGroup();
      group.restoreState(fin);
      new_groups.add(group);
    }
    StateManager.mergeStates(old_groups, new_groups);
    measurePanel.setMeasureGroups(new_groups);

    // restore current measurement group
    int cur;
    try { cur = Integer.parseInt(fin.readLine()); }
    catch (IOException exc) { throw new SaveException(exc); }
    if (cur < 0 || cur >= num) measurePanel.setSelectedGroup(null);
    else {
      MeasureGroup group = (MeasureGroup) new_groups.elementAt(cur);
      measurePanel.setSelectedGroup(group);
    }

    // restore measurement lists
    DataManager dm = (DataManager) bio.getManager(DataManager.class);
    Vector screens = dm.getScreenDatasets();
    int size = screens.size();
    Vector old_list = new Vector(lists.values());
    Vector new_list = new Vector(size);
    for (int i=0; i<size; i++) {
      ScreenData screen = (ScreenData) screens.elementAt(i);
      MeasureList list = new MeasureList(this, screen);
      list.restoreState(fin);
      new_list.add(list);
    }
    StateManager.mergeStates(old_list, new_list);

    // update lists hashtable
    lists.clear();
    for (int i=0; i<size; i++) {
      ScreenData screen = (ScreenData) screens.elementAt(i);
      lists.put(screen, (MeasureList) new_list.elementAt(i));
    }

    // restore active measurement list
    ScreenData screen = dm.getScreenData();
    MeasureList list = screen == null ? null : (MeasureList) lists.get(screen);
    setActiveList(list);
  }


  // -- New API methods: mutators --

  /** Sets image dimension lengths in microns. */
  public void setUseMicrons(boolean b, double width, double height) {
    useMicrons = b;
    mw = width;
    mh = height;
    updateAspect();
  }

  /** Sets distance between each slice in microns. */
  public void setSliceDistance(double dist) {
    sd = dist;
    updateAspect();
  }

  /** Sets whether micron information is used for Z-scale. */
  public void setZAspect(boolean b) {
    zAspect = b;
    updateAspect();
  }

  /** Sets the active measurement list. */
  public void setActiveList(MeasureList list) {
    int[] pos = null;
    if (active != null) pos = active.getPos();
    active = list;
    if (active != null && pos != null) active.setPos(pos);
    pool2.setList(active);
    if (pool3 != null) pool3.setList(active);
  }

  /** Updates the GUI to match the currently selected measurements. */
  public void updateSelection() { measurePanel.updateSelection(); }

  /** Refreshes the measurement pools. */
  public void refreshPools(boolean reconstruct) {
    pool2.refresh(reconstruct);
    if (pool3 != null) pool3.refresh(reconstruct);
  }

  /** Updates the GUI to match the given standard value. */
  public void updateStandard(int stdType) {
    measurePanel.updateStandard(stdType);
  }

  /** Updates the remove button. */
  public void updateRemove() { measurePanel.updateRemove(); }


  // -- New API methods: accessors --

  /** Gets whether micron distance are being used for display aspect ratio. */
  public boolean isUsingMicrons() { return useMicrons; }

  /** Gets width of each image in microns. */
  public double getMicronWidth() { return mw; }

  /** Gets height of each image in microns. */
  public double getMicronHeight() { return mh; }

  /** Gets distance between each slice in microns. */
  public double getSliceDistance() { return sd; }

  /** Gets whether micron information is being used for display's Z-scale. */
  public boolean isUsingZAspect() { return zAspect; }

  /** Gets the 2-D measurement pool. */
  public MeasurePool getPool2D() { return pool2; }

  /** Gets the 3-D measurement pool. */
  public MeasurePool getPool3D() { return pool3; }

  /** Gets the list of measurement groups. */
  public Vector getMeasureGroups() { return measurePanel.getMeasureGroups(); }

  /** Gets the default measurement group. */
  public MeasureGroup getNoneGroup() { return noneGroup; }


  // -- MeasureList API wrappers: mutators --

  /** Sets position within multidimensional structure. */
  public void setPos(int[] pos) {
    if (active == null) return;
    active.setPos(pos);
  }

  /** Adds a new line. */
  public void addLine() {
    if (active == null) return;
    active.addLine();
    bio.generateEvent(this, "add line", true);
  }

  /** Adds a new marker. */
  public void addMarker() {
    if (active == null) return;
    active.addMarker();
    bio.generateEvent(this, "add marker", true);
  }

  /** Adds a new flag. */
  public void addFlag() {
    if (active == null) return;
    active.addFlag();
    bio.generateEvent(this, "add flag", true);
  }

  /** Sets merge state. */
  public void setMerge(boolean merge) {
    if (active == null) return;
    active.setMerge(merge);
  }

  /** Removes selected measurements. */
  public void removeSelected() {
    if (active == null) return;
    active.removeSelected();
    bio.generateEvent(this, "remove selected measurements", true);
  }

  /** Removes all measurements. */
  public void removeAll() {
    if (active == null) return;
    active.removeAll();
    bio.generateEvent(this, "remove all measurements", true);
  }

  /** Exports measurements to the given file. */
  public void export(File file) {
    if (active == null) return;
    active.export(file);
  }

  /** Snaps all measurements to closest slice. */
  public void snapNow() {
    if (active == null) return;
    active.snapNow();
    bio.generateEvent(this, "measurement snapping", true);
  }

  /** Sets whether measurements automatically snap to closest slice. */
  public void setSnap(boolean snap) {
    if (active == null) return;
    active.setSnap(snap);
  }

  /** Sets the selected measurements to the given standard type. */
  public void setStandard(int stdType) {
    if (active == null) return;
    active.setStandard(stdType);
    bio.generateEvent(this, "set standard", true);
  }

  /** Sets the color of the selected measurements. */
  public void setColor(Color color) {
    if (active == null) return;
    active.setColor(color);
    bio.generateEvent(this, "set measurement color", true);
  }

  /** Sets the group of the selected measurements. */
  public void setGroup(MeasureGroup group) {
    if (active == null) return;
    active.setGroup(group);
    bio.generateEvent(this, "set measurement group", true);
  }


  // -- MeasureList API wrappers: accessors --

  /** Gets position within multidimensional structure. */
  public int[] getPos() { return active.getPos(); }

  /** Gets positional index for Z-stack. */
  public int getStackAxis() { return active.getStackAxis(); }

  /** Gets RealType list for domain of active measurement list. */
  public RealType[] getTypes() { return active.getTypes(); }

  /** Gets 2-D domain for active measurement list. */
  public RealTupleType getDomain2D() { return active.getDomain2D(); }

  /** Gets 3-D domain for active measurement list. */
  public RealTupleType getDomain3D() { return active.getDomain3D(); }

  /** Gets tuple type for (r, g, b) range. */
  public RealTupleType getColorRange() { return colorRange; }

  /** Gets X resolution of screen dataset. */
  public int getResX() { return active.getResX(); }

  /** Gets Y resolution of screen dataset. */
  public int getResY() { return active.getResY(); }

  /** Gets number of slices in active measurement list. */
  public int getNumberOfSlices() { return active.getNumberOfSlices(); }

  /** Gets minimum slice value of screen dataset. */
  public int getStackMin() { return active.getStackMin(); }

  /** Gets maximum slice value of screen dataset. */
  public int getStackMax() { return active.getStackMax(); }

  /** Gets stack step value for screen dataset. */
  public int getStackStep() { return active.getStackStep(); }

  /** Gets whether measurements should automatically snap to closest slice. */
  public boolean isSnap() { return active.isSnap(); }

  /** Gets merge state. */
  public boolean isMerge() { return active.isMerge(); }


  // -- Helper methods --

  /** Adds view-related GUI components to VisBio. */
  private void doGUI() {
    bio.setStatus("Initializing measurement logic");
    useMicrons = false;
    mw = Double.NaN;
    mh = Double.NaN;
    sd = Double.NaN;
    zAspect = true;
    lists = new Hashtable();
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    if (vm != null) {
      try {
        colorRange = new RealTupleType(vm.getRedType(),
          vm.getGreenType(), vm.getBlueType());
      }
      catch (VisADException exc) { exc.printStackTrace(); }
    }
    noneGroup = new MeasureGroup("None");

    // create measure pools and add them to ViewManager's displays
    bio.setStatus(null);
    if (vm != null) {
      DisplayImpl display2 = vm.getDisplay2D();
      if (display2 != null) pool2 = new MeasurePool(this, display2, 2);
      DisplayImpl display3 = vm.getDisplay3D();
      if (display3 != null) pool3 = new MeasurePool(this, display3, 3);
    }

    // control panel
    bio.setStatus(null);
    measurePanel = new MeasurePanel(this);
    PanelManager pm = (PanelManager) bio.getManager(PanelManager.class);
    if (pm != null) pm.addPanel(measurePanel);

    // help window
    bio.setStatus(null);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.addHelpTopic("Measure", "measure.html");
  }

  /** Updates the Z-aspect and micron information. */
  private void updateAspect() {
    ViewManager vm = (ViewManager) bio.getManager(ViewManager.class);
    double x, y, z;
    if (useMicrons && mw == mw && mh == mh) {
      x = mw;
      y = mh;
      z = zAspect && sd == sd ? slices * sd : Double.NaN;
    }
    else {
      x = res_x;
      y = res_y;
      z = Double.NaN;
    }
    vm.setAspect(x, y, z);
  }

}
