//
// MeasureFlag.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.Color;
import java.io.PrintWriter;
import java.util.Vector;

import loci.visbio.VisBio;
import loci.visbio.util.BioUtil;

/** A flag in the list of measurements. */
public class MeasureFlag extends MeasurePoint {

  // -- Constructors --

  /** Constructs a flag with the given coordinates, color and group. */
  public MeasureFlag(double x, double y, Color color, MeasureGroup group) {
    super(x, y, null, color, group);
  }

  /** Constructs a flag cloned from the given flag. */
  public MeasureFlag(MeasureFlag flag) { super(flag, null); }

  /**
   * Constructs a flag cloned from the given flag,
   * but with a (possibly) different set of coordinates.
   */
  public MeasureFlag(MeasureFlag flag, double x, double y) {
    super(flag, x, y, null);
  }


  // -- New API methods --

  /** Sets the coordinates of the flag to match those given. */
  public void setCoordinates(PoolPoint p, double x, double y) {
    if (this.x == x && this.y == y) return;
    this.x = x;
    this.y = y;
    for (int i=0; i<pt.length; i++) {
      if (pt[i] != null && pt[i] != p) pt[i].refresh();
    }
  }


  // -- Object API methods --

  /** Gets a string representation of this measurement point. */
  public String toString() {
    return super.toString() + ":\n" +
      "    color=" + color + "\n" +
      "    group=" + group + "\n" +
      "    stdType=" + stdType + "\n" +
      "    stdId=" + stdId + "\n" +
      "    selected=" + selected + "\n" +
      "    preferredColor=" + preferredColor + "\n" +
      "    x=" + x + "\n" +
      "    y=" + y;
  }

}
