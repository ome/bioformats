//
// PoolPoint.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.rmi.RemoteException;

import loci.visbio.VisBio;
import loci.visbio.util.BioUtil;

import visad.*;
import visad.java2d.*;
import visad.java3d.*;

/** PoolPoint is a single measurement pool endpoint. */
public class PoolPoint {

  // -- Fields --

  /** Associated data reference. */
  DataReferenceImpl ref;

  /** Measurement endpoint currently linked to this pool point. */
  MeasurePoint point;

  /** Measurement manager. */
  private MeasureManager mm;

  /** Associated VisAD display. */
  private DisplayImpl display;

  /** Associated direct manipulation renderer. */
  private DataRenderer renderer;

  /** Dimensionality of the pool point's display. */
  private int dim;


  // -- Constructor --

  /** Constructs a point for use in the measurement pool. */
  public PoolPoint(MeasureManager mman, DisplayImpl display,
    String name, int dimension)
  {
    mm = mman;
    this.display = display;
    try { ref = new DataReferenceImpl("bio_" + name); }
    catch (VisADException exc) { exc.printStackTrace(); }
    dim = dimension;

    // update linked measurement endpoint when pool point changes
    final PoolPoint pt = this;
    CellImpl cell = new CellImpl() {
      public void doAction() {
        if (point == null) return;
        RealTuple tuple = (RealTuple) ref.getData();
        if (tuple == null) return;
        double[] v = tuple.getValues();

        // construct dimensional position array
        int[] p = mm.getPos();
        int stackAxis = mm.getStackAxis();
        double[] pos = new double[p.length];
        for (int i=0; i<p.length; i++) pos[i] = p[i];
        if (stackAxis >= 0) {
          if (point.pos == null) pos[stackAxis] = 0;
          else if (dim == 2) pos[stackAxis] = point.pos[stackAxis];
          else pos[stackAxis] = v[2];
        }

        // snap Z-coordinate to nearest slice
        if (mm.isSnap()) {
          int min = mm.getStackMin();
          int max = mm.getStackMax();
          int step = mm.getStackStep();
          if (stackAxis >= 0) {
            pos[stackAxis] =
              BioUtil.getNearest(pos[stackAxis], min, max, step);
          }
        }

        point.setCoordinates(pt, v[0], v[1], pos);
      }
    };
    try { cell.addReference(ref); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }


  // -- API methods --

  /** Adds the point to the associated display. */
  public void init() throws VisADException, RemoteException {
    renderer = display instanceof DisplayImplJ3D ?
      (DataRenderer) new DirectManipulationRendererJ3D() :
      (DataRenderer) new DirectManipulationRendererJ2D();
    renderer.setPickCrawlToCursor(false);
    renderer.suppressExceptions(true);
    renderer.toggle(false);
    display.addReferences(renderer, ref);
  }

  /** Toggles the renderer visible or invisible. */
  public void toggle(boolean on) { renderer.toggle(on); }

  /** Refreshes the point's coordinates to match the linked endpoint. */
  public void refresh() {
    if (point == null) {
      renderer.toggle(false);
      return;
    }
    renderer.toggle(true);
    try {
      RealTuple tuple = (RealTuple) ref.getData();

      int stackAxis = mm.getStackAxis();
      double[] v = {Double.NaN, Double.NaN};
      if (tuple != null) {
        v = tuple.getValues();
        if (v[0] == point.x && v[1] == point.y) {
          double z = stackAxis >= 0 ? point.pos[stackAxis] : 0.0;
          if (dim == 2 || v[2] == z) return;
        }
      }
      if (dim == 3) {
        RealTupleType domain3 = mm.getDomain3D();
        double z = stackAxis >= 0 && point.pos != null ?
          point.pos[stackAxis] : 0.0;
        ref.setData(new RealTuple(domain3, new double[] {
          point.x, point.y, z
        }));
      }
      else { // dim == 2
        RealTupleType domain2 = mm.getDomain2D();
        ref.setData(new RealTuple(domain2, new double[] {point.x, point.y}));
      }
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

}
