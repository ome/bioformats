//
// MeasureThing.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.Color;
import java.io.PrintWriter;

import loci.visbio.util.BioUtil;

/**
 * MeasureThing is the base class for measurement
 * constructs such as lines and points.
 */
public abstract class MeasureThing {

  // -- Fields --

  /** Color of this measurement. */
  public Color color;

  /** Group of this measurement. */
  public MeasureGroup group;

  /** Standard id type. */
  public int stdType = MeasureManager.STD_SINGLE;

  /** Standard id tag. -1 if not a standard line. */
  public int stdId = -1;


  // -- New API methods --

  /** Sets the color of this measurement to match the given color. */
  public abstract void setColor(Color color);

  /** Sets the standard id of this measurement to match the given id. */
  public void setStandard(int stdType, int stdId) {
    this.stdType = stdType;
    this.stdId = stdId;
  }

  /** Gets whether the measurement is standard. */
  public boolean isStandard() { return stdId != -1; }

}
