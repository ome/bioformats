//
// MeasurePool.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.measure;

import java.awt.*;
import java.awt.event.*;
import java.rmi.RemoteException;
import java.util.*;

import loci.visbio.VisBio;
import loci.visbio.util.BioUtil;

import visad.*;
import visad.bom.RubberBandBoxRendererJ3D;
import visad.java3d.DisplayImplJ3D;

/**
 * MeasurePool maintains a pool of manipulable points and a set of
 * connecting lines, for interactive data measurement in the given display.
 */
public class MeasurePool implements DisplayListener {

  // -- Constants --

  /** Maximum pixel distance for picking. */
  private static final int PICKING_THRESHOLD = 10;

  /** Number of extra points to add when number of points is expanded. */
  private static final int BUFFER_SIZE = 15;


  // -- Static fields --

  /** Measurement pool counter. */
  private static int numPools = 0;


  // -- General fields --

  /** Associated MeasureManager. */
  private MeasureManager mm;

  /** Id of this measurement pool. */
  private int pid;

  /** Associated VisAD display. */
  private DisplayImpl display;

  /** Dimensionality of measurement pool's display. */
  private int dim;

  /** Currently linked list of measurements. */
  private MeasureList list;

  /** Whether the measurement pool has been initialized. */
  private boolean inited = false;

  /** Whether measurement endpoints have moved since last mouse press. */
  private boolean ptsChanged = false;


  // -- Pool element fields --

  /** Internal stack of free PoolPoints. */
  private Stack free;

  /** Internal list of used PoolPoints. */
  private Vector used;

  /**
   * Cell for updating linked measurement endpoints, solid lines,
   * dashed lines and colored endpoints when a pool point changes.
   */
  private CellImpl lineCell;

  /** Cell for handling rubber band box selections. */
  private CellImpl boxCell;


  // -- Selection fields --

  /** List of selected lines. */
  private Vector selLines;

  /** List of selected markers. */
  private Vector selPoints;


  // -- Special data references --

  /** Data reference for colored line segments. */
  private DataReferenceImpl solidLines;

  /** Data renderer for colored line segments. */
  private DataRenderer lineRenderer;

  /** Data reference for dashed line segments. */
  private DataReferenceImpl dashedLines;

  /** Data renderer for dashed line segments. */
  private DataRenderer dashedRenderer;

  /** Data reference for colored endpoints. */
  private DataReferenceImpl coloredPoints;

  /** Data renderer for colored endpoints. */
  private DataRenderer pointRenderer;

  /** Data reference for rubber band box. */
  private DataReferenceImpl rubberBand;

  /** Data renderer for rubber band box. */
  private DataRenderer boxRenderer;


  // -- Constructor --

  /** Constructs a pool of measurements. */
  public MeasurePool(MeasureManager mman, DisplayImpl display, int dimension) {
    mm = mman;
    pid = numPools++;
    this.display = display;
    dim = dimension;
    free = new Stack();
    used = new Vector();
    try {
      solidLines = new DataReferenceImpl("bio_solid_lines");
      dashedLines = new DataReferenceImpl("bio_dashed_lines");
      coloredPoints = new DataReferenceImpl("bio_colored_points");
      rubberBand = new DataReferenceImpl("bio_rubber_band");
    }
    catch (VisADException exc) { exc.printStackTrace(); }

    selLines = new Vector();
    selPoints = new Vector();

    lineCell = new CellImpl() {
      public void doAction() {
        // redraw colored lines and points when endpoints change
        if (lineRenderer == null) return;
        Vector solidStrips = new Vector();
        Vector dashedStrips = new Vector();
        Vector pointStrips = new Vector();
        Vector solidColors = new Vector();
        Vector dashedColors = new Vector();
        Vector pointColors = new Vector();
        boolean sel = hasSelection();
        int[] pos = list.getPos();
        int stackAxis = list.getStackAxis();

        // compute list of line strips
        Vector lines = list.getLines();
        int lsize = lines.size();
        for (int i=0; i<lsize; i++) {
          MeasureLine line = (MeasureLine) lines.elementAt(i);

          // ensure at least one endpoint is within dimensional range
          boolean doPt1 = true;
          boolean doPt2 = true;
          for (int j=0; j<pos.length; j++) {
            if (dim == 3 && j == stackAxis) continue;
            if (pos[j] != line.ep1.pos[j]) doPt1 = false;
            if (pos[j] != line.ep2.pos[j]) doPt2 = false;
          }
          if (line.ep1.pt[pid] != null) line.ep1.pt[pid].toggle(doPt1);
          if (line.ep2.pt[pid] != null) line.ep2.pt[pid].toggle(doPt2);
          if (!doPt1 && !doPt2) continue;

          // create gridded set from this line
          GriddedSet set = doSet(new MeasurePoint[] {line.ep1, line.ep2});
          if (line.selected) {
            dashedStrips.add(set);
            dashedColors.add(line.color);
            dashedColors.add(line.color);
          }
          else {
            solidStrips.add(set);
            solidColors.add(line.color);
            solidColors.add(line.color);
          }

          // check for any needed X's
          if (dim == 2) doXs(line, solidStrips, solidColors);
        }

        // compute list of point strips
        Vector points = list.getPoints();
        int psize = points.size();
        for (int i=0; i<psize; i++) {
          MeasurePoint point = (MeasurePoint) points.elementAt(i);

          // ensure endpoint is within dimensional range
          boolean doPt = true;
          for (int j=0; j<pos.length; j++) {
            if (dim == 3 && j == stackAxis) continue;
            if (pos[j] != point.pos[j]) {
              doPt = false;
              break;
            }
          }
          if (!doPt) continue;

          pointStrips.add(point);
          pointColors.add(point.selected > 0 ? Color.yellow : point.color);
        }
        Vector flags = list.getFlags();
        int fsize = flags.size();
        for (int i=0; i<fsize; i++) {
          MeasureFlag flag = (MeasureFlag) flags.elementAt(i);
          pointStrips.add(flag);
          pointColors.add(flag.selected > 0 ? Color.yellow : flag.color);
        }

        doLines(solidStrips, solidColors, solidLines, lineRenderer);
        doLines(dashedStrips, dashedColors, dashedLines, dashedRenderer);
        doPoints(pointStrips, pointColors, coloredPoints, pointRenderer);
        if (m_down && !m_shift) ptsChanged = true;
      }
    };

    boxCell = new CellImpl() {
      public void doAction() {
        // select measurements within the rubber band box
        if (boxRenderer == null) return;
        GriddedSet set = (GriddedSet) rubberBand.getData();
        float[][] samples = null;
        try { samples = set.getSamples(); }
        catch (VisADException exc) { exc.printStackTrace(); }
        if (samples == null) return;
        double x1 = (double) samples[0][0];
        double y1 = (double) samples[1][0];
        double x2 = (double) samples[0][1];
        double y2 = (double) samples[1][1];
        int[] pos = list.getPos();

        if (list.isMerge()) {
          // merge all endpoints lying within rectangle bounds
          double sum_x = 0, sum_y = 0;
          Vector mpts = new Vector();
          Vector points = list.getPoints();
          int psize = points.size();
          for (int i=0; i<psize; i++) {
            MeasurePoint point = (MeasurePoint) points.elementAt(i);

            // skip points that are not at this position
            boolean valid = true;
            for (int j=0; j<pos.length; j++) {
              if (point.pos[j] != pos[j]) {
                valid = false;
                break;
              }
            }
            if (!valid) continue;

            // check for containment
            if (contains(x1, y1, x2, y2, point.x, point.y)) {
              sum_x += point.x;
              sum_y += point.y;
              mpts.add(point);
            }
          }

          int num_pts = mpts.size();
          if (num_pts == 0) {
            list.setMerge(false);
            return;
          }

          MeasurePoint first = (MeasurePoint) mpts.firstElement();
          MeasurePoint merged = new MeasurePoint(sum_x / num_pts,
            sum_y / num_pts, first.pos, first.color, first.group);

          // replace line endpoints with merged point
          for (int i=0; i<num_pts; i++) {
            MeasurePoint point = (MeasurePoint) mpts.elementAt(i);

            // point is a marker; remove from measurement list
            if (point.lines.isEmpty()) {
              list.removeMarker(point);
              continue;
            }

            // point is endpoint for one or more lines
            int j = 0;
            while (j < point.lines.size()) {
              MeasureLine line = (MeasureLine) point.lines.elementAt(j);
              if (line.ep1 == point || line.ep2 == point) {
                list.removeLine(line);
                if (line.ep1 == point) line.ep1 = merged;
                if (line.ep2 == point) line.ep2 = merged;
                if (line.ep1 != line.ep2) {
                  line.ep1.lines.add(line);
                  line.ep2.lines.add(line);
                  list.addLine(line);
                }
              }
              else j++;
            }
          }
          merged.refreshColor();

          if (merged.lines.isEmpty()) {
            // add merged point back as a marker
            list.addMarker(merged);
          }
          mm.refreshPools(true);
          mm.updateSelection();
          mm.setMerge(false);
        }
        else {
          // select all measurements lying within rectangle bounds
          Vector lines = list.getLines();
          int lsize = lines.size();
          boolean first = !hasSelection();
          for (int i=0; i<lsize; i++) {
            MeasureLine line = (MeasureLine) lines.elementAt(i);

            // skip lines not at this position
            boolean diff1 = false, diff2 = false;
            for (int j=0; j<pos.length; j++) {
              if (line.ep1.pos[j] != pos[j]) diff1 = true;
              if (line.ep2.pos[j] != pos[j]) diff2 = true;
            }
            if (diff1 && diff2) continue;

            // check for intersection
            if (intersects(x1, y1, x2, y2,
              line.ep1.x, line.ep1.y, line.ep2.x, line.ep2.y))
            {
              select(line);
              if (first) {
                // avoid bug where selecting multiple meausrements alters color
                mm.updateSelection();
                first = false;
              }
            }
          }
          Vector points = list.getPoints();
          int psize = points.size();
          for (int i=0; i<psize; i++) {
            MeasurePoint point = (MeasurePoint) points.elementAt(i);

            // skip points that are part of a line, or not at this position
            if (!point.lines.isEmpty()) continue;
            boolean valid = true;
            for (int j=0; j<pos.length; j++) {
              if (point.pos[j] != pos[j]) {
                valid = false;
                break;
              }
            }
            if (!valid) continue;

            // check for containment
            if (contains(x1, y1, x2, y2, point.x, point.y)) {
              select(point);
              if (first) {
                // avoid bug where selecting multiple measurements alters color
                mm.updateSelection();
                first = false;
              }
            }
          }
          Vector flags = list.getFlags();
          int fsize = flags.size();
          for (int i=0; i<fsize; i++) {
            MeasureFlag flag = (MeasureFlag) flags.elementAt(i);

            // check for containment
            if (contains(x1, y1, x2, y2, flag.x, flag.y)) {
              select(flag);
              if (first) {
                // avoid bug where selecting multiple measurements alters color
                mm.updateSelection();
                first = false;
              }
            }
          }
          mm.updateSelection();
          mm.refreshPools(true);
        }
      }
    };
    try { boxCell.addReference(rubberBand); }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }

    display.addDisplayListener(this);
    display.enableEvent(DisplayEvent.MOUSE_PRESSED);
    display.enableEvent(DisplayEvent.MOUSE_RELEASED);
    expand(BUFFER_SIZE, false);
  }


  // -- API methods --

  /** Flags the measurement pool for reinitialization. */
  public void uninit() { inited = false; }

  /** Grants the given endpoint use of a pool point. */
  public PoolPoint lease(MeasurePoint point) {
    expand(1, true);
    PoolPoint pt = (PoolPoint) free.pop();
    pt.point = point;
    used.add(pt);
    point.pt[pid] = pt;
    pt.refresh();
    return pt;
  }

  /** Returns the given endpoint's pool point to the measurement pool. */
  public void release(MeasurePoint point) { purge(point.pt[pid]); }

  /** Returns all pool points to the measurement pool. */
  public void releaseAll() {
    while (!used.isEmpty()) purge((PoolPoint) used.lastElement());
  }

  /** Creates measurement pool objects to match the given measurements. */
  public void setList(MeasureList list) {
    deselectAll();
    releaseAll();
    this.list = list;
    if (!inited && list != null) {
      // initialize measurement pool
      try {
        // solid line set
        lineRenderer = display.getDisplayRenderer().makeDefaultRenderer();
        lineRenderer.suppressExceptions(true);
        lineRenderer.toggle(false);
        display.addReferences(lineRenderer, solidLines);

        // dashed line set
        dashedRenderer = display.getDisplayRenderer().makeDefaultRenderer();
        dashedRenderer.suppressExceptions(true);
        dashedRenderer.toggle(false);
        display.addReferences(dashedRenderer, dashedLines, new ConstantMap[] {
          new ConstantMap(GraphicsModeControl.DASH_STYLE, Display.LineStyle)
        });

        // enlarged, colored endpoint set
        pointRenderer = display.getDisplayRenderer().makeDefaultRenderer();
        pointRenderer.suppressExceptions(true);
        pointRenderer.toggle(false);
        display.addReferences(pointRenderer, coloredPoints, new ConstantMap[] {
          new ConstantMap(5.0f, Display.PointSize)
        });

        // rubber band box
        if (dim == 2 && display instanceof DisplayImplJ3D) {
          RealType[] types = list.getTypes();
          RealTupleType domain2 =
            new RealTupleType(new RealType[] {types[0], types[1]});
          rubberBand.setData(new Gridded2DSet(domain2, null, 1));
          if (boxRenderer != null) display.removeReference(rubberBand);
          int m = InputEvent.SHIFT_MASK;
          boxRenderer = new RubberBandBoxRendererJ3D(types[0], types[1], m, m);
          display.addReferences(boxRenderer, rubberBand);
        }

        // direct manipulation endpoints
        int total = free.size();
        for (int i=0; i<total; i++) ((PoolPoint) free.elementAt(i)).init();
      }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
      inited = true;
    }
    refresh(true);
  }

  /** Refreshes the measurement endpoints in the pool. */
  public synchronized void refresh(boolean reconstruct) {
    if (list == null) return;

    // update endpoints
    Vector points = list.getPoints();
    int size = points.size();
    int[] pos = mm.getPos();
    int stackAxis = mm.getStackAxis();
    BioUtil.setDisplayDisabled(display, true);
    for (int i=0; i<size; i++) {
      MeasurePoint point = (MeasurePoint) points.elementAt(i);
      boolean on = true;
      for (int j=0; j<pos.length; j++) {
        if (dim == 3 && j == stackAxis) continue;
        if (point.pos[j] != pos[j]) {
          on = false;
          break;
        }
      }
      if (on) {
        if (point.pt[pid] == null) point.pt[pid] = lease(point);
        point.pt[pid].toggle(true);
      }
      else if (point.pt[pid] != null) point.pt[pid].toggle(false);
    }

    // update flags
    Vector flags = list.getFlags();
    size = flags.size();
    for (int i=0; i<size; i++) {
      MeasureFlag flag = (MeasureFlag) flags.elementAt(i);
      if (flag.pt[pid] == null) flag.pt[pid] = lease(flag);
      flag.pt[pid].toggle(true);
    }

    if (reconstruct) {
      try { lineCell.doAction(); }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
    }
    BioUtil.setDisplayDisabled(display, false);
  }

  /** Gets the display's dimensionality. */
  public int getDimension() { return dim; }

  /** Gets whether the measurement pool has any selected measurements. */
  public boolean hasSelection() {
    return !selLines.isEmpty() || !selPoints.isEmpty();
  }

  /** Gets whether the measurement pool has a single selected measurement. */
  public boolean hasSingleSelection() {
    return selLines.size() + selPoints.size() == 1;
  }

  /** Gets the list of selected measurements in array form. */
  public MeasureThing[] getSelection() {
    int lsize = selLines.size();
    int psize = selPoints.size();
    MeasureThing[] things = new MeasureThing[lsize + psize];
    for (int i=0; i<lsize; i++) {
      things[i] = (MeasureLine) selLines.elementAt(i);
    }
    for (int i=0; i<psize; i++) {
      things[i + lsize] = (MeasurePoint) selPoints.elementAt(i);
    }
    return things;
  }

  /**
   * Gets the standard type corresponding to the current selection.
   * If the selection consists of more than one standard type,
   * MeasureManager.STD_SINGLE is returned.
   */
  public int getSelectionStandardType() {
    int lsize = selLines.size();
    int stdType = -1;
    for (int i=0; i<lsize; i++) {
      MeasureLine line = (MeasureLine) selLines.elementAt(i);
      if (stdType == -1) stdType = line.stdType;
      else if (line.stdType != stdType) return MeasureManager.STD_SINGLE;
    }
    int psize = selPoints.size();
    for (int i=0; i<psize; i++) {
      MeasurePoint point = (MeasurePoint) selPoints.elementAt(i);
      if (stdType == -1) stdType = point.stdType;
      else if (point.stdType != stdType) return MeasureManager.STD_SINGLE;
    }
    return stdType;
  }

  /**
   * Gets the color corresponding to the current selection.  If the
   * selection consists of more than one color, the first color is returned.
   */
  public Color getSelectionColor() {
    int lsize = selLines.size();
    int psize = selPoints.size();
    if (lsize == 0 && psize == 0) return null;
    return lsize > 0 ?
      ((MeasureLine) selLines.firstElement()).color :
      ((MeasurePoint) selPoints.firstElement()).color;
  }

  /**
   * Gets the group corresponding to the current selection.  If the
   * selection consists of more than one group, the first group is returned.
   */
  public MeasureGroup getSelectionGroup() {
    int lsize = selLines.size();
    int psize = selPoints.size();
    if (lsize == 0 && psize == 0) return null;
    return lsize > 0 ?
      ((MeasureLine) selLines.firstElement()).group :
      ((MeasurePoint) selPoints.firstElement()).group;
  }


  // -- DisplayListener API methods --

  /** X and Y coordinates of left mouse press. */
  private int mx, my;

  /** Whether shift was held during left mouse press. */
  private boolean m_shift;

  /** Whether left mouse button is currently down. */
  private boolean m_down;

  /** Listens for mouse events in the display. */
  public void displayChanged(DisplayEvent e) {
    int id = e.getId();
    InputEvent event = e.getInputEvent();

    // ignore non-mouse display events
    if (event == null || !(event instanceof MouseEvent)) return;

    int x = e.getX();
    int y = e.getY();
    int mods = e.getModifiers();
    boolean left = (mods & InputEvent.BUTTON1_MASK) != 0;
    boolean right = (mods & InputEvent.BUTTON3_MASK) != 0;
    boolean shift = (mods & InputEvent.SHIFT_MASK) != 0;
    boolean ctrl = (mods & InputEvent.CTRL_MASK) != 0;

    // ignore events when there is no active measurement list
    if (list == null) return;

    // ignore CTRL events
    if (ctrl) return;

    if (left && id == DisplayEvent.MOUSE_PRESSED) { // left press
      // remember mouse click location for line selection
      mx = x;
      my = y;
      m_shift = shift;
      m_down = true;

      // determine line selection in 2-D display
      if (dim == 2) {
        Vector lines = list.getLines();
        Vector points = list.getPoints();
        Vector flags = list.getFlags();

        // get domain coordinates of mouse click
        double[] coords = BioUtil.pixelToDomain(display, x, y);

        // compute maximum distance threshold
        double[] e1 = BioUtil.pixelToDomain(display, 0, 0);
        double[] e2 = BioUtil.pixelToDomain(display, PICKING_THRESHOLD, 0);
        double threshold = e2[0] - e1[0];

        // find closest measurement
        int index = -1;
        double mindist = Double.POSITIVE_INFINITY;
        int lsize = lines.size();
        boolean isLine = true, isFlag = false;
        int[] pos = mm.getPos();
        for (int i=0; i<lsize; i++) {
          MeasureLine line = (MeasureLine) lines.elementAt(i);

          // skip lines not at this position
          boolean diff1 = false, diff2 = false;
          for (int j=0; j<pos.length; j++) {
            if (line.ep1.pos[j] != pos[j]) diff1 = true;
            if (line.ep2.pos[j] != pos[j]) diff2 = true;
          }
          if (diff1 && diff2) continue;

          // compute distance
          double[] a = {line.ep1.x, line.ep1.y};
          double[] b = {line.ep2.x, line.ep2.y};
          double dist = getDistance(a, b, coords, true);
          if (dist < mindist) {
            mindist = dist;
            index = i;
          }
        }
        int psize = points.size();
        for (int i=0; i<psize; i++) {
          MeasurePoint point = (MeasurePoint) points.elementAt(i);

          // skip points that are part of a line, or not at this position
          if (!point.lines.isEmpty()) continue;
          boolean valid = true;
          for (int j=0; j<pos.length; j++) {
            if (point.pos[j] != pos[j]) {
              valid = false;
              break;
            }
          }
          if (!valid) continue;

          // compute distance
          double dx = point.x - coords[0];
          double dy = point.y - coords[1];
          double dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < mindist) {
            mindist = dist;
            index = i;
            isLine = false;
          }
        }
        int fsize = flags.size();
        for (int i=0; i<fsize; i++) {
          MeasurePoint point = (MeasurePoint) flags.elementAt(i);

          // compute distance
          double dx = point.x - coords[0];
          double dy = point.y - coords[1];
          double dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < mindist) {
            mindist = dist;
            index = i;
            isLine = false;
            isFlag = true;
          }
        }

        if (m_shift) {
          // add or remove picked line or point from the selection
          if (mindist <= threshold && index >= 0) {
            if (isLine) {
              MeasureLine line = (MeasureLine) lines.elementAt(index);
              if (selLines.contains(line)) deselect(line);
              else select(line);
            }
            else {
              MeasurePoint point = isFlag ?
                (MeasurePoint) flags.elementAt(index) :
                (MeasurePoint) points.elementAt(index);
              if (selPoints.contains(point)) deselect(point);
              else select(point);
            }
            mm.updateSelection();
            mm.refreshPools(true);
          }
        }
        else {
          // set picked line or point as the selection
          deselectAll();
          if (mindist <= threshold && index >= 0) {
            if (isLine) select((MeasureLine) lines.elementAt(index));
            else if (isFlag) select((MeasurePoint) flags.elementAt(index));
            else select((MeasurePoint) points.elementAt(index));
          }
          mm.updateSelection();
          mm.refreshPools(true);
        }
      }

    }
    else if (left && id == DisplayEvent.MOUSE_RELEASED) { // left release
      // snap pool points to measurement values in 3-D display
      if (dim == 3) {
        int size = used.size();
        for (int i=0; i<size; i++) {
          PoolPoint pt = (PoolPoint) used.elementAt(i);
          pt.refresh();
        }
      }

      if (ptsChanged && (x != mx || y != my)) {
        mm.getVisBio().generateEvent(mm, "alter measurement", true);
      }
      ptsChanged = false;
      m_down = false;
    }
  }


  // -- Internal API methods

  /** If a single measurement is selected, return its linked pool points. */
  public PoolPoint[] getSelectionPts() {
    int lsize = selLines.size();
    int psize = selPoints.size();
    PoolPoint[] pts;
    if (lsize + psize != 1) pts = new PoolPoint[0];
    else if (lsize > 0) {
      pts = new PoolPoint[2];
      MeasureLine line = (MeasureLine) selLines.firstElement();
      pts[0] = line.ep1.pt[pid];
      pts[1] = line.ep2.pt[pid];
    }
    else {
      pts = new PoolPoint[1];
      MeasurePoint point = (MeasurePoint) selPoints.firstElement();
      pts[0] = point.pt[pid];
    }
    return pts;
  }

  /** Deselects the given line. */
  public void deselect(MeasureLine line) {
    if (!selLines.contains(line)) return;
    line.selected = false;
    line.ep1.selected--;
    line.ep2.selected--;
    selLines.remove(line);
  }

  /** Deselects the given point. */
  public void deselect(MeasurePoint point) {
    if (!selPoints.contains(point)) return;
    point.selected--;
    selPoints.remove(point);
  }


  // -- Helper methods --

  /** Ensures the pool has at least the given number of free points. */
  private void expand(int size, boolean init) {
    // compute number of PoolPoints to add
    int total = free.size();
    if (size <= total) return;
    int count = total + used.size();
    int n = size - total + BUFFER_SIZE;

    // add new PoolPoints to display
    lineCell.disableAction();
    for (int i=0; i<n; i++) {
      PoolPoint pt = new PoolPoint(mm, display, "p" + (count + i), dim);
      try {
        lineCell.addReference(pt.ref);
        if (init) pt.init();
      }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
      free.push(pt);
    }
    lineCell.enableAction();
  }

  /** Purges a point from the pool. */
  private void purge(PoolPoint pt) {
    if (!used.contains(pt)) return;
    pt.point.pt[pid] = null;
    pt.point = null;
    used.remove(pt);
    free.push(pt);
    pt.refresh();
  }

  /** Converts a set of measurement endpoints into a VisAD set. */
  private GriddedSet doSet(MeasurePoint[] points) {
    float[][] samples = new float[dim][points.length];
    GriddedSet set = null;
    try {
      if (dim == 2) {
        for (int i=0; i<points.length; i++) {
          samples[0][i] = (float) points[i].x;
          samples[1][i] = (float) points[i].y;
        }
        set = new Gridded2DSet(list.getDomain2D(), samples,
          points.length, null, null, null, false);
      }
      else {
        int stackAxis = mm.getStackAxis();
        for (int i=0; i<points.length; i++) {
          samples[0][i] = (float) points[i].x;
          samples[1][i] = (float) points[i].y;
          samples[2][i] = stackAxis >= 0 ?
            (float) points[i].pos[stackAxis] : 0f;
        }
        set = new Gridded3DSet(list.getDomain3D(), samples,
          points.length, null, null, null, false);
      }
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    return set;
  }

  /** Checks a line to see if an X must be placed over either endpoint. */
  private void doXs(MeasureLine line, Vector strips, Vector colors) {
    int[] pos = mm.getPos();
    boolean doX1 = false;
    boolean doX2 = false;
    for (int i=0; i<pos.length; i++) {
      if (pos[i] != line.ep1.pos[i]) doX1 = true;
      if (pos[i] != line.ep2.pos[i]) doX2 = true;
    }
    if (doX1) doX(line.ep1, strips, colors);
    if (doX2) doX(line.ep2, strips, colors);
  }

  /** Places an X over the specified measurement point. */
  private void doX(MeasurePoint point, Vector strips, Vector colors) {
    double res_x = list.getResX();
    double res_y = list.getResY();
    double width = 0.05 * (res_x < res_y ? res_x : res_y);
    float[][] samples1 = {
      {(float) (point.x - width), (float) (point.x + width)},
      {(float) (point.y - width), (float) (point.y + width)}
    };
    float[][] samples2 = {
      {(float) (point.x - width), (float) (point.x + width)},
      {(float) (point.y + width), (float) (point.y - width)}
    };
    try {
      RealTupleType domain2 = list.getDomain2D();
      strips.add(new Gridded2DSet(domain2,
        samples1, 2, null, null, null, false));
      strips.add(new Gridded2DSet(domain2,
        samples2, 2, null, null, null, false));
      for (int k=0; k<4; k++) colors.add(Color.white);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
  }

  /**
   * Converts a set of gridded sets with matching colors
   * into a field and updates the data reference accordingly.
   */
  private void doLines(Vector strips, Vector colors,
    DataReferenceImpl ref, DataRenderer renderer)
  {
    int size = strips.size();
    if (size == 0) {
      renderer.toggle(false);
      return;
    }

    // compile strips into UnionSet
    GriddedSet[] sets = new GriddedSet[size];
    strips.copyInto(sets);
    try {
      RealTupleType domain = dim == 2 ?
        list.getDomain2D() : list.getDomain3D();
      UnionSet set = new UnionSet(domain, sets);
      FunctionType function = new FunctionType(domain, mm.getColorRange());
      FlatField field = new FlatField(function, set);

      // assign color values to segment endpoints
      int colorSize = colors.size();
      double[][] samples = new double[3][colorSize];
      for (int j=0; j<colorSize; j++) {
        Color color = (Color) colors.elementAt(j);
        samples[0][j] = color.getRed();
        samples[1][j] = color.getGreen();
        samples[2][j] = color.getBlue();
      }
      field.setSamples(samples, false);

      ref.setData(field);
      renderer.toggle(true);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

  /**
   * Converts a set of measurement points with matching colors
   * into a field and updates the data reference accordingly.
   */
  private void doPoints(Vector strips, Vector colors,
    DataReferenceImpl ref, DataRenderer renderer)
  {
    int size = strips.size();
    if (size == 0) {
      renderer.toggle(false);
      return;
    }

    try {
      RealType index = RealType.getRealType("point_index");
      RealType[] range_types;
      RealType[] dtypes = list.getTypes();
      RealType[] ctypes = mm.getColorRange().getRealComponents();
      if (dim == 2) {
        range_types = new RealType[] {
          dtypes[0], dtypes[1], ctypes[0], ctypes[1], ctypes[2]
        };
      }
      else {
        range_types = new RealType[] {
          dtypes[0], dtypes[1], dtypes[2], ctypes[0], ctypes[1], ctypes[2]
        };
      }
      RealTupleType range = new RealTupleType(range_types);
      FunctionType function = new FunctionType(index, range);
      FlatField field = new FlatField(function, new Integer1DSet(size));

      // assign values to data samples
      double[][] samples = new double[dim + 3][size];
      if (dim == 2) {
        for (int j=0; j<size; j++) {
          MeasurePoint point = (MeasurePoint) strips.elementAt(j);
          Color color = (Color) colors.elementAt(j);
          samples[0][j] = point.x;
          samples[1][j] = point.y;
          samples[2][j] = color.getRed();
          samples[3][j] = color.getGreen();
          samples[4][j] = color.getBlue();
        }
      }
      else {
        int stackAxis = list.getStackAxis();
        for (int j=0; j<size; j++) {
          MeasurePoint point = (MeasurePoint) strips.elementAt(j);
          Color color = (Color) colors.elementAt(j);
          samples[0][j] = point.x;
          samples[1][j] = point.y;
          samples[2][j] = stackAxis >= 0 ? point.pos[stackAxis] : 0.0;
          samples[3][j] = color.getRed();
          samples[4][j] = color.getGreen();
          samples[5][j] = color.getBlue();
        }
      }
      field.setSamples(samples, false);
      ref.setData(field);
      renderer.toggle(true);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

  /** Selects the given line. */
  private void select(MeasureLine line) {
    if (selLines.contains(line)) return;
    line.selected = true;
    line.ep1.selected++;
    line.ep2.selected++;
    selLines.add(line);
  }

  /** Selects the given marker. */
  private void select(MeasurePoint point) {
    if (selPoints.contains(point)) return;
    point.selected++;
    selPoints.add(point);
  }

  /** Deselects all measurements. */
  private void deselectAll() {
    int lsize = selLines.size();
    for (int i=0; i<lsize; i++) {
      MeasureLine line = (MeasureLine) selLines.elementAt(i);
      line.selected = false;
      line.ep1.selected--;
      line.ep2.selected--;
    }
    selLines.removeAllElements();
    int psize = selPoints.size();
    for (int i=0; i<psize; i++) {
      MeasurePoint point = (MeasurePoint) selPoints.elementAt(i);
      point.selected--;
    }
    selPoints.removeAllElements();
  }


  // -- Utility methods --

  /**
   * Determines whether the specified endpoint lies within the given rectangle.
   *
   * @param x1 X-coordinate of the top-left corner of the rectangle
   * @param y1 Y-coordinate of the top-left corner of the rectangle
   * @param x2 X-coordinate of the bottom-right corner of the rectangle
   * @param y2 Y-coordinate of the bottom-right corner of the rectangle
   * @param vx X-coordinate of the standalone endpoint
   * @param vy Y-coordinate of the standalone endpoint
   */
  public static boolean contains(double x1, double y1,
    double x2, double y2, double vx, double vy)
  {
    if (x1 > x2) {
      double t = x1;
      x1 = x2;
      x2 = t;
    }
    if (y1 > y2) {
      double t = y1;
      y1 = y2;
      y2 = t;
    }
    return vx >= x1 && vx <= x2 && vy >= y1 && vy <= y2;
  }

  /**
   * Computes the minimum distance between the point v and the line a-b.
   *
   * @param a Coordinates of the line's first endpoint
   * @param b Coordinates of the line's second endpoint
   * @param v Coordinates of the standalone endpoint
   * @param segment Whether distance computation should be
   *                constrained to the given line segment
   */
  public static double getDistance(double[] a, double[] b, double[] v,
    boolean segment)
  {
    int len = a.length;
     
    // vectors
    double[] ab = new double[len];
    double[] va = new double[len];
    for (int i=0; i<len; i++) {
      ab[i] = a[i] - b[i];
      va[i] = v[i] - a[i];
    }

    // project v onto (a, b)
    double numer = 0;
    double denom = 0;
    for (int i=0; i<len; i++) {
      numer += va[i] * ab[i];
      denom += ab[i] * ab[i];
    }
    double c = numer / denom;
    double[] p = new double[len];
    for (int i=0; i<len; i++) p[i] = c * ab[i] + a[i];

    // determine which point (a, b or p) to use in distance computation
    int flag = 0;
    if (segment) {
      for (int i=0; i<len; i++) {
        if (p[i] > a[i] && p[i] > b[i]) flag = a[i] > b[i] ? 1 : 2;
        else if (p[i] < a[i] && p[i] < b[i]) flag = a[i] < b[i] ? 1 : 2;
        else continue;
        break;
      }
    }

    double sum = 0;
    for (int i=0; i<len; i++) {
      double q;
      if (flag == 0) q = p[i] - v[i]; // use p
      else if (flag == 1) q = a[i] - v[i]; // use a
      else q = b[i] - v[i]; // flag == 2, use b
      sum += q * q;
    }

    return Math.sqrt(sum);
  }

  /**
   * Determines whether the specified line segment
   * intersects the given rectangle.
   *
   * @param x1 X-coordinate of the top-left corner of the rectangle
   * @param y1 Y-coordinate of the top-left corner of the rectangle
   * @param x2 X-coordinate of the bottom-right corner of the rectangle
   * @param y2 Y-coordinate of the bottom-right corner of the rectangle
   * @param ax X-coordinate of the line's first endpoint
   * @param ay Y-coordinate of the line's first endpoint
   * @param bx X-coordinate of the line's second endpoint
   * @param by Y-coordinate of the line's second endpoint
   */
  public static boolean intersects(double x1, double y1,
    double x2, double y2, double ax, double ay, double bx, double by)
  {
    // Used by: measure/MeasurePool
    if (x1 > x2) {
      double t = x1;
      x1 = x2;
      x2 = t;
    }
    if (y1 > y2) {
      double t = y1;
      y1 = y2;
      y2 = t;
    }

    if (contains(x1, y1, x2, y2, ax, ay) ||
      contains(x1, y1, x2, y2, bx, by))
    {
      // rectangle contains an endpoint
      return true;
    }

    if (ax == bx) {
      // vertical line
      if (ax < x1 || ax > x2) return false;
      return (ay <= y1 && by >= y1) || (ay <= y2 && by >= y2) ||
        (ay >= y1 && by <= y1) || (ay >= y2 && by <= y2);
    }
    if (ay == by) {
      // horizontal line
      if (ay < y1 || ay > y2) return false;
      return (ax <= x1 && bx >= x1) || (ax <= x2 && bx >= x2) ||
        (ax >= x1 && bx <= x1) || (ax >= x2 && bx <= x2);
    }

    if ((ax <= x1 && bx <= x1) || (ax >= x2 && bx >= x2) ||
      (ay <= y1 && by <= y1) || (ay >= y2 && by >= y2))
    {
      return false;
    }

    double m = (by - ay) / (bx - ax);
    double b = ay - m * ax;

    double left_y = m * x1 + b;
    if (left_y >= y1 && left_y <= y2) return true;
    double right_y = m * x2 + b;
    if (right_y >= y1 && right_y <= y2) return true;
    double top_x = (y1 - b) / m;
    if (top_x >= x1 && top_x <= x2) return true;
    double bottom_x = (y2 - b) / m;
    if (bottom_x >= x1 && bottom_x <= x2) return true;

    return false;
  }

}
