//
// VisBio.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.net.URL;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;

import loci.visbio.data.DataManager;
import loci.visbio.help.HelpManager;
import loci.visbio.measure.*;
import loci.visbio.state.*;
import loci.visbio.util.*;
import loci.visbio.view.*;

import visad.util.*;

/**
 * VisBio is a multi-purpose biological analysis tool.
 *
 * It provides multi-dimensional visualization of an image or stack
 * of images across time, arbitrary slicing of the data, and
 * measurement tools for computing distances between data points.
 */
public class VisBio extends StatusFrame implements ChangeListener {

  // -- Constants --

  /** Application title. */
  public static final String TITLE = "VisBio";

  /** Application version. */
  public static final String VERSION = "v2.31";

  /** Application author. */
  public static final String AUTHOR = "Curtis Rueden, LOCI";

  /** Debugging flag for event logic. */
  public static final boolean DEBUG = false;

  /** Flag indicating operating system is Mac OS X. */
  public static boolean MAC_OS_X =
    System.getProperty("os.name").indexOf("Mac OS X") >= 0;


  // -- Fields --

  /** Self-referential object. */
  protected VisBio bio;

  /** Logic managers. */
  protected Vector managers;

  /** Associated splash screen. */
  protected SplashScreen ss;


  // -- Constructor --

  /** Constructs a new instance of VisBio. */
  public VisBio() { this(null); }

  /** Constructs a new instance of VisBio with the associated splash screen. */
  public VisBio(SplashScreen ss) {
    super(true);
    setTitle(TITLE);
    bio = this;
    managers = new Vector();
    this.ss = ss;
    if (ss != null) ss.show();
  }


  // -- New API methods --

  /** Updates the splash screen to report the given status message. */
  public void setStatus(String s) {
    if (ss == null) return;
    if (s != null) ss.setText(s + "...");
    ss.nextTask();
  }

  /** Adds a logic manager to the VisBio interface. */
  public void addManager(LogicManager lm) {
    managers.add(lm);
    generateEvent(new VisBioEvent(lm, VisBioEvent.LOGIC_ADDED, null, false));
  }

  /** Gets the logic manager of the given class. */
  public LogicManager getManager(Class c) {
    for (int i=0; i<managers.size(); i++) {
      LogicManager lm = (LogicManager) managers.elementAt(i);
      if (lm.getClass().equals(c)) return lm;
    }
    return null;
  }

  /** Gets all logic managers. */
  public LogicManager[] getManagers() {
    LogicManager[] lm = new LogicManager[managers.size()];
    managers.copyInto(lm);
    return lm;
  }

  /** Generates a state change event. */
  public void generateEvent(LogicManager lm, String msg, boolean undo) {
    generateEvent(new VisBioEvent(lm, VisBioEvent.STATE_CHANGED, msg, undo));
  }

  /** Generates an event and notifies all linked logic managers. */
  public void generateEvent(VisBioEvent evt) {
    if (DEBUG) System.out.println(evt.toString());
    for (int i=0; i<managers.size(); i++) {
      LogicManager lm = (LogicManager) managers.elementAt(i);
      lm.doEvent(evt);
    }
  }

  /**
   * This method executes action commands of the form
   *
   *   "loci.visbio.data.DataManager.fileOpenSeries(param)"
   *
   * by stripping off the fully qualified class name, checking VisBio's
   * list of logic managers for one of that class, and calling the given
   * method on that object, optionally with the given String parameter.
   */
  public void call(String cmd) {
    try {
      // determine class from fully qualified name
      int dot = cmd.lastIndexOf(".");
      Class c = Class.forName(cmd.substring(0, dot));

      // determine if action command has an argument
      Class[] param = null;
      String[] s = null;
      int paren = cmd.indexOf("(");
      if (paren >= 0) {
        param = new Class[] {String.class};
        s = new String[] {cmd.substring(paren + 1, cmd.indexOf(")", paren))};
      }
      else paren = cmd.length();

      // execute appropriate method of that logic manager
      LogicManager lm = getManager(c);
      if (lm != null) {
        Method method = c.getMethod(cmd.substring(dot + 1, paren), param);
        if (method != null) method.invoke(lm, s);
      }
    }
    catch (ClassNotFoundException exc) { exc.printStackTrace(); }
    catch (IllegalAccessException exc) { exc.printStackTrace(); }
    catch (IllegalArgumentException exc) { exc.printStackTrace(); }
    catch (InvocationTargetException exc) {
      Throwable t = exc.getTargetException();
      if (t == null) exc.printStackTrace();
      else t.printStackTrace();
    }
    catch (NoSuchMethodException exc) { exc.printStackTrace(); }
  }


  // -- Window API methods --

  /** Shows VisBio window, hiding splash screen if necessary. */
  public void show() {
    super.show();
    if (ss != null) {
      ss.hide();
      ss = null;
    }
  }


  // -- ActionListener API methods --

  /**
   * Internal method enabling logic managers to access
   * their own methods via VisBio's menu system.
   */
  public void actionPerformed(ActionEvent e) {
    String cmd = e.getActionCommand();
    if (cmd.lastIndexOf(".") < 0) super.actionPerformed(e);
    else call(cmd);
  }


  // -- Main --

  /** Launches the VisBio GUI. */
  public static void main(String[] args) throws Exception {
    // create splash screen
    String[] msg = {
      TITLE + " " + VERSION + " - " + AUTHOR,
      "VisBio is starting up..."
    };
    URL logo = VisBio.class.getResource("visbio-logo.jpg");
    SplashScreen ss = new SplashScreen(logo, msg, new Color(255, 255, 230));

    // construct VisBio interface
    VisBio bio = new VisBio(ss);

    // make menus appear in the right order
    bio.getMenu("File");
    bio.getMenu("Edit");
    bio.getMenu("Window");
    bio.getMenu("Help");

    // create logic managers
    OptionManager om = new OptionManager(bio);
    ViewManager vm = new ViewManager(bio);
    StateManager sm = new StateManager(bio);
    LogicManager[] lm = {
      om, // OptionManager
      new PanelManager(bio),
      new HelpManager(bio),
      new DataManager(bio),
      vm, // ViewManager
      new ColorManager(bio),
      new CaptureManager(bio),
      new SliceManager(bio),
      new RenderManager(bio),
      new MeasureManager(bio),
      new SystemManager(bio),
      new ConsoleManager(bio),
      new ExitManager(bio),
      sm // StateManager
    };
    int tasks = 1;
    for (int i=0; i<lm.length; i++) tasks += lm[i].getTasks();
    ss.setTasks(tasks);

    // add logic managers to VisBio
    for (int i=0; i<lm.length; i++) bio.addManager(lm[i]);
    bio.setStatus("Finishing");

    // read configuration file
    om.readIni();

    // handle Mac OS X application menu items
    if (MAC_OS_X) {
      ReflectedUniverse r = new ReflectedUniverse();
      r.exec("import loci.visbio.util.MacAdapter");
      r.setVar("bio", bio);
      r.exec("MacAdapter.link(bio)");
    }

    // handle file drag and drop onto VisBio frame
    JPanel p = (JPanel) bio.getContentPane();
    p.setTransferHandler(new BioDropHandler(bio));

    // show VisBio window onscreen
    vm.doPack(); // make displays initially square
    Util.centerWindow(bio);
    bio.show();

    // determine if VisBio crashed last time
    sm.checkCrash();
  }

}
