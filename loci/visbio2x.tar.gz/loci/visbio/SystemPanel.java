//
// SystemPanel.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio;

import java.awt.event.*;
import javax.swing.*;

import loci.visbio.util.BioUtil;

/** SystemPanel is the control panel for reporting system information. */
public class SystemPanel extends ControlPanel {

  // -- Fields --

  /** First part of system information string. */
  private String sysInfo1;

  /** Last part of system information string. */
  private String sysInfo2;

  /** Number of megabytes of memory currently in use. */
  private long memUsed;


  // -- Constructor --

  /** Constructs a control panel for viewing system information. */
  public SystemPanel(LogicManager logic) {
    super(logic, "System", "Reports system information");
    final VisBio bio = lm.getVisBio();

    // system information label
    JLabel systemLabel = BioUtil.makeLabel("System information:");
    controls.add(BioUtil.pad(systemLabel));

    // system information display panel
    final JEditorPane systemInfo = new JEditorPane();
    systemInfo.setEditable(false);
    systemInfo.setContentType("text/html");
    sysInfo1 = "<html><body>\n" +
      "Architecture: " + System.getProperty("os.arch") + "<br>\n" +
      "Operating system: " + System.getProperty("os.name") +
      " (v" + System.getProperty("os.version") + ")<br>\n" +
      "Java version: " + System.getProperty("java.version") +
      " (" + System.getProperty("java.vendor") + ")<br>\n" +
      "Memory usage: ";
    sysInfo2 = "\n</body></html>\n";
    systemInfo.setText(sysInfo1 + "xxxx MB used (xxx% free)" + sysInfo2);
    BioUtil.setTip(bio, systemInfo,
      "Reports information about this computer system");
    controls.add(new JScrollPane(systemInfo));

    // update system information twice per second
    Timer t = new Timer(500, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!bio.isVisible()) return;
        long total = Runtime.getRuntime().totalMemory();
        long free = Runtime.getRuntime().freeMemory();
        long used = total - free;

        long u = used >> 20;
        if (memUsed != u) {
          memUsed = u;
          final String s = u + " MB used";
          systemInfo.setText(sysInfo1 + s + sysInfo2);
        }
      }
    });
    t.start();

    // spacing
    controls.add(Box.createVerticalStrut(15));

    // garbage collection button
    JButton clean = new JButton("Clean memory");
    clean.setMnemonic('c');
    BioUtil.setTip(bio, clean, "Calls the Java garbage collector " +
      "to free wasted memory");
    clean.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        BioUtil.setWaitCursor(bio, true);
        SystemManager.gc();
        BioUtil.setWaitCursor(bio, false);
      }
    });
    controls.add(BioUtil.pad(clean));
  }

}
