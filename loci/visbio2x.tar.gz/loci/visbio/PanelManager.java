//
// PanelManager.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio;

import java.awt.*;
import java.util.Vector;

import javax.swing.*;

import loci.visbio.state.*;

/** PanelManager is the class encapsulating VisBio's shutdown logic. */
public class PanelManager extends LogicManager {

  // -- Constants --

  /** String for floating control windows option. */
  public static final String FLOATING = "Floating control windows";


  // -- Fields --

  /** Control panels. */
  private Vector panels;

  /** Control panel frames. */
  private Vector cplFrames;

  /** Control panel panes. */
  private Vector cplPanes;

  /** Whether control panels are located in separate, floating windows. */
  private boolean floating;


  // -- GUI components --

  /** Tabbed pane containing control panels. */
  private JTabbedPane tabs;


  // -- Constructor --

  /** Constructs an exit manager. */
  public PanelManager(VisBio biovis) { super(biovis); }


  // -- New API methods --

  /** Adds a new control panel. */
  public void addPanel(ControlPanel cpl) {
    String name = cpl.getName();

    // create control panel containers
    JFrame f = new JFrame(name);
    f.getContentPane().setLayout(new BorderLayout());
    JPanel p = new JPanel();
    p.setLayout(new BorderLayout());
    JScrollPane scroll = new JScrollPane(p);
    f.getContentPane().add(scroll, BorderLayout.CENTER);

    if (!floating) tabs.addTab(cpl.getName(), null, cpl, cpl.getTip());

    panels.add(cpl);
    cplFrames.add(f);
    cplPanes.add(p);

    bio.addMenuItem("Window", name,
      "loci.visbio.PanelManager.windowShow(" + name + ")",
      name.charAt(0), "Displays " + name + " panel");

    bio.generateEvent(this, "add " + name + " panel", false);
  }

  /** Gets the control panel with the given name. */
  public ControlPanel getPanel(String name) {
    for (int i=0; i<panels.size(); i++) {
      ControlPanel cpl = (ControlPanel) panels.elementAt(i);
      if (cpl.getName().equals(name)) return cpl;
    }
    return null;
  }


  // -- LogicManager API methods --

  /** Called to notify the logic manager of a VisBio event. */
  public void doEvent(VisBioEvent evt) {
    int eventType = evt.getEventType();
    if (eventType == VisBioEvent.LOGIC_ADDED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm == this) doGUI();
    }
    else if (eventType == VisBioEvent.STATE_CHANGED) {
      LogicManager lm = (LogicManager) evt.getSource();
      if (lm instanceof OptionManager) {
        OptionManager om = (OptionManager) lm;
        BooleanOption option = (BooleanOption) om.getOption(FLOATING);
        setFloating(option.getValue());
      }
    }
  }

  /** Gets the number of tasks required to initialize this logic manager. */
  public int getTasks() { return 2; }


  // -- Helper methods --

  /** Adds base control panel GUI components to VisBio. */
  private void doGUI() {
    bio.setStatus("Initializing control panel logic");
    panels = new Vector();
    cplFrames = new Vector();
    cplPanes = new Vector();

    // control panel containers
    tabs = new JTabbedPane();
    bio.getContentPane().add(tabs, BorderLayout.EAST);

    // options menu
    bio.setStatus(null);
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) {
      om.addBooleanOption("General", FLOATING, 'f',
        "Toggles whether each control panel has its own frame", false);
    }
  }

  /** Sets whether control panels are separate, floating windows. */
  private void setFloating(boolean floating) {
    if (this.floating == floating) return;
    this.floating = floating;

    JPanel pane = (JPanel) bio.getContentPane();
    if (floating) {
      pane.remove(tabs);
      tabs.removeAll();
      for (int i=0; i<panels.size(); i++) {
        ControlPanel cpl = (ControlPanel) panels.elementAt(i);
        JPanel p = (JPanel) cplPanes.elementAt(i);
        p.add(cpl, BorderLayout.CENTER);
      }
    }
    else {
      for (int i=0; i<panels.size(); i++) {
        ControlPanel cpl = (ControlPanel) panels.elementAt(i);
        JFrame f = (JFrame) cplFrames.elementAt(i);
        JPanel p = (JPanel) cplPanes.elementAt(i);
        f.setVisible(false);
        p.removeAll();
        tabs.addTab(cpl.getName(), null, cpl, cpl.getTip());
      }
      pane.add(tabs, BorderLayout.EAST);
    }
    bio.pack();
  }


  // -- Menu commands --

  /** Displays or switches to the given control panel. */
  public void windowShow(String name) {
    ControlPanel cpl = (ControlPanel) getPanel(name);
    int ndx = panels.indexOf(cpl);
    if (floating) {
      JFrame f = (JFrame) cplFrames.elementAt(ndx);
      f.pack();
      Point loc = bio.getLocation();
      int x = loc.x + bio.getSize().width;
      int y = loc.y;
      Dimension fsize = f.getSize();
      Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
      if (x + fsize.width > screen.width) x = screen.width - fsize.width;
      if (y + fsize.height > screen.height) y = screen.height - fsize.height;
      f.setLocation(x, y);
      f.show();
    }
    else tabs.setSelectedIndex(ndx);
  }

}
