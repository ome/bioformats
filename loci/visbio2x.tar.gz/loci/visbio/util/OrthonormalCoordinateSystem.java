//
// OrthonormalCoordinateSystem.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.io.*;

import visad.*;

import visad.util.*;

/**
 * A CoordinateSystem defined by three orthonormal vectors in R^3,
 * that will convert between world coordinates and reference coordinates
 * relative to those vectors.
 */
public class OrthonormalCoordinateSystem extends CoordinateSystem {

  private static int count = 0;

  /** Set of orthonormal vectors defining the coordinate system. */
  private double[] u, v, w;


  // -- Constructors --

  /**
   * Constructs a new <CODE>OrthonormalCoordinateSystem</CODE> by
   * deriving an orthonormal basis from the given vectors.
   */
  public OrthonormalCoordinateSystem(double[] v1, double[] v2)
    throws VisADException
  {
    this(new RealTupleType(
      RealType.getRealType("ortho_u" + ++count),
      RealType.getRealType("ortho_v" + count),
      RealType.getRealType("ortho_w" + count)
    ), v1, v2);
  }

  /**
   * Constructs a new <CODE>OrthonormalCoordinateSystem</CODE> for
   * values of the type specified, by deriving an orthonormal basis
   * from the given vectors.
   * @param type type of the values
   */
  public OrthonormalCoordinateSystem(RealTupleType type,
    double[] v1, double[] v2) throws VisADException
  {
    super(type, type.getDefaultUnits());

    // construct orthonormal basis
    u = normalize(v1);
    v = normalize(cross(v1, v2));
    w = normalize(cross(u, v));
  }


  // -- CoordinateSystem API methods --

  /**
   * Converts from reference coordinates to world coordinates.
   * @throws VisADException values are null or wrong dimension
   */
  public double[][] fromReference(double[][] values) throws VisADException {
    if (values == null || values.length != getDimension()) {
      throw new VisADException("values are null or wrong dimension");
    }
    int len = values[0].length;
    double[][] vals = new double[3][len];
    for (int i=0; i<len; i++) {
      for (int j=0; j<3; j++) {
        vals[j][i] = u[j] * values[0][i] +
          v[j] * values[1][i] +
          w[j] * values[2][i];
      }
    }
    return vals;
  }
      
  /**
   * Converts from world coordinates to reference coordinates.
   * @throws VisADException values are null or wrong dimension
   */
  public double[][] toReference(double[][] values) throws VisADException {
    if (values == null || values.length != getDimension()) {
      throw new VisADException("values are null or wrong dimension");
    }
    int len = values[0].length;
    double[][] vals = new double[3][len];
    double[] origin = {0, 0, 0};
    for (int i=0; i<len; i++) {
      double[] pt = {values[0][i], values[1][i], values[2][i]};
      double[] qu = project(origin, u, pt);
      double[] qv = project(origin, v, pt);
      double[] qw = project(origin, w, pt);
      vals[0][i] = Util.isApproximatelyEqual(u[0], 0) ?
        (Util.isApproximatelyEqual(u[1], 0) ?
        qu[2] / u[2] : qu[1] / u[1]) : qu[0] / u[0];
      vals[1][i] = Util.isApproximatelyEqual(v[0], 0) ?
        (Util.isApproximatelyEqual(v[1], 0) ?
        qv[2] / v[2] : qv[1] / v[1]) : qv[0] / v[0];
      vals[2][i] = Util.isApproximatelyEqual(w[0], 0) ?
        (Util.isApproximatelyEqual(w[1], 0) ?
        qw[2] / w[2] : qw[1] / w[1]) : qw[0] / w[0];
    }
    return vals;
  }


  // -- Object API methods --

  /**
   * Checks to see if the object in question is equal to this.
   * @param o object in question
   * @return true if they are equal, otherwise false.
   */
  public boolean equals(Object o) {
    if (o == null || !(o instanceof OrthonormalCoordinateSystem)) return false;
    OrthonormalCoordinateSystem ocs = (OrthonormalCoordinateSystem) o;
    RealTupleType ref = ocs.getReference();
    return getReference().equals(ref) && BioUtil.arraysEqual(u, ocs.u) &&
      BioUtil.arraysEqual(v, ocs.v) && BioUtil.arraysEqual(w, ocs.w);
  }


  // -- Utility methods --

  /** Computes the cross-product of the two given vectors. */
  public static double[] cross(double[] p1, double[] p2) {
    int len = p1.length;
    double[] q = new double[len];
    for (int i=0; i<len; i++) {
      int ndx1 = (i + 1) % len;
      int ndx2 = (i + 2) % len;
      q[i] = p1[ndx1] * p2[ndx2] - p1[ndx2] * p2[ndx1];
    }
    return q;
  }

  /** Normalizes the given vector. */
  public static double[] normalize(double[] v) {
    int len = v.length;
    double factor = 0;
    for (int i=0; i<len; i++) factor += v[i] * v[i];
    factor = Math.sqrt(factor);
    double[] n = new double[len];
    for (int i=0; i<len; i++) n[i] = v[i] / factor;
    return n;
  }

  /** Projects point p onto line p1-p2. */
  public static double[] project(double[] p1, double[] p2, double[] p) {
    int len = p.length;
    double[] v21 = new double[len];
    double[] vp1 = new double[len];
    double numer = 0, denom = 0;
    for (int i=0; i<len; i++) {
      v21[i] = p2[i] - p1[i];
      vp1[i] = p[i] - p1[i];
      numer += v21[i] * vp1[i];
      denom += v21[i] * v21[i];
    }
    double u = numer / denom;
    double[] q = new double[len];
    for (int i=0; i<len; i++) q[i] = p1[i] + u * v21[i];
    return q;
  }

}
