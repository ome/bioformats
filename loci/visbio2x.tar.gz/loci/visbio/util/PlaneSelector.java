//
// PlaneSelector.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.Color;
import java.io.*;
import java.rmi.RemoteException;
import java.util.Vector;

import loci.visbio.state.*;

import visad.*;
import visad.java3d.DirectManipulationRendererJ3D;

/**
 * PlaneSelector maintains a data structure of three endpoints that
 * can be manipulated by the user to specify an arbitrary plane in 3-D.
 */
public class PlaneSelector implements Saveable, Dynamic {

  // -- Constants --

  /** Header for plane selector data in state file. */
  private static final String PLANE_HEADER = "# Plane selector";


  // -- Fields --

  /** Colors for thick line border and endpoints. */
  protected Color[] lineColors;

  /** Color for semi-transparent plane. */
  protected Color planeColor;

  /** Display to which plane is linked. */
  protected DisplayImpl display;

  /** Data references for manipulable endpoints. */
  protected DataReferenceImpl[] pt_refs = new DataReferenceImpl[3];

  /** Data reference for linked plane outline. */
  protected DataReferenceImpl line_ref;

  /** Data reference for linked plane. */
  protected DataReferenceImpl plane_ref;

  /** Data renderers for the manipulable endpoints. */
  protected DataRenderer[] pt_renderers = new DataRenderer[3];

  /** Data renderer for linked plane outline. */
  protected DataRenderer line_renderer;

  /** Data renderer for linked plane. */
  protected DataRenderer plane_renderer;

  /** Computation cell for linking plane with endpoints. */
  protected CellImpl cell;

  /** Real type mappings for the plane. */
  protected RealType xtype, ytype, ztype, rtype, gtype, btype;

  /** Math type for domain and range tuples. */
  protected RealTupleType domain, range;

  /** Starting coordinates for plane's endpoints. */
  protected double x1, y1, z1, x2, y2, z2, x3, y3, z3;

  /** Current coordinates for plane's endpoints. */
  protected double[][] pos = new double[3][3];

  /** Color values for plane outline points. */
  protected double[][] lineValues;
  
  /** Perimeter lines for the plane. */
  protected FlatField lines;

  /** Semi-transparent planar slice. */
  protected Gridded3DSet plane;

  /** List of PlaneListeners to notify when plane changes. */
  protected Vector listeners = new Vector();

  /** Number of data changes to ignore before recomputing plane. */
  protected int ignore = 0;


  // -- Constructor --

  /** Constructs an uninitialized plane selector. */
  public PlaneSelector() { }

  /** Constructs a plane selector. */
  public PlaneSelector(Color[] lineColors, Color planeColor) {
    this.lineColors = lineColors;
    this.planeColor = planeColor;
    initState(null);
  }


  // -- API methods --

  /** Links the plane selector to the given display. */
  public void link(DisplayImpl display)
    throws VisADException, RemoteException
  {
    if (this.display != null) unlink();
    this.display = display;
    if (display == null) return;

    Vector v = display.getMapVector();
    double[] xrange = null, yrange = null, zrange = null;
    for (int i=0; i<v.size(); i++) {
      ScalarMap map = (ScalarMap) v.elementAt(i);
      ScalarType st = map.getScalar();
      if (!(st instanceof RealType)) continue;
      RealType rt = (RealType) st;
      DisplayRealType drt = map.getDisplayScalar();
      if (drt.equals(Display.XAxis)) {
        xtype = rt;
        xrange = map.getRange();
      }
      else if (drt.equals(Display.YAxis)) {
        ytype = rt;
        yrange = map.getRange();
      }
      else if (drt.equals(Display.ZAxis)) {
        ztype = rt;
        zrange = map.getRange();
      }
      else if (drt.equals(Display.Red)) rtype = rt;
      else if (drt.equals(Display.Green)) gtype = rt;
      else if (drt.equals(Display.Blue)) btype = rt;
    }
    if (xtype == null || ytype == null || ztype == null) {
      throw new VisADException("Appropriate spatial mappings not found");
    }
    if (rtype == null || gtype == null || btype == null) {
      throw new VisADException("Appropriate color mappings not found");
    }
    domain = new RealTupleType(xtype, ytype, ztype);
    range = new RealTupleType(rtype, gtype, btype);
    x1 = xrange[0]; y1 = yrange[0]; z1 = zrange[0];
    x2 = xrange[1]; y2 = yrange[1]; z2 = zrange[1];
    x3 = xrange[0]; y3 = yrange[1]; z3 = zrange[1];
    pos[0][0] = x1; pos[0][1] = y1; pos[0][2] = z1;
    pos[1][0] = x2; pos[1][1] = y2; pos[1][2] = z2;
    pos[2][0] = x3; pos[2][1] = y3; pos[2][2] = z3;
    syncData();

    lineValues = new double[3][4];
    int len = lineColors.length;
    for (int i=0; i<4; i++) {
      lineValues[0][i] = lineColors[i % len].getRed();
      lineValues[1][i] = lineColors[i % len].getGreen();
      lineValues[2][i] = lineColors[i % len].getBlue();
    }
    float plane_r = planeColor.getRed() / 255.0f;
    float plane_g = planeColor.getGreen() / 255.0f;
    float plane_b = planeColor.getBlue() / 255.0f;
    DisplayRenderer displayRenderer = display.getDisplayRenderer();

    // manipulable plane definition points
    for (int i=0; i<pt_refs.length; i++) {
      pt_renderers[i] = new DirectManipulationRendererJ3D();
      pt_renderers[i].setPickCrawlToCursor(false);
      pt_renderers[i].suppressExceptions(true);
      pt_renderers[i].toggle(false);
      display.addReferences(pt_renderers[i], pt_refs[i], new ConstantMap[] {
        new ConstantMap(lineValues[0][i] / 255.0, Display.Red),
        new ConstantMap(lineValues[1][i] / 255.0, Display.Green),
        new ConstantMap(lineValues[2][i] / 255.0, Display.Blue),
        new ConstantMap(6.0, Display.PointSize)
      });
    }

    // thick plane outline
    line_renderer = displayRenderer.makeDefaultRenderer();
    line_renderer.suppressExceptions(true);
    line_renderer.toggle(false);
    display.addReferences(line_renderer, line_ref, new ConstantMap[] {
      new ConstantMap(3.0, Display.LineWidth)
    });

    // semi-transparent plane
    plane_renderer = displayRenderer.makeDefaultRenderer();
    plane_renderer.suppressExceptions(true);
    plane_renderer.toggle(false);
    display.addReferences(plane_renderer, plane_ref, new ConstantMap[] {
      new ConstantMap(plane_r, Display.Red),
      new ConstantMap(plane_g, Display.Green),
      new ConstantMap(plane_b, Display.Blue),
      new ConstantMap(0.75, Display.Alpha)
    });

    refresh(true);
  }

  /** Unlinks the plane selector from its display. */
  public void unlink() throws VisADException, RemoteException {
    if (display == null) return;
    for (int i=0; i<pt_refs.length; i++) display.removeReference(pt_refs[i]);
    display.removeReference(line_ref);
    display.removeReference(plane_ref);
  }

  /** Toggles the plane selector's visibility. */
  public void setVisible(boolean visible) {
    for (int i=0; i<pt_renderers.length; i++) pt_renderers[i].toggle(visible);
    line_renderer.toggle(visible);
    plane_renderer.toggle(visible);
  }

  /** Gets the plane selector's visibility. */
  public boolean isVisible() { return line_renderer.getEnabled(); }

  /** Refreshes the plane data from its endpoint locations. */
  protected void refresh(boolean force) {
    // update position array
    boolean same = true;
    for (int i=0; i<pt_refs.length; i++) {
      RealTuple tuple = (RealTuple) pt_refs[i].getData();
      double[] values = tuple.getValues();
      for (int j=0; j<values.length; j++) {
        if (values[j] != pos[i][j]) {
          same = false;
          pos[i][j] = values[j];
        }
      }
    }

    // endpoints have not changed; no need for refresh
    if (same && !force) return;

    // ensure endpoints form proper geometry
    constrainPoints();

    try {
      // recompute linked plane
      lines = null;
      plane = null;
      computePlane();

      // update data references
      syncData();
      line_ref.setData(lines);
      plane_ref.setData(plane);
    }
    catch (VisADException exc) { exc.printStackTrace(); }
    catch (RemoteException exc) { exc.printStackTrace(); }
  }

  /**
   * Constrains the endpoints to some required geometry.
   * Subclasses should override this method to ensure
   * adherence to any special geometry they require.
   */
  protected void constrainPoints() { }

  /** Computes the appropriate plane from the current endpoints. */
  protected void computePlane() throws VisADException, RemoteException {
    float[][] samples = new float[3][pos.length + 1];
    for (int i=0; i<pos.length; i++) {
      for (int j=0; j<3; j++) samples[j][i] = (float) pos[i][j];
    }
    for (int j=0; j<3; j++) samples[j][pos.length] = samples[j][0];
    float[][] samps = new float[3][4];
    for (int i=0; i<3; i++) {
      samps[i][0] = samples[i][0];
      samps[i][1] = (samples[i][0] + samples[i][1]) / 2;
      samps[i][2] = samples[i][2];
      samps[i][3] = samples[i][1];
    }
    FunctionType lineType = new FunctionType(domain, range);
    Gridded3DSet lineSet =
      new Gridded3DSet(domain, samples, 4, null, null, null, false);
    lines = new FlatField(lineType, lineSet);
    lines.setSamples(lineValues);
    plane = new Gridded3DSet(domain, samps, 2, 2, null, null, null, false);
  }

  /** Updates the data references to match the current position array. */
  protected void syncData() {
    cell.disableAction();
    for (int i=0; i<pos.length; i++) {
      RealTuple tuple = (RealTuple) pt_refs[i].getData();
      double[] values = tuple == null ? null : tuple.getValues();
      if (!BioUtil.arraysEqual(values, pos[i])) {
        try { pt_refs[i].setData(new RealTuple(domain, pos[i])); }
        catch (VisADException exc) { exc.printStackTrace(); }
        catch (RemoteException exc) { exc.printStackTrace(); }
      }
    }
    cell.enableAction();
  }


  // -- Saveable API methods --

  /** Writes the plane selector state to the given output stream. */
  public void saveState(PrintWriter fout) throws SaveException {
    fout.println(PLANE_HEADER);
    fout.println(lineColors.length);
    for (int i=0; i<lineColors.length; i++) {
      BioUtil.writeColor(lineColors[i], fout);
    }
    BioUtil.writeColor(planeColor, fout);
    for (int i=0; i<pt_refs.length; i++) {
      for (int j=0; j<3; j++) fout.println(pos[i][j]);
    }
  }

  /** Restores the plane selector state from the given input stream. */
  public void restoreState(BufferedReader fin) throws SaveException {
    try {
      if (!fin.readLine().trim().equals(PLANE_HEADER)) {
        throw new SaveException("PlaneSelector: incorrect state format");
      }
      int num = Integer.parseInt(fin.readLine());
      lineColors = new Color[num];
      for (int i=0; i<num; i++) lineColors[i] = BioUtil.readColor(fin);
      planeColor = BioUtil.readColor(fin);
      for (int i=0; i<pt_refs.length; i++) {
        pos[i][0] = BioUtil.readDouble(fin);
        pos[i][1] = BioUtil.readDouble(fin);
        pos[i][2] = BioUtil.readDouble(fin);
      }
    }
    catch (NumberFormatException exc) { throw new SaveException(exc); }
    catch (IOException exc) { throw new SaveException(exc); }
  }


  // -- Dynamic API methods --

  /** Tests whether two dynamic objects have matching states. */
  public boolean matches(Dynamic dyn) { return this == dyn; }

  /** Modifies this object's state to match that of the given object. */
  public void initState(Dynamic dyn) {
    if (dyn != null && dyn instanceof PlaneSelector) {
      PlaneSelector plane = (PlaneSelector) dyn;
      lineColors = plane.lineColors;
      planeColor = plane.planeColor;
      pos = plane.pos;
    }

    if (cell == null) {
      // cell links plane with endpoints
      cell = new CellImpl() {
        public void doAction() {
          if (ignore > 0) ignore--;
          else refresh(false);
        }
      };

      try {
        // construct data references
        for (int i=0; i<pt_refs.length; i++) {
          pt_refs[i] = new DataReferenceImpl("bio_pt" + i);
        }
        line_ref = new DataReferenceImpl("bio_edges");
        plane_ref = new DataReferenceImpl("bio_plane");

        // link endpoints to cell
        ignore++;
        cell.disableAction();
        for (int i=0; i<pt_refs.length; i++) cell.addReference(pt_refs[i]);
        cell.enableAction();
      }
      catch (VisADException exc) { exc.printStackTrace(); }
      catch (RemoteException exc) { exc.printStackTrace(); }
    }
    else {
      syncData();
      refresh(true);
    }
  }

  /**
   * Called when this object is being discarded in favor of
   * another object with a matching state.
   */
  public void discard() { }

}
