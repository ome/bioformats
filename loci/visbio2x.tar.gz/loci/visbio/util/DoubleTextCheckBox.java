//
// DoubleTextCheckBox.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;

import visad.util.Util;

/** A checkbox with two text fields. */
public class DoubleTextCheckBox extends JPanel
  implements DocumentListener, ItemListener
{

  // -- Fields --

  private Vector listeners;
  private String cmd;
  private JCheckBox box;
  private JLabel label;
  private JTextField field1, field2;


  // -- Constructor --

  /** Creates a DoubleTextCheckBox. */
  public DoubleTextCheckBox(String label1, String label2,
    String value1, String value2, boolean checked)
  {
    super();
    listeners = new Vector();
    cmd = "";
    setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
    box = new JCheckBox(label1, checked);
    box.addItemListener(this);
    label = BioUtil.makeLabel(label2);
    field1 = BioUtil.makeField(5);
    field1.setText(value1);
    field2 = BioUtil.makeField(5);
    field2.setText(value2);
    field1.getDocument().addDocumentListener(this);
    field2.getDocument().addDocumentListener(this);
    Util.adjustTextField(field1);
    Util.adjustTextField(field2);
    updateGUI();

    add(box);
    add(Box.createHorizontalGlue());
    add(Box.createHorizontalStrut(5));
    add(field1);
    add(Box.createHorizontalStrut(5));
    add(label);
    add(Box.createHorizontalStrut(5));
    add(field2);
  }

  /** Refreshes the state of the widget. */
  public void updateGUI() {
    boolean enabled = box.isEnabled() && box.isSelected();
    label.setEnabled(enabled);
    field1.setEnabled(enabled);
    field2.setEnabled(enabled);
  }


  // -- API methods --

  /** Gets whether the checkbox is selected. */
  public boolean isSelected() { return box.isSelected(); }

  /** Enables or disables the checkbox. */
  public void setEnabled(boolean enabled) {
    box.setEnabled(enabled);
    updateGUI();
  }

  /** Gets the value of the first text field. */
  public String getFirstValue() { return field1.getText(); }

  /** Gets the value of the second text field. */
  public String getSecondValue() { return field2.getText(); }

  /** Sets whether the checkbox is selected. */
  public void setSelected(boolean selected) { box.setSelected(selected); }

  /** Sets the values of the text fields. */
  public void setValues(String text1, String text2) {
    field1.setText(text1);
    field2.setText(text2);
  }

  /** Sets the mnemonic of the widget. */
  public void setMnemonic(char m) { box.setMnemonic(m); }

  /** Sets the tool tips for the widget. */
  public void setToolTipText(String checkbox, String text1, String text2) {
    box.setToolTipText(checkbox);
    field1.setToolTipText(text1);
    field2.setToolTipText(text2);
  }

  /** Adds an item listener to the check box. */
  public void addActionListener(ActionListener l) { listeners.add(l); }

  /** Removes an item listener from the check box. */
  public void removeActionListener(ActionListener l) { listeners.remove(l); }

  /** Sets the action command for the action listeners. */
  public void setActionCommand(String cmd) { this.cmd = cmd; }


  // -- ItemListener API methods --

  /** ItemListener method triggered when check box state changes. */
  public void itemStateChanged(ItemEvent e) {
    updateGUI();
    notifyListeners();
  }


  // -- DocumentListener API methods --

  public void changedUpdate(DocumentEvent e) { notifyListeners(); }
  public void insertUpdate(DocumentEvent e) { notifyListeners(); }
  public void removeUpdate(DocumentEvent e) { notifyListeners(); }


  // -- Helper methods --

  private void notifyListeners() {
    ActionEvent e = new ActionEvent(this, 0, cmd);
    int size = listeners.size();
    for (int i=0; i<size; i++) {
      ActionListener l = (ActionListener) listeners.elementAt(i);
      l.actionPerformed(e);
    }
  }

}
