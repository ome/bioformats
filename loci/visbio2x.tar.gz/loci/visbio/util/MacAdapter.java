//
// MacAdapter.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2003 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import com.apple.eawt.*;

import loci.visbio.*;
import loci.visbio.help.HelpManager;
import loci.visbio.state.OptionManager;

/** An adapter for handling the Mac OS X application menu items. */
public class MacAdapter extends ApplicationAdapter {

  // Note: This class will only compile on Macintosh systems. However, since
  // no other classes depend on it directly (i.e., they reference it via
  // reflection), the rest of VisBio should still compile on non-Macintoshes.


  // -- Fields --

  /** Linked VisBio instance. */
  private VisBio bio;


  // -- Constructor --

  /** Constructs a Mac OS X adapter. */
  public MacAdapter(VisBio bio) { this.bio = bio; }


  // -- ApplicationAdapter API methods --

  /** Handles the About menu item. */
  public void handleAbout(ApplicationEvent evt) {
    evt.setHandled(true);
    HelpManager hm = (HelpManager) bio.getManager(HelpManager.class);
    if (hm != null) hm.helpShow("About");
  }

  /** Handles the Preferences menu item. */
  public void handlePreferences(ApplicationEvent evt) {
    evt.setHandled(true);
    OptionManager om = (OptionManager) bio.getManager(OptionManager.class);
    if (om != null) om.fileOptions();
  }

  /** Handles the Quit menu item. */
  public void handleQuit(ApplicationEvent evt) {
    evt.setHandled(false);
    ExitManager em = (ExitManager) bio.getManager(ExitManager.class);
    if (em != null) em.fileExit();
  }


  // -- New API methods --

  /** Associates the VisBio instance with a Mac OS X adapter. */
  public static void link(VisBio bio) {
    Application app = new Application();
    app.setEnabledPreferencesMenu(true);
    app.addApplicationListener(new MacAdapter(bio));
  }

}
