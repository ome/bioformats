//
// SplashScreen.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;
import java.net.URL;

import javax.swing.*;

import visad.util.Util;

/** An application splash screen. */
public class SplashScreen extends JWindow {

  // -- Constants --

  /** Width of splash screen black border. */
  private static final int BORDER_WIDTH = 2;


  // -- Fields --

  /** Label containing splash message. */
  private JLabel msgLabel;

  /** Progress bar. */
  private JProgressBar bar;

  /** Current task number. */
  private int task = 0;

  /** Total number of tasks. */
  private int tasks = 0;


  // -- Constructor --

  /**
   * Constructs a splash screen using the given logo image,
   * informative messages and message background color.
   */
  public SplashScreen(URL logo, String[] msg, Color bgcolor) {
    Container pane = getContentPane();
    pane.setBackground(Color.black);
    pane.add(Box.createVerticalStrut(BORDER_WIDTH), BorderLayout.NORTH);
    pane.add(Box.createVerticalStrut(BORDER_WIDTH), BorderLayout.SOUTH);
    pane.add(Box.createHorizontalStrut(BORDER_WIDTH), BorderLayout.WEST);
    pane.add(Box.createHorizontalStrut(BORDER_WIDTH), BorderLayout.EAST);
    JPanel main = new JPanel();
    pane.add(main, BorderLayout.CENTER);

    main.setBackground(bgcolor);
    main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
    main.add(new JLabel(new ImageIcon(logo)));

    bar = new JProgressBar();
    bar.setAlignmentX(JProgressBar.LEFT_ALIGNMENT);
    main.add(bar);

    main.add(Box.createVerticalStrut(3));
    for (int i=0; i<msg.length; i++) {
      JPanel p = new JPanel();
      p.setBackground(bgcolor);
      p.setAlignmentX(JPanel.LEFT_ALIGNMENT);
      p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
      p.add(Box.createHorizontalGlue());
      msgLabel = BioUtil.makeLabel(msg[i]);
      p.add(msgLabel);
      p.add(Box.createHorizontalGlue());
      main.add(p);
    }
    main.add(Box.createVerticalStrut(3));

    pack();
    Util.centerWindow(this);
  }

  // -- API methods --

  /** Sets the number of tasks for splash screen progress bar. */
  public void setTasks(int tasks) { this.tasks = tasks; }

  /** Changes the currently displayed text. */
  public void setText(String msg) { msgLabel.setText(msg); }

  /** Advances task counter. */
  public void nextTask() {
    if (tasks > 0) {
      task++;
      int p = 100 * task / tasks;
      bar.setValue(p);
    }
  }

}
