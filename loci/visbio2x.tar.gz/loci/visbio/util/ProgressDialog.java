//
// ProgressDialog.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;

import javax.swing.*;

import visad.util.Util;

/**
 * ProgressDialog is a modal dialog displaying a progress bar.
 * It pops up when show() or go() is called, and disappears when
 * dismissed with kill().
 */
public class ProgressDialog extends JDialog {

  // -- Constants --

  /** Minimum width of the progress bar onscreen. */
  protected static final int MINIMUM_WIDTH = 300;

 
  // -- GUI components --

  /** Progress bar. */
  protected JProgressBar bar;

  /** Information label. */
  protected JLabel label;


  // -- Other fields --

  /** Exception to throw when checkException() is called. */
  protected Exception exc;

  /** False if dialog has been prematurely killed. */
  protected boolean live;


  // -- Constructors --

  /** Constructs a new instance of ProgressDialog as child of a frame. */
  public ProgressDialog(Frame owner, String info) {
    super(owner, "Please wait...", true);
    doGUI(owner, info);
  }

  /** Constructs a new instance of ProgressDialog as child of a dialog. */
  public ProgressDialog(Dialog owner, String info) {
    super(owner, "Please wait...", true);
    doGUI(owner, info);
  }

  /** Does layout of the progress dialog's interface. */
  private void doGUI(Window owner, String info) {
    live = true;

    // lay out components
    JPanel pane = new JPanel();
    pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
    setContentPane(pane);
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

    // info label
    label = BioUtil.makeLabel(info + "...");
    label.setAlignmentY(JLabel.TOP_ALIGNMENT);
    pane.add(BioUtil.pad(label));

    // progress bar
    bar = new JProgressBar();
    pane.add(bar);
    pane.add(Box.createVerticalGlue());

    // finish layout
    bar.setStringPainted(true);
    pack();
    bar.setStringPainted(false);
    bar.setVisible(false);
    setResizable(false);
  }


  // -- Component API methods --

  /** Makes progress dialog decently sized. */
  public Dimension getPreferredSize() {
    Dimension d = super.getPreferredSize();
    return new Dimension(d.width > MINIMUM_WIDTH ?
      d.width : MINIMUM_WIDTH, d.height);
  }


  // -- New API methods --

  /** Sets the progress amount of the progress dialog. */
  public void setPercent(int value) {
    if (value < 0) {
      bar.setStringPainted(false);
      bar.setVisible(false);
    }
    else {
      bar.setStringPainted(true);
      bar.setValue(value);
      bar.setVisible(true);
    }
  }

  /** Sets the information label to the specified string. */
  public void setText(String info) { label.setText(info + "..."); }

  /** Sets the exception to be thrown when checkException() is called. */
  public void setException(Exception exc) { this.exc = exc; }

  /** Throws the exception registered with setException(), if any. */
  public void checkException() throws Exception { if (exc != null) throw exc; }

  /**
   * Displays the dialog and runs the given code in a separate thread.
   * Blocks until the dialog is hidden. To accomplish this, the last line
   * of the given Runnable object's code should be a call to kill().
   */
  public void go(Runnable r) {
    Thread t = new Thread(r);
    t.start();
    show();
  }

  /** Hides the progress dialog. */
  public void kill() {
    synchronized (bar) {
      live = false;
      super.setVisible(false);
    }
  }

  /** Shows the progress dialog. */
  public void show() {
    synchronized (bar) {
      if (!live) return;
      Window owner = getOwner();
      if (owner == null) Util.centerWindow(this);
      else Util.centerWindow(owner, this);
    }
    super.show();
  }


  // -- Main --

  /** Launches the ProgressDialog GUI. */
  public static void main(String[] args) throws Exception {
    final ProgressDialog dialog =
      new ProgressDialog((Frame) null, "Testing ProgressDialog");
    dialog.go(new Runnable() {
      public void run() {
        try { Thread.sleep(5000); }
        catch (InterruptedException exc) { exc.printStackTrace(); }

        int percent = 0;
        while (percent <= 100) {
          try { Thread.sleep((int) (Math.random() * 200)); }
          catch (InterruptedException exc) { exc.printStackTrace(); }
          dialog.setPercent(++percent);
          if (percent == 90) dialog.setText("Almost done");
        }
        dialog.kill();
      }
    });
    dialog.checkException();
    System.exit(0);
  }

}
