//
// WarningPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.util.StringTokenizer;

import javax.swing.*;
import javax.swing.border.*;

import loci.visbio.state.OptionManager;

/** WarningPane provides a dialog box for displaying a warning to the user. */
public class WarningPane extends DialogPane {

  // -- Constants --

  /** Border to place around warning text. */
  private static final Border WARN_BORDER = new CompoundBorder(
    new EmptyBorder(5, 5, 0, 5), new CompoundBorder(
    new LineBorder(Color.black), new EmptyBorder(5, 5, 5, 5)));


  // -- Fields --

  /** Associated option manager. */
  private OptionManager om;

  /** Associated option checkbox. */
  private JCheckBox option;

  /** Checkbox within warning pane. */
  private JCheckBox always;

  // -- Constructor --

  /** Creates a new warning pane linked to the given warning checkbox. */
  public WarningPane(String text, OptionManager om,
    JCheckBox option, boolean allowCancel)
  {
    super("VisBio Warning", allowCancel);
    this.om = om;
    this.option = option;

    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
    p.setBorder(WARN_BORDER);
    pane.add(p);

    StringTokenizer st = new StringTokenizer(text, "\n\r");
    int count = st.countTokens();
    for (int i=0; i<count; i++) p.add(BioUtil.makeLabel(st.nextToken()));

    always = new JCheckBox("Always display this warning", true);
    always.setMnemonic('a');
    always.setActionCommand("always");
    always.addActionListener(this);
    buttons.add(Box.createHorizontalStrut(10), 0);
    buttons.add(always, 1);
  }


  // -- ActionListener API methods --

  /** Handles button press events. */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("always")) {
      if (option != null) option.setSelected(always.isSelected());
      if (om != null) om.writeIni();
    }
    else super.actionPerformed(e);
  }

}
