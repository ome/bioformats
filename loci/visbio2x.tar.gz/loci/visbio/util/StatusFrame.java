//
// StatusFrame.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.event.*;

import visad.util.*;

/** A GUIFrame with a status bar. */
public class StatusFrame extends GUIFrame
  implements ChangeListener, FocusListener, MouseListener
{

  // -- Constants --

  /** Key mask for use with keyboard shortcuts on this operating system. */
  protected static final int MENU_MASK =
    Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();


  // -- Fields --

  /** Status bar. */
  protected JTextField status;

  /** Hashtable for status messages. */
  protected Hashtable statusHash;

  /** Default status bar message. */
  protected String message;


  // -- Constructors --

  /** Constructs a new status frame. */
  public StatusFrame() { this(false); }

  /** Constructs a new status frame with heavy- or light-weight menus. */
  public StatusFrame(boolean heavyweight) {
    super(heavyweight);
    status = new JTextField();
    status.setEditable(false);
    status.setBorder(new BevelBorder(BevelBorder.RAISED));
    message = "";

    JPanel pane = new JPanel();
    pane.setLayout(new BorderLayout());
    setContentPane(pane);
    pane.add(status, BorderLayout.SOUTH);

    statusHash = new Hashtable();
  }


  // -- API methods --

  /** Adds a menu item with the specified status bar message. */
  public void addMenuItem(String menu, JMenuItem item,
    String cmd, char mnemonic, String statusMsg)
  {
    addMenuItem(menu, item, cmd, mnemonic, true);
    statusHash.put(item, statusMsg);
    item.addChangeListener(this);
  }

  /** Adds a menu item with the specified status bar message. */
  public JMenuItem addMenuItem(String menu, String item,
    String cmd, char mnemonic, String statusMsg)
  {
    JMenuItem jmi = addMenuItem(menu, item, cmd, mnemonic);
    statusHash.put(jmi, statusMsg);
    jmi.addChangeListener(this);
    return jmi;
  }

  /** Sets the keyboard shortcut for the given menu item. */
  public void setMenuShortcut(String menu, String item, int keycode) {
    JMenuItem jmi = getMenuItem(menu, item);
    if (jmi == null) return;
    jmi.setAccelerator(KeyStroke.getKeyStroke(keycode, MENU_MASK));
  }

  /** Sets the default status bar message. */
  public void setDefaultMessage(String statusMsg) {
    message = statusMsg == null ? "" : statusMsg;
    status.setText(message);
  }

  /** Sets the given component's status bar message. */
  public void setStatusMessage(Component c, String statusMsg) {
    statusHash.put(c, statusMsg);
    c.addFocusListener(this);
    c.addMouseListener(this);
  }

  /** Sets the visibility of the status bar. */
  public void setStatusVisible(boolean visible) {
    final boolean vis = visible;
    Util.invoke(false, false, new Runnable() {
      public void run() {
        status.setVisible(vis);
        validate();
        repaint();
      }
    });
  }


  // -- ChangeListener API methods --

  /** Updates status bar message to match highlighted menu item. */
  public void stateChanged(ChangeEvent e) {
    JMenuItem jmi = (JMenuItem) e.getSource();
    if (jmi.isArmed()) doStatus(jmi);
    else status.setText(message);
  }


  // -- FocusListener API methods --

  /** Updates status bar message to match component with the focus. */
  public void focusGained(FocusEvent e) { doStatus(e.getSource()); }

  /** Clears status bar message. */
  public void focusLost(FocusEvent e) { status.setText(message); }


  // -- MouseListener API methods --

  /** Updates status bar message to match component containing the mouse. */
  public void mouseEntered(MouseEvent e) { doStatus(e.getSource()); }

  /** Clears status bar message. */
  public void mouseExited(MouseEvent e) { status.setText(message); }

  /** Unused MouseListener method. */
  public void mouseClicked(MouseEvent e) { }

  /** Unused MouseListener method. */
  public void mousePressed(MouseEvent e) { }

  /** Unused MouseListener method. */
  public void mouseReleased(MouseEvent e) { }


  // -- Helper methods --

  /** Updates the status bar with the given object's message. */
  private void doStatus(Object o) {
    String msg = (String) statusHash.get(o);
    status.setText(msg == null ? message : msg);
  }

}
