//
// BioUtil.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;
import java.io.*;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.*;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;

import loci.visbio.*;

import visad.*;
import visad.util.*;

/** BioUtil provides a collection of general utilities used by VisBio. */
public class BioUtil {

  // -- Equality testing --

  /**
   * Determines whether the two Object arrays are component-wise equal.
   * Also works with multidimensional arrays of Objects or primitives.
   */
  public static boolean arraysEqual(Object[] a1, Object[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    if (!a1.getClass().equals(a2.getClass())) return false;
    if (a1.length == 0) return true;

    String cname = a1[0].getClass().getName();
    boolean array = cname.startsWith("[");
    char atype = cname.length() < 1 ? '\0' : cname.charAt(1);
    for (int i=0; i<a1.length; i++) {
      if (array) {
        if (atype == '[' || atype == 'L') { // array of arrays/Objects
          if (!arraysEqual((Object[]) a1[i], (Object[]) a2[i])) return false;
        }
        else if (atype == 'I') { // array of ints
          if (!arraysEqual((int[]) a1[i], (int[]) a2[i])) return false;
        }
        else if (atype == 'C') { // array of chars
          if (!arraysEqual((char[]) a1[i], (char[]) a2[i])) return false;
        }
        else if (atype == 'F') { // array of floats
          if (!arraysEqual((float[]) a1[i], (float[]) a2[i])) return false;
        }
        else if (atype == 'D') { // array of doubles
          if (!arraysEqual((double[]) a1[i], (double[]) a2[i])) return false;
        }
        else if (atype == 'J') { // array of longs
          if (!arraysEqual((long[]) a1[i], (long[]) a2[i])) return false;
        }
        else if (atype == 'S') { // array of shorts
          if (!arraysEqual((short[]) a1[i], (short[]) a2[i])) return false;
        }
        else if (atype == 'B') { // array of bytes
          if (!arraysEqual((byte[]) a1[i], (byte[]) a2[i])) return false;
        }
        else if (atype == 'Z') { // array of booleans
          if (!arraysEqual((boolean[]) a1[i], (boolean[]) a2[i])) return false;
        }
      }
      else if (!objectsEqual(a1[i], a2[i])) return false;
    }
    return true;
  }

  /** Determines whether the two boolean arrays are component-wise equal. */
  public static boolean arraysEqual(boolean[] a1, boolean[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two byte arrays are component-wise equal. */
  public static boolean arraysEqual(byte[] a1, byte[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two char arrays are component-wise equal. */
  public static boolean arraysEqual(char[] a1, char[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two double arrays are component-wise equal. */
  public static boolean arraysEqual(double[] a1, double[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two float arrays are component-wise equal. */
  public static boolean arraysEqual(float[] a1, float[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two int arrays are component-wise equal. */
  public static boolean arraysEqual(int[] a1, int[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two long arrays are component-wise equal. */
  public static boolean arraysEqual(long[] a1, long[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /** Determines whether the two short arrays are component-wise equal. */
  public static boolean arraysEqual(short[] a1, short[] a2) {
    if (a1 == null || a2 == null) return a1 == null && a2 == null;
    if (a1.length != a2.length) return false;
    for (int i=0; i<a1.length; i++) if (a1[i] != a2[i]) return false;
    return true;
  }

  /**
   * Determines whether the two objects are equal. In particular, the
   * case where one or both objects are null is handled properly.
   */
  public static boolean objectsEqual(Object o1, Object o2) {
    if (o1 == null && o2 == null) return true;
    if (o1 == null || o2 == null) return false;
    return o1.equals(o2);
  }


  // -- Object I/O --

  /** Reads an array of Strings from the given input stream. */
  public static String[] readArray(String[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new String[len];
    for (int i=0; i<len; i++) a[i] = fin.readLine();
    return a;
  }

  /** Reads an array of booleans from the given input stream. */
  public static boolean[] readArray(boolean[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new boolean[len];
    for (int i=0; i<len; i++) a[i] = fin.readLine().equals("true");
    return a;
  }

  /** Reads an array of bytes from the given input stream. */
  public static byte[] readArray(byte[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new byte[len];
    for (int i=0; i<len; i++) a[i] = Byte.parseByte(fin.readLine());
    return a;
  }

  /** Reads an array of chars from the given input stream. */
  public static char[] readArray(char[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new char[len];
    for (int i=0; i<len; i++) a[i] = fin.readLine().charAt(0);
    return a;
  }

  /** Reads an array of doubles from the given input stream. */
  public static double[] readArray(double[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new double[len];
    for (int i=0; i<len; i++) a[i] = readDouble(fin);
    return a;
  }

  /** Reads an array of floats from the given input stream. */
  public static float[] readArray(float[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new float[len];
    for (int i=0; i<len; i++) a[i] = Float.parseFloat(fin.readLine());
    return a;
  }

  /** Reads an array of ints from the given input stream. */
  public static int[] readArray(int[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new int[len];
    for (int i=0; i<len; i++) a[i] = Integer.parseInt(fin.readLine());
    return a;
  }

  /** Reads an array of longs from the given input stream. */
  public static long[] readArray(long[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new long[len];
    for (int i=0; i<len; i++) a[i] = Long.parseLong(fin.readLine());
    return a;
  }

  /** Reads an array of shorts from the given input stream. */
  public static short[] readArray(short[] a, BufferedReader fin)
    throws IOException
  {
    String s = fin.readLine();
    if (s.equals("null")) return null;
    int len = Integer.parseInt(s);
    a = new short[len];
    for (int i=0; i<len; i++) a[i] = Short.parseShort(fin.readLine());
    return a;
  }

  /** Reads a double from the given input stream. */
  public static double readDouble(BufferedReader fin) throws IOException {
    String s = fin.readLine();
    double d;
    if (s.equals("NaN")) d = Double.NaN;
    else d = Double.parseDouble(s);
    return d;
  }

  /** Reads a Color object from the given input stream. */
  public static Color readColor(BufferedReader fin) throws IOException {
    int r = Integer.parseInt(fin.readLine());
    int g = Integer.parseInt(fin.readLine());
    int b = Integer.parseInt(fin.readLine());
    return new Color(r, g, b);
  }

  /** Writes the given array of Objects to the given output stream. */
  public static void writeArray(Object[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of booleans to the given output stream. */
  public static void writeArray(boolean[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of bytes to the given output stream. */
  public static void writeArray(byte[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of chars to the given output stream. */
  public static void writeArray(char[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of doubles to the given output stream. */
  public static void writeArray(double[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of floats to the given output stream. */
  public static void writeArray(float[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of ints to the given output stream. */
  public static void writeArray(int[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of longs to the given output stream. */
  public static void writeArray(long[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given array of shorts to the given output stream. */
  public static void writeArray(short[] a, PrintWriter fout) {
    if (a == null) fout.println("null");
    else {
      fout.println(a.length);
      for (int i=0; i<a.length; i++) fout.println(a[i]);
    }
  }

  /** Writes the given color object to the given output stream. */
  public static void writeColor(Color color, PrintWriter fout) {
    fout.println(color.getRed());
    fout.println(color.getGreen());
    fout.println(color.getBlue());
  }


  // -- GUI functions --

  /**
   * Pads a component or group of components with
   * horizontal space on both sides.
   */
  public static JPanel pad(Component c) { return pad(c, true, true); }

  /**
   * Pads a component or group of components with
   * horizontal space on one or both sides.
   */
  public static JPanel pad(Component c, boolean left, boolean right) {
    // Used throughout VisBio's GUI
    JPanel p;
    if (c instanceof JPanel) {
      p = (JPanel) c;
      if (left) {
        p.add(Box.createHorizontalGlue(), 0);
        p.add(Box.createHorizontalStrut(5), 0);
      }
      if (right) {
        p.add(Box.createHorizontalGlue());
        p.add(Box.createHorizontalStrut(5));
      }
    }
    else {
      p = new JPanel();
      p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
      if (left) {
        p.add(Box.createHorizontalStrut(5));
        p.add(Box.createHorizontalGlue());
      }
      p.add(c);
      if (right) {
        p.add(Box.createHorizontalGlue());
        p.add(Box.createHorizontalStrut(5));
      }
    }
    return p;
  }

  /** Constructs a JButton with an icon from the given file id. */
  public static JButton makeButton(Object owner, String id,
    String altText, int wpad, int hpad)
  {
    // Used by: util/SpinWidget, view/ViewPanel
    URL url = owner.getClass().getResource(id);
    ImageIcon icon = null;
    if (url != null) icon = new ImageIcon(url);
    JButton button;
    if (icon == null) button = new JButton(altText);
    else {
      button = new JButton(icon);
      button.setPreferredSize(new Dimension(
        icon.getIconWidth() + wpad, icon.getIconHeight() + hpad));
    }
    return button;
  }

  /** Creates a JLabel with black text. */
  public static JLabel makeLabel(String label) {
    // Used throughout VisBio's GUI
    JLabel l = new JLabel(label);
    l.setForeground(Color.black);
    return l;
  }

  /** Creates a JTextField of fixed size. */
  public static JTextField makeField(int columns) {
    // Used throughout VisBio's GUI
    JTextField field = new JTextField(columns);
    Dimension size = field.getPreferredSize();
    field.setMinimumSize(size);
    field.setMaximumSize(size);
    return field;
  }

  /** Sets the given component's tool tip. */
  public static void setTip(StatusFrame frame, JComponent c, String msg) {
    // Used throughout VisBio's GUI
    frame.setStatusMessage(c, msg);
    c.setToolTipText(msg);
  }

  /** Hashtable for keeping track of wait cursor states. */
  private static Hashtable waitHash = new Hashtable();

  /**
   * Toggles the cursor between hourglass and normal pointer mode
   * for the given component.
   */
  public static void setWaitCursor(Component c, boolean wait) {
    if (!(c instanceof Window)) c = getWindow(c);
    Integer i = (Integer) waitHash.get(c);
    if (i == null) i = new Integer(0);
    boolean doWait = false, doNorm = false;
    if (wait) {
      if (i.intValue() == 0) doWait = true;
      i = new Integer(i.intValue() + 1);
    }
    else {
      i = new Integer(i.intValue() - 1);
      if (i.intValue() == 0) doNorm = true;
    }
    waitHash.put(c, i);
    if (doWait) c.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    else if (doNorm) c.setCursor(Cursor.getDefaultCursor());
  }

  /** Gets the containing window for the given component. */
  public static Window getWindow(Component c) {
    // Used by: util/BioUtil, view/ViewPanel
    Window w = null;
    Component p = c;
    while (p != null) {
      p = p.getParent();
      if (p instanceof Window) {
        w = (Window) p;
        break;
      }
    }
    return w;
  }

  /** Constructs a JFileChooser that recognizes accepted VisBio file types. */
  public static JFileChooser getVisBioFileChooser() {
    // Used by: data/DataManager, data/ImportGroupPane, data/ImportSeriesPane
    JFileChooser dialog = new JFileChooser(System.getProperty("user.dir"));
    Vector filters = new Vector();

    // Bio-Rad PIC - biorad/BioRadForm
    FileFilter biorad = new ExtensionFileFilter("pic", "BioRad PIC files");
    dialog.addChoosableFileFilter(biorad);
    filters.add(biorad);

    // TIFF - tiff/TiffForm, ij/ImageJForm
    FileFilter tiff = new ExtensionFileFilter(
      new String[] {"tiff", "tif"}, "Multi-page TIFF stacks");
    dialog.addChoosableFileFilter(tiff);
    filters.add(tiff);

    // QuickTime - qt/QTForm
    FileFilter qt = new ExtensionFileFilter("mov", "QuickTime movies");
    dialog.addChoosableFileFilter(qt);
    filters.add(qt);

    // BMP - ij/ImageJForm
    FileFilter bmp = new ExtensionFileFilter("bmp", "BMP images");
    dialog.addChoosableFileFilter(bmp);
    filters.add(bmp);

    // DICOM - ij/ImageJForm
    FileFilter dicom = new ExtensionFileFilter("dicom", "DICOM images");
    dialog.addChoosableFileFilter(dicom);
    filters.add(dicom);

    // FITS - ij/ImageJForm
    FileFilter fits = new ExtensionFileFilter("fits", "FITS images");
    dialog.addChoosableFileFilter(fits);
    filters.add(fits);

    // GIF - ij/ImageJForm
    FileFilter gif = new ExtensionFileFilter("gif", "GIF images");
    dialog.addChoosableFileFilter(gif);
    filters.add(gif);

    // JPEG - ij/ImageJForm
    FileFilter jpeg = new ExtensionFileFilter(
      new String[] {"jpg", "jpeg", "jpe"}, "JPEG images");
    dialog.addChoosableFileFilter(jpeg);
    filters.add(jpeg);

    // LUT - ij/ImageJForm
    FileFilter lut = new ExtensionFileFilter("lut", "LUT images");
    dialog.addChoosableFileFilter(lut);
    filters.add(lut);

    // PGM - ij/ImageJForm
    FileFilter pgm = new ExtensionFileFilter("pgm", "PGM images");
    dialog.addChoosableFileFilter(pgm);
    filters.add(pgm);

    // ROI - ij/ImageJForm
    FileFilter roi = new ExtensionFileFilter("roi", "ROI images");
    dialog.addChoosableFileFilter(roi);
    filters.add(roi);

    // ZIP-compressed TIFF - ij/ImageJForm
    FileFilter zip = new ExtensionFileFilter(
      "zip", "ZIP-compressed TIFF images");
    dialog.addChoosableFileFilter(zip);
    filters.add(zip);

    // combination filter
    FileFilter[] ff = new FileFilter[filters.size()];
    filters.copyInto(ff);
    FileFilter combo = new ComboFileFilter(ff, "All VisBio file types");
    dialog.addChoosableFileFilter(combo);

    return dialog;
  }


  // -- VisAD functions --

  /**
   * Collapses a field from the form: <tt>(z -> ((x, y) -> (v1, ..., vn))</tt>
   * into the form: <tt>((x, y, z) -> (v1, ..., vn))</tt>.
   */
  public static FlatField collapse(FieldImpl f)
    throws VisADException, RemoteException
  {
    // Used by: view/SliceManager, view/RenderManager
    if (f == null) return null;

    FlatField collapse;
    try { collapse = (FlatField) f.domainMultiply(); }
    catch (FieldException exc) { collapse = null; }

    if (collapse == null) {
      // images dimensions do not match; resample so that they do
      GriddedSet set = (GriddedSet) f.getDomainSet();
      int len = set.getLengths()[0];
      int res_x = 0;
      int res_y = 0;
      for (int i=0; i<len; i++) {
        FlatField flat = (FlatField) f.getSample(i);
        GriddedSet flat_set = (GriddedSet) flat.getDomainSet();
        int[] l = flat_set.getLengths();
        if (l[0] > res_x) res_x = l[0];
        if (l[1] > res_y) res_y = l[1];
      }
      FieldImpl nf = new FieldImpl((FunctionType) f.getType(), set);
      for (int i=0; i<len; i++) {
        FlatField flat = (FlatField) f.getSample(i);
        GriddedSet flat_set = (GriddedSet) flat.getDomainSet();
        int[] l = flat_set.getLengths();
        if (l[0] > res_x) res_x = l[0];
        if (l[1] > res_y) res_y = l[1];
      }
      for (int i=0; i<len; i++) {
        FlatField flat = (FlatField) f.getSample(i);
        GriddedSet flat_set = (GriddedSet) flat.getDomainSet();
        nf.setSample(i, flat.resample(
          new Integer2DSet(flat_set.getType(), res_x, res_y),
          Data.WEIGHTED_AVERAGE, Data.NO_ERRORS), false);
      }
      collapse = (FlatField) nf.domainMultiply();
    }

    return collapse;
  }

  /**
   * Gets an array of ScalarMaps from the given display,
   * corresponding to the specified RealTypes.
   */
  public static ScalarMap[] getMaps(DisplayImpl display, RealType[] types) {
    // Used by: view/ColorManager, view/RenderManager
    ScalarMap[] maps = new ScalarMap[types.length];
    Vector v = display.getMapVector();
    int size = v.size();
    for (int i=0; i<size; i++) {
      ScalarMap map = (ScalarMap) v.elementAt(i);
      ScalarType type = map.getScalar();
      for (int j=0; j<types.length; j++) {
        if (type.equals(types[j])) {
          maps[j] = map;
          break;
        }
      }
    }
    return maps;
  }

  /** Hashtable for keeping track of display states. */
  private static Hashtable displayHash = new Hashtable();

  /** Enables or disables the given display. */
  public static void setDisplayDisabled(DisplayImpl d, boolean disable) {
    // Used by: view/ColorManager, view/ColorPane, view/ViewManager,
    //          measure/MeasurePool
    if (d == null) return;
    Integer i = (Integer) displayHash.get(d);
    if (i == null) i = new Integer(0);
    boolean doDisable = false, doEnable = false;
    if (disable) {
      if (i.intValue() == 0) doDisable = true;
      i = new Integer(i.intValue() + 1);
    }
    else {
      i = new Integer(i.intValue() - 1);
      if (i.intValue() == 0) doEnable = true;
    }
    displayHash.put(d, i);
    if (doDisable) d.disableAction();
    else if (doEnable) d.enableAction();
  }

  /** Converts the given cursor coordinates to domain coordinates. */
  public static double[] cursorToDomain(DisplayImpl d, double[] cursor) {
    // Used by: util/BioUtil

    // locate x, y and z mappings
    Vector maps = d.getMapVector();
    int numMaps = maps.size();
    ScalarMap map_x = null, map_y = null, map_z = null;
    for (int i=0; i<numMaps; i++) {
      if (map_x != null && map_y != null && map_z != null) break;
      ScalarMap map = (ScalarMap) maps.elementAt(i);
      DisplayRealType drt = map.getDisplayScalar();
      if (drt.equals(Display.XAxis)) map_x = map;
      else if (drt.equals(Display.YAxis)) map_y = map;
      else if (drt.equals(Display.ZAxis)) map_z = map;
    }

    // adjust for scale
    double[] scale_offset = new double[2];
    double[] dummy = new double[2];
    double[] values = new double[3];
    if (map_x == null) values[0] = Double.NaN;
    else {
      map_x.getScale(scale_offset, dummy, dummy);
      values[0] = (cursor[0] - scale_offset[1]) / scale_offset[0];
    }
    if (map_y == null) values[1] = Double.NaN;
    else {
      map_y.getScale(scale_offset, dummy, dummy);
      values[1] = (cursor[1] - scale_offset[1]) / scale_offset[0];
    }
    if (map_z == null) values[2] = Double.NaN;
    else {
      map_z.getScale(scale_offset, dummy, dummy);
      values[2] = (cursor[2] - scale_offset[1]) / scale_offset[0];
    }

    return values;
  }

  /** Converts the given pixel coordinates to cursor coordinates. */
  public static double[] pixelToCursor(DisplayImpl d, int x, int y) {
    // Used by: util/BioUtil
    MouseBehavior mb = d.getDisplayRenderer().getMouseBehavior();
    VisADRay ray = mb.findRay(x, y);
    return ray.position;
  }

  /** Converts the given pixel coordinates to domain coordinates. */
  public static double[] pixelToDomain(DisplayImpl d, int x, int y) {
    // Used by: measure/MeasurePool, measure/MeasureList
    return cursorToDomain(d, pixelToCursor(d, x, y));
  }


  // -- Mathematical functions --

  /**
   * Gets the distance between the endpoints p and q, using
   * the given conversion values between pixels and microns.
   *
   * @param p Coordinates of the first endpoint
   * @param q Coordinates of the second endpoint
   * @param m Conversion values between microns and pixels
   */
  public static double getDistance(double[] p, double[] q, double[] m) {
    // Used by: measure/AlignmentPlane, measure/MeasureManager,
    //          measure/MeasurePanel
    int len = p.length;
    double sum = 0;
    for (int i=0; i<len; i++) {
      double dist = m[i] * (q[i] - p[i]);
      sum += dist * dist;
    }
    return Math.sqrt(sum);
  }

  /** Rounds the value to nearest value along the given progression. */
  public static int getNearest(double val, int min, int max, int step) {
    // Used by: measure/MeasureList, measure/PoolPoint
    int lo = (int) ((val - min) / step);
    int hi = lo + step;
    int v = (val - lo < hi - val) ? lo : hi;
    if (v < min) v = min;
    else if (v > max) {
      int q = (max - min) / step;
      v = min + q * step;
    }
    return v;
  }

  /**
   * Computes a unique 1-D index corresponding to the multidimensional
   * position given in the pos array, using the specified lengths array
   * as the maximum value at each positional dimension.
   */
  public static int positionToRaster(int[] lengths, int[] pos) {
    // Used by: data/ScreenData, measure/AlignmentInfo, measure/MeasureList
    int[] offsets = new int[lengths.length];
    if (offsets.length > 0) offsets[0] = 1;
    for (int i=1; i<offsets.length; i++) {
      offsets[i] = offsets[i - 1] * lengths[i - 1];
    }
    int raster = 0;
    for (int i=0; i<pos.length; i++) raster += offsets[i] * pos[i];
    return raster;
  }

  /**
   * Computes a unique 3-D position corresponding to the given raster
   * value, using the specified lengths array as the maximum value at
   * each positional dimension.
   */
  public static int[] rasterToPosition(int[] lengths, int raster) {
    // Used by: data/ExportPane, data/RawData, data/ScreenData,
    //          measure/MeasureList
    int[] offsets = new int[lengths.length];
    if (offsets.length > 0) offsets[0] = 1;
    for (int i=1; i<offsets.length; i++) {
      offsets[i] = offsets[i - 1] * lengths[i - 1];
    }
    int[] pos = new int[lengths.length];
    for (int i=0; i<pos.length; i++) {
      int q = i < pos.length - 1 ? raster % offsets[i + 1] : raster;
      pos[i] = q / offsets[i];
      raster -= q;
    }
    return pos;
  }

  /**
   * Computes the maximum raster value of a positional array with
   * the given maximum values.
   */
  public static int getRasterLength(int[] lengths) {
    // Used by: measure/MeasureList
    int len = 1;
    for (int i=0; i<lengths.length; i++) len *= lengths[i];
    return len;
  }


  // -- Debugging methods --

  /** Pops up a message box, for blocking the current thread. */
  public static void pause(String msg) {
    JOptionPane.showMessageDialog(null, msg,
      "VisBio", JOptionPane.PLAIN_MESSAGE);
  }

}
