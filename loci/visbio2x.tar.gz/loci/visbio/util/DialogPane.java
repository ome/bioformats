//
// DialogPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import visad.util.Util;

/**
 * DialogPane provides an extensible interface for
 * creating dialogs with Ok and Cancel buttons.
 */
public class DialogPane extends JPanel implements ActionListener {

  // -- Constants --

  /** Return value if approve (ok) is chosen. */
  public static final int APPROVE_OPTION = 1;

  /** Return value if cancel is chosen. */
  public static final int CANCEL_OPTION = 2;


  // -- Fields --

  /** Pane where subclasses can place controls. */
  protected JPanel pane;

  /** Panel containing buttons. */
  protected JPanel buttons;

  /** Ok button. */
  protected JButton ok;

  /** Currently visible dialog. */
  protected JDialog dialog;

  /** Return value of dialog. */
  protected int rval;

  /** Dialog's title. */
  protected String title;


  // -- Constructors --

  /** Creates a dialog pane. */
  public DialogPane(String title) { this(title, BoxLayout.Y_AXIS, true); }

  /** Creates a dialog pane. */
  public DialogPane(String title, int axis) { this(title, axis, true); }

  /** Creates a dialog pane. */
  public DialogPane(String title, boolean doCancel) {
    this(title, BoxLayout.Y_AXIS, doCancel);
  }

  /** Creates a dialog pane. */
  public DialogPane(String title, int axis, boolean doCancel) {
    super();
    this.title = title;
    setLayout(new BorderLayout());
    add(Box.createVerticalStrut(5), BorderLayout.CENTER);

    pane = new JPanel();
    pane.setLayout(new BoxLayout(pane, axis));
    add(pane, BorderLayout.NORTH);

    // create buttons
    buttons = new JPanel();
    buttons.setLayout(new BoxLayout(buttons, BoxLayout.X_AXIS));
    add(buttons, BorderLayout.SOUTH);

    // cancel button
    if (doCancel) {
      JButton cancel = new JButton("Cancel");
      cancel.setMnemonic('c');
      cancel.setActionCommand("cancel");
      cancel.addActionListener(this);
      buttons.add(cancel);
    }

    // ok button
    ok = new JButton("Ok");
    ok.setMnemonic('o');
    ok.setActionCommand("ok");
    ok.addActionListener(this);
    buttons.add(ok);

    BioUtil.pad(buttons);
  }


  // -- API methods --

  /** Displays a dialog using this dialog pane. */
  public int showDialog(Frame parent) { return showDialog(parent, true); }

  /** Displays a dialog using this dialog pane. */
  public int showDialog(Frame parent, boolean modal) {
    dialog = new JDialog(parent, title, modal);
    dialog.setContentPane(this);
    dialog.getRootPane().setDefaultButton(ok);
    resetComponents();
    dialog.pack();
    Util.centerWindow(parent, dialog);
    rval = CANCEL_OPTION;
    dialog.setVisible(true);
    return rval;
  }

  /**
   * Resets the dialog pane's components to their default states.
   * Subclasses should override this method to provide proper functionality.
   */
  public void resetComponents() { }


  // -- ActionListener API methods --

  /** Handles button press events. */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("ok")) {
      rval = APPROVE_OPTION;
      if (dialog != null) dialog.setVisible(false);
    }
    else if (command.equals("cancel")) {
      rval = CANCEL_OPTION;
      if (dialog != null) dialog.setVisible(false);
    }
  }

}
