//
// WizardPane.java
//

/*
VisBio application for visualization of multidimensional
biological image data. Copyright (C) 2002-2004 Curtis Rueden.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package loci.visbio.util;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import visad.util.Util;

/**
 * WizardPane provides an extensible interface for creating
 * multi-page wizard dialogs with Cancel, Back, Next and Finish buttons.
 */
public class WizardPane extends DialogPane {

  // -- Fields --

  /** Panels representing the wizard's pages. */
  protected JPanel[] pages;

  /** The current page. */
  protected int page;

  /** Wizard's next button. */
  protected JButton next;

  /** Wizard's back button. */
  protected JButton back;


  // -- Constructor --

  /** Creates a file series chooser dialog. */
  public WizardPane(String title) {
    super(title);
    page = -1;

    // back button
    back = new JButton("< Back");
    back.setMnemonic('b');
    back.setActionCommand("back");
    back.addActionListener(this);
    back.setEnabled(false);
    buttons.add(Box.createHorizontalStrut(5), 3);
    buttons.add(back, 4);

    // next button
    next = new JButton("Next >");
    next.setMnemonic('n');
    next.setActionCommand("next");
    next.addActionListener(this);
    next.setEnabled(false);
    buttons.add(next, 5);
    buttons.add(Box.createHorizontalStrut(5), 6);

    // finish button
    ok.setText("Finish");
    ok.setMnemonic('f');
  }


  // -- API methods --

  /** Sets wizard's pages to match the given panels. */
  public void setPages(JPanel[] pages) {
    this.pages = pages;
    for (int i=0; i<pages.length; i++) {
      pane.add(pages[i]);
      pages[i].setVisible(false);
    }
    setPage(0);
  }

  /** Sets the current page to the given value. */
  public void setPage(int page) {
    if (this.page == page) return;
    if (this.page >= 0) pages[this.page].setVisible(false);
    pages[page].setVisible(true);
    this.page = page;
    back.setEnabled(page > 0);
    int last = pages.length - 1;
    next.setEnabled(page < last);
    ok.setEnabled(page == last);
    if (dialog != null) {
      // resize and center dialog, and repack
      Window parent = dialog.getOwner();
      Point loc = parent.getLocation();
      Dimension p = parent.getSize();
      Dimension w = dialog.getPreferredSize();
      dialog.setBounds(new Rectangle(loc.x + (p.width - w.width) / 2,
        loc.y + (p.height - w.height) / 2, w.width, w.height));
      dialog.pack();
    }
  }


  // -- DialogPane API methods --

  /**
   * Resets the wizard pane's components to their default states.
   * Subclasses should override this method to provide proper functionality.
   */
  public void resetComponents() { setPage(0); }


  // -- ActionListener API methods --

  /** Handles button press events. */
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("back")) setPage(page - 1);
    else if (command.equals("next")) setPage(page + 1);
    else super.actionPerformed(e);
  }

}
