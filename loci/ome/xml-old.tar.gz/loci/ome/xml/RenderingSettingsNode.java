/*
 * loci.ome.xml.RenderingSettingsNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Experimenter;
import org.openmicroscopy.ds.st.RenderingSettings;
import org.w3c.dom.Element;

/**
 * RenderingSettingsNode is the node corresponding to the
 * "RenderingSettings" XML element.
 */
public class RenderingSettingsNode extends AttributeNode
  implements RenderingSettings
{

  // -- Constructor --

  /**
   * Constructs a RenderingSettings node with the given associated DOM element.
   */
  public RenderingSettingsNode(Element element) { super(element); }


  // -- RenderingSettings API methods --

  /** Gets Active attribute of the RenderingSettings element. */
  public Boolean isActive() { return getBooleanAttribute("Active"); }

  /** Sets Active attribute for the RenderingSettings element. */
  public void setActive(Boolean value) {
    setBooleanAttribute("Active", value);
  }

  /** Gets Alpha attribute of the RenderingSettings element. */
  public Integer getAlpha() { return getIntegerAttribute("Alpha"); }

  /** Sets Alpha attribute for the RenderingSettings element. */
  public void setAlpha(Integer value) { setIntegerAttribute("Alpha", value); }

  /** Gets Blue attribute of the RenderingSettings element. */
  public Integer getBlue() { return getIntegerAttribute("Blue"); }

  /** Sets Blue attribute for the RenderingSettings element. */
  public void setBlue(Integer value) { setIntegerAttribute("Blue", value); }

  /** Gets Green attribute of the RenderingSettings element. */
  public Integer getGreen() { return getIntegerAttribute("Green"); }

  /** Sets Green attribute for the RenderingSettings element. */
  public void setGreen(Integer value) { setIntegerAttribute("Green", value); }

  /** Gets Red attribute of the RenderingSettings element. */
  public Integer getRed() { return getIntegerAttribute("Red"); }

  /** Sets Red attribute for the RenderingSettings element. */
  public void setRed(Integer value) { setIntegerAttribute("Red", value); }

  /** Gets InputEnd attribute of the RenderingSettings element. */
  public Double getInputEnd() { return getDoubleAttribute("InputEnd"); }

  /** Sets InputEnd attribute for the RenderingSettings element. */
  public void setInputEnd(Double value) {
    setDoubleAttribute("InputEnd", value);
  }

  /** Gets InputStart attribute of the RenderingSettings element. */
  public Double getInputStart() { return getDoubleAttribute("InputStart"); }

  /** Sets InputStart attribute for the RenderingSettings element. */
  public void setInputStart(Double value) {
    setDoubleAttribute("InputStart", value);
  }

  /** Gets TheC attribute of the RenderingSettings element. */
  public Integer getTheC() { return getIntegerAttribute("TheC"); }

  /** Sets TheC attribute for the RenderingSettings element. */
  public void setTheC(Integer value) { setIntegerAttribute("TheC", value); }

  /** Gets BitResolution attribute of the RenderingSettings element. */
  public Integer getBitResolution() {
    return getIntegerAttribute("BitResolution");
  }

  /** Sets BitResolution attribute for the RenderingSettings element. */
  public void setBitResolution(Integer value) {
    setIntegerAttribute("BitResolution", value);
  }

  /** Gets CdEnd attribute of the RenderingSettings element. */
  public Integer getCdEnd() { return getIntegerAttribute("CdEnd"); }

  /** Sets CdEnd attribute for the RenderingSettings element. */
  public void setCdEnd(Integer value) { setIntegerAttribute("CdEnd", value); }

  /** Gets CdStart attribute of the RenderingSettings element. */
  public Integer getCdStart() { return getIntegerAttribute("CdStart"); }

  /** Sets CdStart attribute for the RenderingSettings element. */
  public void setCdStart(Integer value) {
    setIntegerAttribute("CdStart", value);
  }

  /** Gets Coefficient attribute of the RenderingSettings element. */
  public Double getCoefficient() { return getDoubleAttribute("Coefficient"); }

  /** Sets Coefficient attribute for the RenderingSettings element. */
  public void setCoefficient(Double value) {
    setDoubleAttribute("Coefficient", value);
  }

  /** Gets Family attribute of the RenderingSettings element. */
  public Integer getFamily() { return getIntegerAttribute("Family"); }

  /** Sets Family attribute for the RenderingSettings element. */
  public void setFamily(Integer value) {
    setIntegerAttribute("Family", value);
  }

  /** Gets Model attribute of the RenderingSettings element. */
  public Integer getModel() { return getIntegerAttribute("Model"); }

  /** Sets Model attribute for the RenderingSettings element. */
  public void setModel(Integer value) { setIntegerAttribute("Model", value); }

  /** Gets TheT attribute of the RenderingSettings element. */
  public Integer getTheT() { return getIntegerAttribute("TheT"); }

  /** Sets TheT attribute for the RenderingSettings element. */
  public void setTheT(Integer value) { setIntegerAttribute("TheT", value); }

  /** Gets TheZ attribute of the RenderingSettings element. */
  public Integer getTheZ() { return getIntegerAttribute("TheZ"); }

  /** Sets TheZ attribute for the RenderingSettings element. */
  public void setTheZ(Integer value) { setIntegerAttribute("TheZ", value); }

  /**
   * Gets Experimenter referenced by Experimenter attribute
   * of the RenderingSettings element.
   */
  public Experimenter getExperimenter() {
    return (Experimenter) createReferencedNode(ExperimenterNode.class,
      "Experimenter", "Experimenter");
  }

  /**
   * Sets Experimenter referenced by Experimenter attribute
   * of the RenderingSettings element.
   */
  public void setExperimenter(Experimenter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Experimenter", "Experimenter");
  }

}
