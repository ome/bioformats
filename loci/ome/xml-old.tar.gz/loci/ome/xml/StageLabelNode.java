/*
 * loci.ome.xml.StageLabelNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.StageLabel;
import org.w3c.dom.Element;

/**
 * StageLabelNode is the node corresponding to the "StageLabel" XML element.
 */
public class StageLabelNode extends AttributeNode implements StageLabel {

  // -- Constructor --

  /** Constructs a StageLabel node with the given associated DOM element. */
  public StageLabelNode(Element element) { super(element); }


  // -- StageLabel API methods --

  /** Gets Z attribute of the StageLabel element. */
  public Float getZ() { return getFloatAttribute("Z"); }

  /** Sets Z attribute for the StageLabel element. */
  public void setZ(Float value) { setFloatAttribute("Z", value); }

  /** Gets Y attribute of the StageLabel element. */
  public Float getY() { return getFloatAttribute("Y"); }

  /** Sets Y attribute for the StageLabel element. */
  public void setY(Float value) { setFloatAttribute("Y", value); }

  /** Gets X attribute of the StageLabel element. */
  public Float getX() { return getFloatAttribute("X"); }

  /** Sets X attribute for the StageLabel element. */
  public void setX(Float value) { setFloatAttribute("X", value); }

  /** Gets Name attribute of the StageLabel element. */
  public String getName() { return getAttribute("Name"); }

  /** Sets Name attribute for the StageLabel element. */
  public void setName(String value) { setAttribute("Name", value); }

}
