/*
 * loci.ome.xml.PixelChannelComponentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.*;
import org.w3c.dom.Element;

/**
 * PixelChannelComponentNode is the node corresponding to the
 * "ChannelComponent" XML element.
 */
public class PixelChannelComponentNode extends AttributeNode
  implements PixelChannelComponent
{

  // -- Constructor --

  /**
   * Constructs a PixelChannelComponent node
   * with the given associated DOM element.
   */
  public PixelChannelComponentNode(Element element) { super(element); }


  // -- PixelChannelComponent API methods --

  /**
   * Gets the ChannelInfo element ancestor to this ChannelComponent element.
   */
  public LogicalChannel getLogicalChannel() {
    return (LogicalChannel)
      createAncestorNode(LogicalChannelNode.class, "ChannelInfo");
  }

  /**
   * Sets the ChannelInfo element ancestor for this ChannelComponent element.
   */
  public void setLogicalChannel(LogicalChannel value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets ColorDomain attribute of the ChannelComponent element. */
  public String getColorDomain() { return getAttribute("ColorDomain"); }

  /** Sets ColorDomain attribute for the ChannelComponent element. */
  public void setColorDomain(String value) {
    setAttribute("ColorDomain", value);
  }

  /** Gets Index attribute of the ChannelComponent element. */
  public Integer getIndex() { return getIntegerAttribute("Index"); }

  /** Sets Index attribute for the ChannelComponent element. */
  public void setIndex(Integer value) { setIntegerAttribute("Index", value); }

  /**
   * Gets a Pixels node corresponding to the ChannelComponent element's
   * Pixels attribute (which references a Pixels element).
   */
  public Pixels getPixels() {
    return (Pixels) createNode(PixelsNode.class,
      findElement("Pixels", getAttribute("Pixels")));
  }

  /**
   * Sets the ChannelComponent's Pixels attribute to match
   * the one associated with the given Pixels node.
   */
  public void setPixels(Pixels value) {
    if (!(value instanceof OMEXMLNode)) return;
    setAttribute("Pixels", ((OMEXMLNode) value).getLSID());
  }

}
