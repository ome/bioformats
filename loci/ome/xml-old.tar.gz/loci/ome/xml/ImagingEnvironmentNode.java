/*
 * loci.ome.xml.ImagingEnvironmentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.ImagingEnvironment;
import org.w3c.dom.Element;

/**
 * ImagingEnvironmentNode is the node corresponding to the
 * "ImagingEnvironment" XML element.
 */
public class ImagingEnvironmentNode extends AttributeNode
  implements ImagingEnvironment
{

  // -- Constructor --

  /**
   * Constructs an ImagingEnvironment node
   * with the given associated DOM element.
   */
  public ImagingEnvironmentNode(Element element) { super(element); }


  // -- ImagingEnvironment API methods --

  /** Gets CO2Percent attribute of the ImagingEnvironment element. */
  public Float getCO2Percent() { return getFloatElement("CO2Percent"); }

  /** Sets CO2Percent attribute for the ImagingEnvironment element. */
  public void setCO2Percent(Float value) {
    setFloatElement("CO2Percent", value);
  }

  /** Gets Humidity attribute of the ImagingEnvironment element. */
  public Float getHumidity() { return getFloatElement("Humidity"); }

  /** Sets Humidity attribute for the ImagingEnvironment element. */
  public void setHumidity(Float value) { setFloatElement("Humidity", value); }

  /** Gets AirPressure attribute of the ImagingEnvironment element. */
  public Float getAirPressure() { return getFloatElement("AirPressure"); }

  /** Sets AirPressure attribute for the ImagingEnvironment element. */
  public void setAirPressure(Float value) {
    setFloatElement("AirPressure", value);
  }

  /** Gets Temperature attribute of the ImagingEnvironment element. */
  public Float getTemperature() { return getFloatElement("Temperature"); }

  /** Sets Temperature attribute for the ImagingEnvironment element. */
  public void setTemperature(Float value) {
    setFloatElement("Temperature", value);
  }

}
