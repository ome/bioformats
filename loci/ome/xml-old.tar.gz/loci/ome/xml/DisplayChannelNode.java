/*
 * loci.ome.xml.DisplayChannelNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.DisplayChannel;
import org.w3c.dom.Element;

/**
 * DisplayChannelNode is the node corresponding to the
 * "RedChannel," "GreenChannel," "BlueChannel" and "GreyChannel" XML elements.
 */
public class DisplayChannelNode extends AttributeNode
  implements DisplayChannel
{

  // -- Constructor --

  /**
   * Constructs a DisplayChannel node
   * with the given associated DOM element.
   */
  public DisplayChannelNode(Element element) { super(element); }


  // -- DisplayChannel API methods --

  /** Gets Gamma attribute of the element. */
  public Float getGamma() { return getFloatAttribute("Gamma"); }

  /** Sets Gamma attribute of the element. */
  public void setGamma(Float value) { setFloatAttribute("Gamma", value); }

  /** Gets WhiteLevel attribute of the element. */
  public Double getWhiteLevel() { return getDoubleAttribute("WhiteLevel"); }

  /** Sets WhiteLevel attribute of the element. */
  public void setWhiteLevel(Double value) {
    setDoubleAttribute("WhiteLevel", value);
  }

  /** Gets BlackLevel attribute of the element. */
  public Double getBlackLevel() { return getDoubleAttribute("BlackLevel"); }

  /** Sets BlackLevel attribute of the element. */
  public void setBlackLevel(Double value) {
    setDoubleAttribute("BlackLevel", value);
  }

  /** Gets ChannelNumber attribute of the element. */
  public Integer getChannelNumber() {
    return getIntegerAttribute("ChannelNumber");
  }

  /** Sets ChannelNumber attribute of the element. */
  public void setChannelNumber(Integer value) {
    setIntegerAttribute("ChannelNumber", value);
  }

  /**
   * Gets a list of DisplayOptions elements referencing this
   * DisplayChannel node via a BlueChannel child element.
   */
  public List getDisplayOptionsListByBlueChannel() {
    return createReferralNodes(DisplayOptionsNode.class,
      "DisplayOptions", "BlueChannel");
  }

  /**
   * Gets the number of DisplayOptions elements referencing this
   * DisplayChannel node via a BlueChannel child element.
   */
  public int countDisplayOptionsListByBlueChannel() {
    return getSize(getReferrals("DisplayOptions", "BlueChannel"));
  }

  /**
   * Gets a list of DisplayOptions elements referencing this
   * DisplayChannel node via a GreenChannel child element.
   */
  public List getDisplayOptionsListByGreenChannel() {
    return createReferralNodes(DisplayOptionsNode.class,
      "DisplayOptions", "GreenChannel");
  }

  /**
   * Gets the number of DisplayOptions elements referencing this
   * DisplayChannel node via a GreenChannel child element.
   */
  public int countDisplayOptionsListByGreenChannel() {
    return getSize(getReferrals("DisplayOptions", "GreenChannel"));
  }

  /**
   * Gets a list of DisplayOptions elements referencing this
   * DisplayChannel node via a GreyChannel child element.
   */
  public List getDisplayOptionsListByGreyChannel() {
    return createReferralNodes(DisplayOptionsNode.class,
      "DisplayOptions", "GreyChannel");
  }

  /**
   * Gets the number of DisplayOptions elements referencing this
   * DisplayChannel node via a GreyChannel child element.
   */
  public int countDisplayOptionsListByGreyChannel() {
    return getSize(getReferrals("DisplayOptions", "GreyChannel"));
  }

  /**
   * Gets a list of DisplayOptions elements referencing this
   * DisplayChannel node via a RedChannel child element.
   */
  public List getDisplayOptionsListByRedChannel() {
    return createReferralNodes(DisplayOptionsNode.class,
      "DisplayOptions", "RedChannel");
  }

  /**
   * Gets the number of DisplayOptions elements referencing this
   * DisplayChannel node via a RedChannel child element.
   */
  public int countDisplayOptionsListByRedChannel() {
    return getSize(getReferrals("DisplayOptions", "RedChannel"));
  }

}
