/*
 * loci.ome.xml.PlaneSum_XiNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.PlaneSum_Xi;
import org.w3c.dom.Element;

/**
 * PlaneSum_XiNode is the node corresponding to the "PlaneSum_Xi" XML element.
 */
public class PlaneSum_XiNode extends AttributeNode implements PlaneSum_Xi {

  // -- Constructor --

  /** Constructs a PlaneSum_Xi node with the given associated DOM element. */
  public PlaneSum_XiNode(Element element) { super(element); }


  // -- PlaneSum_Xi API methods --

  /** Gets Sum_Xi attribute of the PlaneSum_Xi element. */
  public Float getSum_Xi() { return getFloatAttribute("Sum_Xi"); }

  /** Sets Sum_Xi attribute for the PlaneSum_Xi element. */
  public void setSum_Xi(Float value) { setFloatAttribute("Sum_Xi", value); }

  /** Gets TheT attribute of the PlaneSum_Xi element. */
  public Integer getTheT() { return getIntegerAttribute("TheT"); }

  /** Sets TheT attribute for the PlaneSum_Xi element. */
  public void setTheT(Integer value) { setIntegerAttribute("TheT", value); }

  /** Gets TheC attribute of the PlaneSum_Xi element. */
  public Integer getTheC() { return getIntegerAttribute("TheC"); }

  /** Sets TheC attribute for the PlaneSum_Xi element. */
  public void setTheC(Integer value) { setIntegerAttribute("TheC", value); }

  /** Gets TheZ attribute of the PlaneSum_Xi element. */
  public Integer getTheZ() { return getIntegerAttribute("TheZ"); }

  /** Sets TheZ attribute for the PlaneSum_Xi element. */
  public void setTheZ(Integer value) { setIntegerAttribute("TheZ", value); }

}
