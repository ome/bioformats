/*
 * loci.ome.xml.ImagePlateNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.ImagePlate;
import org.openmicroscopy.ds.st.Plate;
import org.w3c.dom.Element;

/**
 * ImagePlateNode is the node corresponding to the "ImagePlate" XML element.
 */
public class ImagePlateNode extends AttributeNode implements ImagePlate {

  // -- Constructor --

  /** Constructs a ImagePlate node with the given associated DOM element. */
  public ImagePlateNode(Element element) { super(element); }


  // -- ImagePlate API methods --

  /** Gets Well attribute of the ImagePlate element. */
  public String getWell() { return getAttribute("Well"); }

  /** Sets Well attribute for the ImagePlate element. */
  public void setWell(String value) { setAttribute("Well", value); }

  /** Gets Sample attribute of the ImagePlate element. */
  public Integer getSample() { return getIntegerAttribute("Sample"); }

  /** Sets Sample attribute for the ImagePlate element. */
  public void setSample(Integer value) {
    setIntegerAttribute("Sample", value);
  }

  /** Gets Confidence attribute of the Classification element. */
  public Float getConfidence() { return getFloatAttribute("Confidence"); }

  /** Sets Confidence attribute for the Classification element. */
  public void setConfidence(Float value) {
    setFloatAttribute("Confidence", value);
  }

  /** Gets Plate referenced by Plate attribute of the ImagePlate element. */
  public Plate getPlate() {
    return (Plate) createReferencedNode(PlateNode.class, "Plate", "Plate");
  }

  /** Sets Plate referenced by Plate attribute of the ImagePlate element. */
  public void setPlate(Plate value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Plate", "Plate");
  }

}
