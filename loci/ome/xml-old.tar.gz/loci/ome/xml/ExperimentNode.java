/*
 * loci.ome.xml.ExperimentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Experiment;
import org.openmicroscopy.ds.st.Experimenter;
import org.w3c.dom.Element;

/**
 * ExperimentNode is the node corresponding to the "Experiment" XML element.
 */
public class ExperimentNode extends AttributeNode implements Experiment {

  // -- Constructor --

  /** Constructs a Experiment node with the given associated DOM element. */
  public ExperimentNode(Element element) { super(element); }


  // -- Experiment API methods --

  /**
   * Gets an Experimenter node representing the
   * Experiment element's referenced Experimenter element.
   */
  public Experimenter getExperimenter() {
    return (Experimenter) createReferencedNode(
      ExperimenterNode.class, "Experimenter");
  }

  /**
   * Sets the Experiment element's referenced Experimenter element to match
   * the one associated with the given Experimenter node.
   */
  public void setExperimenter(Experimenter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Experimenter");
  }

  /** Gets value of Description child element for Experiment element. */
  public String getDescription() {
    return getCharacterData(getChildElement("Description"));
  }

  /** Sets value for Experiment element's Description child element. */
  public void setDescription(String value) {
    setCharacterData(value, getChildElement("Description"));
  }

  /** Gets Type attribute of the Experiment element. */
  public String getType() { return getAttribute("Type"); }

  /** Sets Type attribute for the Experiment element. */
  public void setType(String value) { setAttribute("Type", value); }

  /**
   * Gets a list of ImageExperiment elements referencing this Experiment node.
   */
  public List getImageExperimentList() {
    return createAttrReferralNodes(ImageExperimentNode.class,
      "ImageExperiment", "Experiment");
  }

  /**
   * Gets the number of ImageExperiment elements
   * referencing this Experiment node.
   */
  public int countImageExperimentList() {
    return getSize(getAttrReferrals("ImageExperiment", "Experiment"));
  }

}
