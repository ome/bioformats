/*
 * loci.ome.xml.SignalNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Signal;
import org.w3c.dom.Element;

/** SignalNode is the node corresponding to the "Signal" XML element. */
public class SignalNode extends AttributeNode implements Signal {

  // -- Constructor --

  /** Constructs a Signal node with the given associated DOM element. */
  public SignalNode(Element element) { super(element); }


  // -- Signal API methods --

  /** Gets Background of the Signal element. */
  public Float getBackground() { return getFloatAttribute("Background"); }

  /** Sets Background for the Signal element. */
  public void setBackground(Float value) {
    setFloatAttribute("Background", value);
  }

  /** Gets GeometricSigma of the Signal element. */
  public Float getGeometricSigma() {
    return getFloatAttribute("GeometricSigma");
  }

  /** Sets GeometricSigma for the Signal element. */
  public void setGeometricSigma(Float value) {
    setFloatAttribute("GeometricSigma", value);
  }

  /** Gets Sigma of the Signal element. */
  public Float getSigma() { return getFloatAttribute("Sigma"); }

  /** Sets Sigma for the Signal element. */
  public void setSigma(Float value) { setFloatAttribute("Sigma", value); }

  /** Gets GeometricMean of the Signal element. */
  public Float getGeometricMean() {
    return getFloatAttribute("GeometricMean");
  }

  /** Sets GeometricMean for the Signal element. */
  public void setGeometricMean(Float value) {
    setFloatAttribute("GeometricMean", value);
  }

  /** Gets Mean of the Signal element. */
  public Float getMean() { return getFloatAttribute("Mean"); }

  /** Sets Mean for the Signal element. */
  public void setMean(Float value) { setFloatAttribute("Mean", value); }

  /** Gets Integral of the Signal element. */
  public Float getIntegral() { return getFloatAttribute("Integral"); }

  /** Sets Integral for the Signal element. */
  public void setIntegral(Float value) {
    setFloatAttribute("Integral", value);
  }

  /** Gets CentroidZ of the Signal element. */
  public Float getCentroidZ() { return getFloatAttribute("CentroidZ"); }

  /** Sets CentroidZ for the Signal element. */
  public void setCentroidZ(Float value) {
    setFloatAttribute("CentroidZ", value);
  }

  /** Gets CentroidY of the Signal element. */
  public Float getCentroidY() { return getFloatAttribute("CentroidY"); }

  /** Sets CentroidY for the Signal element. */
  public void setCentroidY(Float value) {
    setFloatAttribute("CentroidY", value);
  }

  /** Gets CentroidX of the Signal element. */
  public Float getCentroidX() { return getFloatAttribute("CentroidX"); }

  /** Sets CentroidX for the Signal element. */
  public void setCentroidX(Float value) {
    setFloatAttribute("CentroidX", value);
  }

  /** Gets TheC of the Signal element. */
  public Integer getTheC() { return getIntegerAttribute("TheC"); }

  /** Sets TheC for the Signal element. */
  public void setTheC(Integer value) { setIntegerAttribute("TheC", value); }

}
