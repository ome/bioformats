/*
 * loci.ome.xml.ImageGroupNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Group;
import org.openmicroscopy.ds.st.ImageGroup;
import org.w3c.dom.Element;

/**
 * ImageGroupNode is the node corresponding to the "ImageGroup" XML element.
 */
public class ImageGroupNode extends AttributeNode implements ImageGroup {

  // -- Constructor --

  /** Constructs an ImageGroup node with the given associated DOM element. */
  public ImageGroupNode(Element element) { super(element); }


  // -- ImageGroup API methods --

  /**
   * Gets Group referenced by Group attribute of the ImageGroupNode element.
   */
  public Group getGroup() {
    return (Group) createReferencedNode(GroupNode.class,
      "Group", "Group");
  }

  /**
   * Sets Group referenced by Group attribute of the ImageGroupNode element.
   */
  public void setGroup(Group value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Group", "Group");
  }

}
