/*
 * loci.ome.xml.PlateNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Plate;
import org.openmicroscopy.ds.st.Screen;
import org.w3c.dom.Element;

/** PlateNode is the node corresponding to the "Plate" XML element. */
public class PlateNode extends AttributeNode implements Plate {

  // -- Constructor --

  /** Constructs a Plate node with the given associated DOM element. */
  public PlateNode(Element element) { super(element); }


  // -- Plate API methods --

  /**
   * Gets a Screen node representing the Plate element's
   * first referenced Screen element.
   */
  public Screen getScreen() {
    return (Screen) createReferencedNode(ScreenNode.class, "Screen");
  }

  /**
   * Sets the Plate element's first referenced Screen element
   * to match the one associated with the given Screen node.
   */
  public void setScreen(Screen value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Screen");
  }

  /** Gets ExternRef attribute of the Plate element. */
  public String getExternalReference() { return getAttribute("ExternRef"); }

  /** Sets ExternRef attribute of the Plate element. */
  public void setExternalReference(String value) {
    setAttribute("ExternRef", value);
  }

  /** Gets Name attribute of the Plate element. */
  public String getName() { return getAttribute("Name"); }

  /** Sets Name attribute for the Plate element. */
  public void setName(String value) { setAttribute("Name", value); }

  /** Gets a list of ImagePlate elements referencing this Plate node. */
  public List getImagePlateList() {
    return createAttrReferralNodes(ImagePlateNode.class,
      "ImagePlate", "Plate");
  }

  /** Gets the number of ImagePlate elements referencing this Plate node. */
  public int countImagePlateList() {
    return getSize(getAttrReferrals("ImagePlate", "Plate"));
  }

  /** Gets a list of PlateScreen elements referencing this Plate node. */
  public List getPlateScreenList() {
    return createAttrReferralNodes(PlateScreenNode.class,
      "PlateScreen", "Plate");
  }

  /** Gets the number of PlateScreen elements referencing this Plate node. */
  public int countPlateScreenList() {
    return getSize(getAttrReferrals("PlateScreen", "Plate"));
  }

}
