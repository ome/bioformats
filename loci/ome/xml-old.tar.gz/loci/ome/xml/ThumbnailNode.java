/*
 * loci.ome.xml.ThumbnailNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Repository;
import org.openmicroscopy.ds.st.Thumbnail;
import org.w3c.dom.Element;

/** ThumbnailNode is the node corresponding to the "Thumbnail" XML element. */
public class ThumbnailNode extends AttributeNode implements Thumbnail {

  // -- Constructor --

  /** Constructs a Thumbnail node with the given associated DOM element. */
  public ThumbnailNode(Element element) { super(element); }


  // -- Thumbnail API methods --

  /** Gets href attribute of the Thumbnail element. */
  public String getPath() { return getAttribute("href"); }

  /** Sets href attribute of the Thumbnail element. */
  public void setPath(String value) { setAttribute("href", value); }

  /**
   * Gets Repository referenced by Repository attribute
   * of the Thumbnail ST element.
   */
  public Repository getRepository() {
    Element customThumbnail = getChildElement("Thumbnail",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    String repositoryID = customThumbnail.getAttribute("Repository");
    return (Repository) createNode(RepositoryNode.class,
      findElement("Repository", repositoryID));
  }

  /**
   * Sets Repository referenced by Repository attribute
   * of the Thumbnail ST element.
   */
  public void setRepository(Repository value) {
    if (!(value instanceof OMEXMLNode)) return;
    Element customThumbnail = getChildElement("Thumbnail",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    String repositoryID = ((OMEXMLNode) value).getLSID();
    setAttribute("Repository", repositoryID, customThumbnail);
  }

  /** Gets MIMEtype attribute of the Thumbnail element. */
  public String getMimeType() { return getAttribute("MIMEtype"); }

  /** Sets MIMEtype attribute of the Thumbnail element. */
  public void setMimeType(String value) { setAttribute("MIMEtype", value); }

}
