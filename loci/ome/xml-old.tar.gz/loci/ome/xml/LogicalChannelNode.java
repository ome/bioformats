/*
 * loci.ome.xml.LogicalChannelNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.*;
import org.w3c.dom.Element;

/**
 * LogicalChannelNode is the node corresponding
 * to the "ChannelInfo" XML element.
 */
public class LogicalChannelNode extends AttributeNode
  implements LogicalChannel
{

  // -- Constructor --

  /**
   * Constructs a LogicalChannel node with the given associated DOM element.
   */
  public LogicalChannelNode(Element element) { super(element); }


  // -- LogicalChannel API methods --

  /** Gets NDfilter attribute of the ChannelInfo element. */
  public Float getNDFilter() { return getFloatAttribute("NDfilter"); }

  /** Sets NDfilter attribute of the ChannelInfo element. */
  public void setNDFilter(Float value) {
    setFloatAttribute("NDfilter", value);
  }

  /** Gets Fluor attribute of the ChannelInfo element. */
  public String getFluor() { return getAttribute("Fluor"); }

  /** Sets Fluor attribute of the ChannelInfo element. */
  public void setFluor(String value) { setAttribute("Fluor", value); }

  /** Gets EmWave attribute of the ChannelInfo element. */
  public Integer getEmissionWavelength() {
    return getIntegerAttribute("EmWave");
  }

  /** Sets EmWave attribute of the ChannelInfo element. */
  public void setEmissionWavelength(Integer value) {
    setIntegerAttribute("EmWave", value);
  }

  /** Gets ExWave attribute of the ChannelInfo element. */
  public Integer getExcitationWavelength() {
    return getIntegerAttribute("ExWave");
  }

  /** Sets ExWave attribute of the ChannelInfo element. */
  public void setExcitationWavelength(Integer value) {
    setIntegerAttribute("ExWave", value);
  }

  /** Gets AuxLightWavelength attribute of LogicalChannel element. */
  public Integer getAuxLightWavelength() {
    return getIntegerAttribute("AuxLightWavelength",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets AuxLightWavelength attribute for LogicalChannel element. */
  public void setAuxLightWavelength(Integer value) {
    setIntegerAttribute("AuxLightWavelength", value,
      findElement("LogicalChannel", getLSID()));
  }

  /** Gets AuxTechnique attribute of LogicalChannel element. */
  public String getAuxTechnique() {
    return getAttribute("AuxTechnique",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets AuxTechnique attribute for LogicalChannel element. */
  public void setAuxTechnique(String value) {
    setAttribute("AuxTechnique", value,
      findElement("LogicalChannel", getLSID()));
  }

  /** Gets AuxLightAttenuation attribute of LogicalChannel element. */
  public Float getAuxLightAttenuation() {
    return getFloatAttribute("AuxLightAttenuation",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets AuxLightAttenuation attribute for LogicalChannel element. */
  public void setAuxLightAttenuation(Float value) {
    setFloatAttribute("AuxLightAttenuation", value,
      findElement("LogicalChannel", getLSID()));
  }

  /**
   * Gets a LightSource node representing the ChannelInfo element's
   * referenced AuxLightSource (a LightSource element).
   */
  public LightSource getAuxLightSource() {
    return (LightSource) createReferencedNode(
      LightSourceNode.class, "AuxLightSource");
  }

  /**
   * Sets the ChannelInfo element's referenced AuxLightSource (a LightSource
   * element) to match the one associated with the given LightSource node.
   */
  public void setAuxLightSource(LightSource value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "AuxLightSource");
  }

  /** Gets ContrastMethod attribute of the ChannelInfo element. */
  public String getContrastMethod() { return getAttribute("ContrastMethod"); }

  /** Sets ContrastMethod attribute of the ChannelInfo element. */
  public void setContrastMethod(String value) {
    setAttribute("ContrastMethod", value);
  }

  /** Gets Mode attribute of the ChannelInfo element. */
  public String getMode() { return getAttribute("Mode"); }

  /** Sets Mode attribute of the ChannelInfo element. */
  public void setMode(String value) { setAttribute("Mode", value); }

  /** Gets PhotometricInterpretation attribute of the ChannelInfo element. */
  public String getPhotometricInterpretation() {
    return getAttribute("PhotometricInterpretation");
  }

  /** Sets PhotometricInterpretation attribute of the ChannelInfo element. */
  public void setPhotometricInterpretation(String value) {
    setAttribute("PhotometricInterpretation", value);
  }

  /** Gets PinholeSize attribute of the ChannelInfo element. */
  public Integer getPinholeSize() {
    return getIntegerAttribute("PinholeSize");
  }

  /** Sets PinholeSize attribute of the ChannelInfo element. */
  public void setPinholeSize(Integer value) {
    setIntegerAttribute("PinholeSize", value);
  }

  /** Gets IlluminationType attribute of the ChannelInfo element. */
  public String getIlluminationType() {
    return getAttribute("IlluminationType");
  }

  /** Sets IlluminationType attribute of the ChannelInfo element. */
  public void setIlluminationType(String value) {
    setAttribute("IlluminationType", value);
  }

  /** Gets DetectorGain attribute of LogicalChannel element. */
  public Float getDetectorGain() {
    return getFloatAttribute("DetectorGain",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets DetectorGain attribute for LogicalChannel element. */
  public void setDetectorGain(Float value) {
    setFloatAttribute("DetectorGain", value,
      findElement("LogicalChannel", getLSID()));
  }

  /** Gets DetectorOffset attribute of LogicalChannel element. */
  public Float getDetectorOffset() {
    return getFloatAttribute("DetectorOffset",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets DetectorOffset attribute for LogicalChannel element. */
  public void setDetectorOffset(Float value) {
    setFloatAttribute("DetectorOffset", value,
      findElement("LogicalChannel", getLSID()));
  }

  /**
   * Gets a Detector node representing the
   * ChannelInfo element's referenced Detector element.
   */
  public Detector getDetector() {
    return (Detector) createReferencedNode(DetectorNode.class, "Detector");
  }

  /**
   * Sets the ChannelInfo element's referenced Detector element to match
   * the one associated with the given Detector node.
   */
  public void setDetector(Detector value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Detector");
  }

  /**
   * Gets an OTF node representing the
   * ChannelInfo element's referenced OTF element.
   */
  public OTF getOTF() {
    return (OTF) createReferencedNode(OTFNode.class, "OTF");
  }

  /**
   * Sets the ChannelInfo element's referenced OTF element to match
   * the one associated with the given OTF node.
   */
  public void setOTF(OTF value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "OTF");
  }

  /** Gets LightWavelength attribute of LogicalChannel element. */
  public Integer getLightWavelength() {
    return getIntegerAttribute("LightWavelength",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets LightWavelength attribute for LogicalChannel element. */
  public void setLightWavelength(Integer value) {
    setIntegerAttribute("LightWavelength", value,
      findElement("LogicalChannel", getLSID()));
  }

  /** Gets LightAttenuation attribute of LogicalChannel element. */
  public Float getLightAttenuation() {
    return getFloatAttribute("LightAttenuation",
      findElement("LogicalChannel", getLSID()));
  }

  /** Sets LightAttenuation attribute for LogicalChannel element. */
  public void setLightAttenuation(Float value) {
    setFloatAttribute("LightAttenuation", value,
      findElement("LogicalChannel", getLSID()));
  }

  /**
   * Gets a LightSource node representing the
   * ChannelInfo element's referenced LightSource element.
   */
  public LightSource getLightSource() {
    return (LightSource) createReferencedNode(
      LightSourceNode.class, "LightSource");
  }

  /**
   * Sets the ChannelInfo element's referenced LightSource element to match
   * the one associated with the given LightSource node.
   */
  public void setLightSource(LightSource value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "LightSource");
  }

  /**
   * Gets a Filter node representing the
   * ChannelInfo element's referenced Filter element.
   */
  public Filter getFilter() {
    return (Filter) createReferencedNode(FilterNode.class, "Filter");
  }

  /**
   * Sets the ChannelInfo element's referenced Filter element to match
   * the one associated with the given Filter node.
   */
  public void setFilter(Filter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Filter");
  }

  /** Gets SamplesPerPixel attribute of the ChannelInfo element. */
  public Integer getSamplesPerPixel() {
    return getIntegerAttribute("SamplesPerPixel");
  }

  /** Sets SamplesPerPixel attribute of the ChannelInfo element. */
  public void setSamplesPerPixel(Integer value) {
    setIntegerAttribute("SamplesPerPixel", value);
  }

  /** Gets Name attribute of the ChannelInfo element. */
  public String getName() { return getAttribute("Name"); }

  /** Sets Name attribute for the ChannelInfo element. */
  public void setName(String value) { setAttribute("Name", value); }

  /** Gets nodes corresponding to ChannelComponent child elements. */
  public List getPixelChannelComponentList() {
    return createChildNodes(PixelChannelComponentNode.class,
      "ChannelComponent");
  }

  /** Counts the number of ChannelComponent child elements. */
  public int countPixelChannelComponentList() {
    return getSize(getChildElements("ChannelComponent"));
  }

}
