/*
 * loci.ome.xml.DatasetAnnotationNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.DatasetAnnotation;
import org.openmicroscopy.ds.st.Experimenter;
import org.w3c.dom.Element;

/**
 * DatasetAnnotationNode is the node corresponding to the
 * "DatasetAnnotation" XML element.
 */
public class DatasetAnnotationNode extends AttributeNode
  implements DatasetAnnotation
{

  // -- Constructor --

  /**
   * Constructs a DatasetAnnotation node with the given associated DOM element.
   */
  public DatasetAnnotationNode(Element element) { super(element); }


  // -- DatasetAnnotation API methods --

  /** Gets Valid attribute of the DatasetAnnotation element. */
  public Boolean isValid() { return getBooleanAttribute("Valid"); }

  /** Sets Valid attribute for the DatasetAnnotation element. */
  public void setValid(Boolean value) { setBooleanAttribute("Valid", value); }

  /** Gets Timestamp attribute of the DatasetAnnotation element. */
  public Long getTimestamp() { return getLongAttribute("Timestamp"); }

  /** Sets Timestamp attribute for the DatasetAnnotation element. */
  public void setTimestamp(Long value) {
    setLongAttribute("Timestamp", value);
  }

  /** Gets Content attribute of the DatasetAnnotation element. */
  public String getContent() { return getAttribute("Content"); }

  /** Sets Content attribute for the DatasetAnnotation element. */
  public void setContent(String value) { setAttribute("Content", value); }

  /**
   * Gets Experimenter referenced by Experimenter attribute
   * of the DatasetAnnotation element.
   */
  public Experimenter getExperimenter() {
    return (Experimenter) createReferencedNode(ExperimenterNode.class,
      "Experimenter", "Experimenter");
  }

  /**
   * Sets Experimenter referenced by Experimenter attribute
   * of the DatasetAnnotation element.
   */
  public void setExperimenter(Experimenter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Experimenter", "Experimenter");
  }

}
