/*
 * loci.ome.xml.ImageInstrumentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.*;
import org.w3c.dom.Element;

/**
 * ImageInstrumentNode is the node corresponding to the
 * "ImageInstrument" XML element.
 */
public class ImageInstrumentNode extends AttributeNode
  implements ImageInstrument
{

  // -- Constructor --

  /**
   * Constructs a ImageInstrument node with the given associated DOM element.
   */
  public ImageInstrumentNode(Element element) { super(element); }


  // -- ImageInstrument API methods --

  /**
   * Gets Objective referenced by Objective attribute
   * of the ImageInstrument element.
   */
  public Objective getObjective() {
    return (Objective) createReferencedNode(ObjectiveNode.class,
      "Objective", "Objective");
  }

  /**
   * Sets Objective referenced by Objective attribute
   * of the ImageInstrument element.
   */
  public void setObjective(Objective value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Objective", "Objective");
  }

  /**
   * Gets Instrument referenced by Instrument attribute
   * of the ImageInstrument element.
   */
  public Instrument getInstrument() {
    return (Instrument) createReferencedNode(InstrumentNode.class,
      "Instrument", "Instrument");
  }

  /**
   * Sets Instrument referenced by Instrument attribute
   * of the ImageInstrument element.
   */
  public void setInstrument(Instrument value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Instrument", "Instrument");
  }

}
