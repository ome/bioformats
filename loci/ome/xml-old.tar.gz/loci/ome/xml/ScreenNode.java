/*
 * loci.ome.xml.ScreenNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Screen;
import org.w3c.dom.Element;

/** ScreenNode is the node corresponding to the "Screen" XML element. */
public class ScreenNode extends AttributeNode implements Screen {

  // -- Constructor --

  /** Constructs a Screen node with the given associated DOM element. */
  public ScreenNode(Element element) { super(element); }


  // -- Screen API methods --

  /** Gets ExternRef attribute of the Screen element. */
  public String getExternalReference() { return getAttribute("ExternRef"); }

  /** Sets ExternRef attribute of the Screen element. */
  public void setExternalReference(String value) {
    setAttribute("ExternRef", value);
  }

  /** Gets value of Description child element for Screen element. */
  public String getDescription() {
    return getCharacterData(getChildElement("Description"));
  }

  /** Sets value for Screen element's Description child element. */
  public void setDescription(String value) {
    setCharacterData(value, getChildElement("Description"));
  }

  /** Gets Name attribute of the Screen element. */
  public String getName() { return getAttribute("Name"); }

  /** Sets Name attribute for the Screen element. */
  public void setName(String value) { setAttribute("Name", value); }

  /** Gets a list of plates belonging to (referencing) this screen. */
  public List getPlateList() {
    return createReferralNodes(PlateNode.class, "Plate");
  }

  /** Gets the number of plates belonging to (referencing) this screen. */
  public int countPlateList() { return getSize(getReferrals("Plate")); }

  /** Gets a list of PlateScreen elements referencing this Screen node. */
  public List getPlateScreenList() {
    return createAttrReferralNodes(PlateScreenNode.class,
      "PlateScreen", "Screen");
  }

  /** Gets the number of PlateScreen elements referencing this Screen node. */
  public int countPlateScreenList() {
    return getSize(getAttrReferrals("PlateScreen", "Screen"));
  }

}
