/*
 * loci.ome.xml.TrajectoryEntryNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Trajectory;
import org.openmicroscopy.ds.st.TrajectoryEntry;
import org.w3c.dom.Element;

/**
 * TrajectoryEntryNode is the node corresponding to the
 * "TrajectoryEntry" XML element.
 */
public class TrajectoryEntryNode extends AttributeNode
  implements TrajectoryEntry
{

  // -- Constructor --

  /**
   * Constructs a TrajectoryEntry node with the given associated DOM element.
   */
  public TrajectoryEntryNode(Element element) { super(element); }


  // -- TrajectoryEntry API methods --

  /** Gets Velocity attribute of the TrajectoryEntry element. */
  public Float getVelocity() { return getFloatAttribute("Velocity"); }

  /** Sets Velocity attribute for the TrajectoryEntry element. */
  public void setVelocity(Float value) {
    setFloatAttribute("Velocity", value);
  }

  /** Gets Distance attribute of the TrajectoryEntry element. */
  public Float getDistance() { return getFloatAttribute("Distance"); }

  /** Sets Distance attribute for the TrajectoryEntry element. */
  public void setDistance(Float value) {
    setFloatAttribute("Distance", value);
  }

  /** Gets DeltaZ attribute of the TrajectoryEntry element. */
  public Float getDeltaZ() { return getFloatAttribute("DeltaZ"); }

  /** Sets DeltaZ attribute for the TrajectoryEntry element. */
  public void setDeltaZ(Float value) { setFloatAttribute("DeltaZ", value); }

  /** Gets DeltaY attribute of the TrajectoryEntry element. */
  public Float getDeltaY() { return getFloatAttribute("DeltaY"); }

  /** Sets DeltaY attribute for the TrajectoryEntry element. */
  public void setDeltaY(Float value) { setFloatAttribute("DeltaY", value); }

  /** Gets DeltaX attribute of the TrajectoryEntry element. */
  public Float getDeltaX() { return getFloatAttribute("DeltaX"); }

  /** Sets DeltaX attribute for the TrajectoryEntry element. */
  public void setDeltaX(Float value) { setFloatAttribute("DeltaX", value); }

  /** Gets Order attribute of the TrajectoryEntry element. */
  public Integer getOrder() { return getIntegerAttribute("Order"); }

  /** Sets Order attribute for the TrajectoryEntry element. */
  public void setOrder(Integer value) { setIntegerAttribute("Order", value); }

  /**
   * Gets Trajectory referenced by Trajectory attribute of the
   * TrajectoryEntry element.
   */
  public Trajectory getTrajectory() {
    return (Trajectory)
      createReferencedNode(TrajectoryNode.class, "Trajectory", "Trajectory");
  }

  /**
   * Sets Trajectory referenced by Trajectory attribute of the
   * TrajectoryEntry element.
   */
  public void setTrajectory(Trajectory value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Trajectory", "Trajectory");
  }

}
