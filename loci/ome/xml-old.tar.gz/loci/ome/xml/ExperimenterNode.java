/*
 * loci.ome.xml.ExperimenterNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Experimenter;
import org.openmicroscopy.ds.st.Group;
import org.w3c.dom.Element;

/**
 * ExperimenterNode is the node corresponding
 * to the "Experimenter" XML element.
 */
public class ExperimenterNode extends AttributeNode implements Experimenter {

  // -- Constructor --

  /** Constructs a Experimenter node with the given associated DOM element. */
  public ExperimenterNode(Element element) { super(element); }


  // -- ExperimenterNode API methods --

  /** Gets value of OMEName child element for Experimenter element. */
  public String getOMEName() {
    return getCharacterData(getChildElement("OMEName"));
  }

  /** Sets value of OMEName child element for Experimenter element. */
  public void setOMEName(String value) {
    setCharacterData(value, getChildElement("OMEName"));
  }

  /**
   * Gets a list of Group nodes corresponding to the
   * Group elements referenced by the Experimenter node.
   */
  public List getGroups() {
    return createReferencedNodes(GroupNode.class, "Group");
  }

  /** Gets the number of Group elements referenced by the Experimenter node. */
  public int countGroups() { return getSize(getChildElements("GroupRef")); }


  // -- Experimenter API methods --

  /**
   * Gets a Group node representing the Experimenter element's
   * first referenced Group element.
   */
  public Group getGroup() {
    return (Group) createReferencedNode(GroupNode.class, "Group");
  }

  /**
   * Sets the Experimenter element's first referenced Group element
   * to match the one associated with the given Group node.
   */
  public void setGroup(Group value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Group");
  }

  /** Gets DataDirectory attribute of Experimenter ST element. */
  public String getDataDirectory() {
    Element customExperimenter = getChildElement("Experimenter",
      getChildElement("CustomAttributes", getAncestorElement("OME")));
    return getAttribute("DataDirectory", customExperimenter);
  }

  /** Sets DataDirectory attribute for Experimenter ST element. */
  public void setDataDirectory(String value) {
    Element customExperimenter = getChildElement("Experimenter",
      getChildElement("CustomAttributes", getAncestorElement("OME")));
    setAttribute("DataDirectory", value, customExperimenter);
  }

  /** Gets value of Institution child element for Experimenter element. */
  public String getInstitution() {
    return getCharacterData(getChildElement("Institution"));
  }

  /** Sets value of Institution child element for Experimenter element. */
  public void setInstitution(String value) {
    setCharacterData(value, getChildElement("Institution"));
  }

  /** Gets value of Email child element for Experimenter element. */
  public String getEmail() {
    return getCharacterData(getChildElement("Email"));
  }
  /** Sets value of Email child element for Experimenter element. */
  public void setEmail(String value) {
    setCharacterData(value, getChildElement("Email"));
  }

  /** Gets value of LastName child element for Experimenter element. */
  public String getLastName() {
    return getCharacterData(getChildElement("LastName"));
  }

  /** Sets value of LastName child element for Experimenter element. */
  public void setLastName(String value) {
    setCharacterData(value, getChildElement("LastName"));
  }

  /** Gets value of FirstName child element for Experimenter element. */
  public String getFirstName() {
    return getCharacterData(getChildElement("FirstName"));
  }

  /** Sets value of FirstName child element for Experimenter element. */
  public void setFirstName(String value) {
    setCharacterData(value, getChildElement("FirstName"));
  }

  /**
   * Gets a list of DatasetAnnotation elements
   * referencing this Experimenter node.
   */
  public List getDatasetAnnotationList() {
    return createAttrReferralNodes(DatasetAnnotationNode.class,
      "DatasetAnnotation", "Experimenter");
  }

  /**
   * Gets the number of DatasetAnnotation elements
   * referencing this Experimenter node.
   */
  public int countDatasetAnnotationList() {
    return getSize(getAttrReferrals("DatasetAnnotation", "Experimenter"));
  }

  /**
   * Gets a list of experiments belonging to (referencing) this experimenter.
   */
  public List getExperimentList() {
    return createReferralNodes(ExperimentNode.class, "Experiment");
  }

  /**
   * Gets the number of experiments belonging to
   * (referencing) this experimenter.
   */
  public int countExperimentList() {
    return getSize(getReferrals("Experiment"));
  }

  /**
   * Gets a list of ExperimenterGroup elements
   * referencing this Experimenter node.
   */
  public List getExperimenterGroupList() {
    return createAttrReferralNodes(ExperimenterGroupNode.class,
      "ExperimenterGroup", "Experimenter");
  }

  /**
   * Gets the number of ExperimenterGroup elements
   * referencing this Experimenter node.
   */
  public int countExperimenterGroupList() {
    return getSize(getAttrReferrals("ExperimenterGroup", "Experimenter"));
  }

  /**
   * Gets a list of Group elements referencing this
   * Experimenter node via a Contact child element.
   */
  public List getGroupListByContact() {
    return createReferralNodes(GroupNode.class, "Group", "Contact");
  }

  /**
   * Gets the number of Group elements referencing this
   * Experimenter node via a Contact child element.
   */
  public int countGroupListByContact() {
    return getSize(getReferrals("Group", "Contact"));
  }

  /**
   * Gets a list of Group elements referencing this
   * Experimenter node via a Leader child element.
   */
  public List getGroupListByLeader() {
    return createReferralNodes(GroupNode.class, "Group", "Leader");
  }

  /**
   * Gets the number of Group elements referencing this
   * Experimenter node via a Leader child element.
   */
  public int countGroupListByLeader() {
    return getSize(getReferrals("Group", "Leader"));
  }

  /**
   * Gets a list of ImageAnnotation elements
   * referencing this Experimenter node.
   */
  public List getImageAnnotationList() {
    return createAttrReferralNodes(ImageAnnotationNode.class,
      "ImageAnnotation", "Experimenter");
  }

  /**
   * Gets the number of ImageAnnotation elements
   * referencing this Experimenter node.
   */
  public int countImageAnnotationList() {
    return getSize(getAttrReferrals("ImageAnnotation", "Experimenter"));
  }

  /**
   * Gets a list of RenderingSettings elements
   * referencing this Experimenter node.
   */
  public List getRenderingSettingsList() {
    return createAttrReferralNodes(RenderingSettingsNode.class,
      "RenderingSettings", "Experimenter");
  }

  /**
   * Gets the number of RenderingSettings elements
   * referencing this Experimenter node.
   */
  public int countRenderingSettingsList() {
    return getSize(getAttrReferrals("RenderingSettings", "Experimenter"));
  }

}
