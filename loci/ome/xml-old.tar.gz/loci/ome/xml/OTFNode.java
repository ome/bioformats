/*
 * loci.ome.xml.OTFNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.*;
import org.w3c.dom.Element;

/** OTFNode is the node corresponding to the "OTF" XML element. */
public class OTFNode extends AttributeNode implements OTF {

  // -- Constructor --

  /** Constructs a OTF node with the given associated DOM element. */
  public OTFNode(Element element) { super(element); }


  // -- OTF API methods --

  /** Gets the Instrument element ancestor to this OTF element. */
  public Instrument getInstrument() {
    return (Instrument) createAncestorNode(InstrumentNode.class, "Instrument");
  }

  /** Sets the Instrument element ancestor for this OTF element. */
  public void setInstrument(Instrument value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets OpticalAxisAverage attribute of the OTF element. */
  public Boolean isOpticalAxisAverage() {
    return getBooleanAttribute("OpticalAxisAverage");
  }

  /** Sets OpticalAxisAverage attribute of the OTF element. */
  public void setOpticalAxisAverage(Boolean value) {
    setBooleanAttribute("OpticalAxisAverage", value);
  }

  /** Gets Path attribute of OTF ST element. */
  public String getPath() {
    Element customOTF = getChildElement("OTF",
      getChildElement("CustomAttributes", getAncestorElement("OME")));
    return getAttribute("Path", customOTF);
  }

  /** Sets Path attribute for OTF ST element. */
  public void setPath(String value) {
    Element customOTF = getChildElement("OTF",
      getChildElement("CustomAttributes", getAncestorElement("OME")));
    setAttribute("Path", value, customOTF);
  }

  /**
   * Gets Repository referenced by Repository attribute
   * of the OTF ST element.
   */
  public Repository getRepository() {
    Element customOTF = getChildElement("OTF",
      getChildElement("CustomAttributes", getAncestorElement("OME")));
    String repositoryID = customOTF.getAttribute("Repository");
    return (Repository) createNode(RepositoryNode.class,
      findElement("Repository", repositoryID));
  }

  /**
   * Sets Repository referenced by Repository attribute
   * of the OTF ST element.
   */
  public void setRepository(Repository value) {
    if (!(value instanceof OMEXMLNode)) return;
    Element customOTF = getChildElement("OTF",
      getChildElement("CustomAttributes", getAncestorElement("OME")));
    String repositoryID = ((OMEXMLNode) value).getLSID();
    setAttribute("Repository", repositoryID, customOTF);
  }

  /** Gets PixelType attribute of the OTF element. */
  public String getPixelType() { return getAttribute("PixelType"); }

  /** Sets PixelType attribute of the OTF element. */
  public void setPixelType(String value) { setAttribute("PixelType", value); }

  /** Gets SizeY attribute of the OTF element. */
  public Integer getSizeY() { return getIntegerAttribute("SizeY"); }

  /** Sets SizeY attribute of the OTF element. */
  public void setSizeY(Integer value) { setIntegerAttribute("SizeY", value); }

  /** Gets SizeX attribute of the OTF element. */
  public Integer getSizeX() { return getIntegerAttribute("SizeX"); }

  /** Sets SizeX attribute of the OTF element. */
  public void setSizeX(Integer value) { setIntegerAttribute("SizeX", value); }

  /**
   * Gets a Filter node representing the
   * OTF element's referenced Filter element.
   */
  public Filter getFilter() {
    return (Filter) createReferencedNode(FilterNode.class, "Filter");
  }

  /**
   * Sets the OTF element's referenced Filter element to match
   * the one associated with the given Filter node.
   */
  public void setFilter(Filter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Filter");
  }

  /**
   * Gets an Objective node representing the
   * OTF element's referenced Objective element.
   */
  public Objective getObjective() {
    return (Objective) createReferencedNode(ObjectiveNode.class, "Objective");
  }

  /**
   * Sets the OTF element's referenced Objective element to match
   * the one associated with the given Objective node.
   */
  public void setObjective(Objective value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Objective");
  }

  /** Gets a list of logical channels referencing this OTF. */
  public List getLogicalChannelList() {
    return createReferralNodes(LogicalChannelNode.class, "ChannelInfo");
  }

  /** Gets the number of logical channels referencing this OTF. */
  public int countLogicalChannelList() {
    return getSize(getReferrals("ChannelInfo"));
  }

}
