/*
 * loci.ome.xml.ThresholdNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Threshold;
import org.w3c.dom.Element;

/** ThresholdNode is the node corresponding to the "Threshold" XML element. */
public class ThresholdNode extends AttributeNode implements Threshold {

  // -- Constructor --

  /** Constructs a Threshold node with the given associated DOM element. */
  public ThresholdNode(Element element) { super(element); }


  // -- Threshold API methods --

  /** Gets Threshold of the Threshold element. */
  public Integer getThreshold() { return getIntegerAttribute("Threshold"); }

  /** Sets Threshold for the Threshold element. */
  public void setThreshold(Integer value) {
    setIntegerAttribute("Threshold", value);
  }

}
