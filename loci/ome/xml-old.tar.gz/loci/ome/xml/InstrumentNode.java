/*
 * loci.ome.xml.InstrumentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Instrument;
import org.w3c.dom.Element;

/**
 * InstrumentNode is the node corresponding to the "Instrument" XML element.
 */
public class InstrumentNode extends AttributeNode implements Instrument {

  // -- Constructor --

  /** Constructs a Instrument node with the given associated DOM element. */
  public InstrumentNode(Element element) { super(element); }


  // -- Instrument API methods --

  /** Gets the Microscope child element's Type attribute value. */
  public String getType() {
    return getAttribute("Type", getChildElement("Microscope"));
  }

  /** Sets the Microscope child element's Type attribute value. */
  public void setType(String value) {
    setAttribute("Type", value, getChildElement("Microscope"));
  }

  /** Gets the Microscope child element's SerialNumber attribute value. */
  public String getSerialNumber() {
    return getAttribute("SerialNumber", getChildElement("Microscope"));
  }

  /** Sets the Microscope child element's SerialNumber attribute value. */
  public void setSerialNumber(String value) {
    setAttribute("SerialNumber", value, getChildElement("Microscope"));
  }

  /** Gets the Microscope child element's Model attribute value. */
  public String getModel() {
    return getAttribute("Model", getChildElement("Microscope"));
  }

  /** Sets the Microscope child element's Model attribute value. */
  public void setModel(String value) {
    setAttribute("Model", value, getChildElement("Microscope"));
  }

  /** Gets the Microscope child element's Manufacturer attribute value. */
  public String getManufacturer() {
    return getAttribute("Manufacturer", getChildElement("Microscope"));
  }

  /** Sets the Microscope child element's Manufacturer attribute value. */
  public void setManufacturer(String value) {
    setAttribute("Manufacturer", value, getChildElement("Microscope"));
  }

  /** Gets nodes corresponding to Detector child elements. */
  public List getDetectorList() {
    return createChildNodes(DetectorNode.class, "Detector");
  }

  /** Gets the number of Detector child elements. */
  public int countDetectorList() {
    return getSize(getChildElements("Detector"));
  }

  /** Gets nodes corresponding to Filter child elements. */
  public List getFilterList() {
    return createChildNodes(FilterNode.class, "Filter");
  }

  /** Gets the number of Filter child elements. */
  public int countFilterList() { return getSize(getChildElements("Filter")); }

  /**
   * Gets a list of ImageInstrument elements
   * referencing this Instrument node.
   */
  public List getImageInstrumentList() {
    return createAttrReferralNodes(ImageInstrumentNode.class,
      "ImageInstrument", "Instrument");
  }

  /**
   * Gets the number of ImageInstrument elements
   * referencing this Instrument node.
   */
  public int countImageInstrumentList() {
    return getSize(getAttrReferrals("ImageInstrument", "Instrument"));
  }

  /** Gets nodes corresponding to LightSource child elements. */
  public List getLightSourceList() {
    return createChildNodes(LightSourceNode.class, "LightSource");
  }

  /** Gets the number of LightSource child elements. */
  public int countLightSourceList() {
    return getSize(getChildElements("LightSource"));
  }

  /** Gets nodes corresponding to OTF child elements. */
  public List getOTFList() {
    return createChildNodes(OTFNode.class, "OTF");
  }

  /** Gets the number of OTF child elements. */
  public int countOTFList() { return getSize(getChildElements("OTF")); }

  /** Gets nodes corresponding to Objective child elements. */
  public List getObjectiveList() {
    return createChildNodes(ObjectiveNode.class, "Objective");
  }

  /** Gets the number of Objective child elements. */
  public int countObjectiveList() {
    return getSize(getChildElements("Objective"));
  }

}
