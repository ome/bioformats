/*
 * loci.ome.xml.FilterNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Filter;
import org.openmicroscopy.ds.st.Instrument;
import org.w3c.dom.Element;

/** FilterNode is the node corresponding to the "Filter" XML element. */
public class FilterNode extends AttributeNode implements Filter {

  // -- Constructor --

  /** Constructs a Filter node with the given associated DOM element. */
  public FilterNode(Element element) { super(element); }


  // -- Filter API methods --

  /** Gets the Instrument element ancestor to this Filter element. */
  public Instrument getInstrument() {
    return (Instrument) createAncestorNode(InstrumentNode.class, "Instrument");
  }

  /** Sets the Instrument element ancestor for this Filter element. */
  public void setInstrument(Instrument value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets nodes corresponding to Dichroic child elements. */
  public List getDichroicList() {
    return createChildNodes(DichroicNode.class, "Dichroic");
  }

  /** Gets the number of Dichroic child elements. */
  public int countDichroicList() {
    return getSize(getChildElements("Dichroic"));
  }

  /** Gets nodes corresponding to EmFilter child elements. */
  public List getEmissionFilterList() {
    return createChildNodes(EmissionFilterNode.class, "EmFilter");
  }

  /** Gets the number of EmFilter child elements. */
  public int countEmissionFilterList() {
    return getSize(getChildElements("EmFilter"));
  }

  /** Gets nodes corresponding to ExFilter child elements. */
  public List getExcitationFilterList() {
    return createChildNodes(ExcitationFilterNode.class, "ExFilter");
  }

  /** Gets the number of ExFilter child elements. */
  public int countExcitationFilterList() {
    return getSize(getChildElements("ExFilter"));
  }

  /** Gets nodes corresponding to FilterSet child elements. */
  public List getFilterSetList() {
    return createChildNodes(FilterSetNode.class, "FilterSet");
  }

  /** Gets the number of FilterSet child elements. */
  public int countFilterSetList() {
    return getSize(getChildElements("FilterSet"));
  }

  /**
   * Gets a list of logical channels (ChannelInfo elements)
   * using (referencing) this filter.
   */
  public List getLogicalChannelList() {
    return createReferralNodes(LogicalChannelNode.class, "ChannelInfo");
  }

  /**
   * Gets the number of logical channels (ChannelInfo elements)
   * using (referencing) this filter.
   */
  public int countLogicalChannelList() {
    return getSize(getReferrals("ChannelInfo"));
  }

  /** Gets a list of OTFs using (referencing) this filter. */
  public List getOTFList() {
    return createReferralNodes(OTFNode.class, "OTF");
  }

  /** Gets the number of OTFs using (referencing) this filter. */
  public int countOTFList() { return getSize(getReferrals("OTF")); }

}
