/*
 * loci.ome.xml.GroupNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Experimenter;
import org.openmicroscopy.ds.st.Group;
import org.w3c.dom.Element;

/** GroupNode is the node corresponding to the "Group" XML element. */
public class GroupNode extends AttributeNode implements Group {

  // -- Constructor --

  /** Constructs a Group node with the given associated DOM element. */
  public GroupNode(Element element) { super(element); }


  // -- Group API methods --

  /**
   * Gets an Experimenter node representing the
   * Group element's referenced Contact (a Group element).
   */
  public Experimenter getContact() {
    return (Experimenter) createReferencedNode(Experimenter.class, "Contact");
  }

  /**
   * Sets the Group element's referenced Contact (a Group element)
   * to match the one associated with the given Experimenter node.
   */
  public void setContact(Experimenter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Contact");
  }

  /**
   * Gets an Experimenter node representing the
   * Group element's referenced Leader (a Group element).
   */
  public Experimenter getLeader() {
    return (Experimenter) createReferencedNode(Experimenter.class, "Leader");
  }

  /**
   * Sets the Group element's referenced Leader (a Group element)
   * to match the one associated with the given Experimenter node.
   */
  public void setLeader(Experimenter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Leader");
  }

  /** Gets Name attribute of the Group element. */
  public String getName() { return getAttribute("Name"); }

  /** Sets Name attribute for the Group element. */
  public void setName(String value) { setAttribute("Name", value); }

  /** Gets a list of experimenters belonging to (referencing) this group. */
  public List getExperimenterList() {
    return createReferralNodes(ExperimenterNode.class, "Experimenter");
  }

  /**
   * Gets the number of experimenters belonging to (referencing) this group.
   */
  public int countExperimenterList() {
    return getSize(getReferrals("Experimenter"));
  }

  /** Gets a list of ExperimenterGroup elements referencing this Group node. */
  public List getExperimenterGroupList() {
    return createAttrReferralNodes(ExperimenterGroupNode.class,
      "ExperimenterGroup", "Group");
  }

  /**
   * Gets the number of ExperimenterGroup elements referencing this Group node.
   */
  public int countExperimenterGroupList() {
    return getSize(getAttrReferrals("ExperimenterGroup", "Group"));
  }

  /** Gets a list of ImageGroup elements referencing this Group node. */
  public List getImageGroupList() {
    return createAttrReferralNodes(ImageGroupNode.class,
      "ImageGroup", "Group");
  }

  /** Gets the number of ImageGroup elements referencing this Group node. */
  public int countImageGroupList() {
    return getSize(getAttrReferrals("ImageGroup", "Group"));
  }

}
