/*
 * loci.ome.xml.DisplayOptionsNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.*;
import org.w3c.dom.Element;

/**
 * DisplayOptionsNode is the node corresponding to the
 * "DisplayOptions" XML element.
 */
public class DisplayOptionsNode extends AttributeNode
  implements DisplayOptions
{

  // -- Constructor --

  /**
   * Constructs a DisplayOptions node with the given associated DOM element.
   */
  public DisplayOptionsNode(Element element) { super(element); }


  // -- DisplayOptions API methods --

  /** Gets the Time child element's TStop attribute value. */
  public Integer getTStop() {
    return getIntegerAttribute("TStop", getChildElement("Time"));
  }

  /** Sets the Time child element's TStop attribute value. */
  public void setTStop(Integer value) {
    setIntegerAttribute("TStop", value, getChildElement("Time"));
  }

  /** Gets the Time child element's TStart attribute value. */
  public Integer getTStart() {
    return getIntegerAttribute("TStart", getChildElement("Time"));
  }

  /** Sets the Time child element's TStart attribute value. */
  public void setTStart(Integer value) {
    setIntegerAttribute("TStart", value, getChildElement("Time"));
  }

  /** Gets the Projection child element's ZStop attribute value. */
  public Integer getZStop() {
    return getIntegerAttribute("ZStop", getChildElement("Projection"));
  }

  /** Sets the Projection child element's ZStop attribute value. */
  public void setZStop(Integer value) {
    setIntegerAttribute("ZStop", value, getChildElement("Projection"));
  }

  /** Gets the Projection child element's ZStart attribute value. */
  public Integer getZStart() {
    return getIntegerAttribute("ZStart", getChildElement("Projection"));
  }

  /** Sets the Projection child element's ZStart attribute value. */
  public void setZStart(Integer value) {
    setIntegerAttribute("ZStart", value, getChildElement("Projection"));
  }

  /** Gets the GreyChannel child element's ColorMap attribute value. */
  public String getColorMap() {
    return getAttribute("ColorMap", getChildElement("GreyChannel"));
  }

  /** Sets the GreyChannel child element's ColorMap attribute value. */
  public void setColorMap(String value) {
    setAttribute("ColorMap", value, getChildElement("GreyChannel"));
  }

  /** Gets node corresponding to GreyChannel child element. */
  public DisplayChannel getGreyChannel() {
    return (DisplayChannel)
      createChildNode(DisplayChannelNode.class, "GreyChannel");
  }

  /**
   * Sets the DisplayOptions element's GreyChannel child element to match
   * the one associated with the given DisplayChannel node.
   */
  public void setGreyChannel(DisplayChannel value) {
    if (!(value instanceof OMEXMLNode)) return;
    setChildNode((OMEXMLNode) value, "GreyChannel");
  }

  /** Gets whether the Display attribute value is "RGB" or "Grey." */
  public Boolean isDisplayRGB() {
    String value = getAttribute("Display");
    return value == null ? null : new Boolean(value.equals("RGB"));
  }

  /** Sets whether the Display attribute value is "RGB" or "Grey." */
  public void setDisplayRGB(Boolean value) {
    boolean rgb = value != null && value.equals("RGB");
    setAttribute("Display", rgb ? "RGB" : "Grey");
  }

  /** Gets the BlueChannel child element's isOn attribute value. */
  public Boolean isBlueChannelOn() {
    return getBooleanAttribute("isOn", getChildElement("BlueChannel"));
  }
  /** Sets the BlueChannel child element's isOn attribute value. */
  public void setBlueChannelOn(Boolean value) {
    setBooleanAttribute("isOn", value, getChildElement("BlueChannel"));
  }

  /** Gets node corresponding to BlueChannel child element. */
  public DisplayChannel getBlueChannel() {
    return (DisplayChannel)
      createChildNode(DisplayChannelNode.class, "BlueChannel");
  }

  /**
   * Sets the DisplayOptions element's BlueChannel child element to match
   * the one associated with the given DisplayChannel node.
   */
  public void setBlueChannel(DisplayChannel value) {
    if (!(value instanceof OMEXMLNode)) return;
    setChildNode((OMEXMLNode) value, "BlueChannel");
  }

  /** Gets the GreenChannel child element's isOn attribute value. */
  public Boolean isGreenChannelOn() {
    return getBooleanAttribute("isOn", getChildElement("GreenChannel"));
  }

  /** Sets the GreenChannel child element's isOn attribute value. */
  public void setGreenChannelOn(Boolean value) {
    setBooleanAttribute("isOn", value, getChildElement("GreenChannel"));
  }

  /** Gets node corresponding to GreenChannel child element. */
  public DisplayChannel getGreenChannel() {
    return (DisplayChannel)
      createChildNode(DisplayChannelNode.class, "GreenChannel");
  }

  /**
   * Sets the DisplayOptions element's GreenChannel child element to match
   * the one associated with the given DisplayChannel node.
   */
  public void setGreenChannel(DisplayChannel value) {
    if (!(value instanceof OMEXMLNode)) return;
    setChildNode((OMEXMLNode) value, "GreenChannel");
  }

  /** Gets the RedChannel child element's isOn attribute value. */
  public Boolean isRedChannelOn() {
    return getBooleanAttribute("isOn", getChildElement("RedChannel"));
  }

  /** Sets the RedChannel child element's isOn attribute value. */
  public void setRedChannelOn(Boolean value) {
    setBooleanAttribute("isOn", value, getChildElement("RedChannel"));
  }

  /** Gets node corresponding to RedChannel child element. */
  public DisplayChannel getRedChannel() {
    return (DisplayChannel)
      createChildNode(DisplayChannelNode.class, "RedChannel");
  }

  /**
   * Sets the DisplayOptions element's RedChannel child element to match
   * the one associated with the given DisplayChannel node.
   */
  public void setRedChannel(DisplayChannel value) {
    if (!(value instanceof OMEXMLNode)) return;
    setChildNode((OMEXMLNode) value, "RedChannel");
  }

  /** Gets Zoom attribute of the DisplayOptions element. */
  public Float getZoom() { return getFloatAttribute("Zoom"); }

  /** Sets Zoom attribute of the DisplayOptions element. */
  public void setZoom(Float value) { setFloatAttribute("Zoom", value); }

  /** Gets the Pixels element ancestor to this DisplayOptions element. */
  public Pixels getPixels() {
    return (Pixels) createAncestorNode(PixelsNode.class, "Pixels");
  }

  /** Sets the Pixels element ancestor for this DisplayOptions element. */
  public void setPixels(Pixels value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets nodes corresponding to ROI child elements. */
  public List getDisplayROIList() {
    return createChildNodes(DisplayROINode.class, "ROI");
  }

  /** Gets the number of ROI child elements. */
  public int countDisplayROIList() { return getSize(getChildElements("ROI")); }

}
