/*
 * loci.ome.xml.DetectorNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Detector;
import org.openmicroscopy.ds.st.Instrument;
import org.w3c.dom.Element;

/** DetectorNode is the node corresponding to the "Detector" XML element. */
public class DetectorNode extends AttributeNode implements Detector {

  // -- Constructor --

  /** Constructs a Detector node with the given associated DOM element. */
  public DetectorNode(Element element) { super(element); }


  // -- Detector API methods --

  /** Gets the Instrument element ancestor to this Detector element. */
  public Instrument getInstrument() {
    return (Instrument) createAncestorNode(InstrumentNode.class, "Instrument");
  }

  /** Sets the Instrument element ancestor for this Detector element. */
  public void setInstrument(Instrument value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets Offset attribute of the Detector element. */
  public Float getOffset() { return getFloatAttribute("Offset"); }

  /** Sets Offset attribute of the Detector element. */
  public void setOffset(Float value) { setFloatAttribute("Offset", value); }

  /** Gets Voltage attribute of the Detector element. */
  public Float getVoltage() { return getFloatAttribute("Voltage"); }

  /** Sets Voltage attribute of the Detector element. */
  public void setVoltage(Float value) { setFloatAttribute("Voltage", value); }

  /** Gets Gain attribute of the Detector element. */
  public Float getGain() { return getFloatAttribute("Gain"); }

  /** Sets Gain attribute of the Detector element. */
  public void setGain(Float value) { setFloatAttribute("Gain", value); }

  /** Gets Type attribute of the Detector element. */
  public String getType() { return getAttribute("Type"); }

  /** Sets Type attribute for the Detector element. */
  public void setType(String value) { setAttribute("Type", value); }

  /** Gets SerialNumber attribute of the Detector element. */
  public String getSerialNumber() { return getAttribute("SerialNumber"); }

  /** Sets SerialNumber attribute of the Detector element. */
  public void setSerialNumber(String value) {
    setAttribute("SerialNumber", value);
  }

  /** Gets Model attribute of the Detector element. */
  public String getModel() { return getAttribute("Model"); }

  /** Sets Model attribute of the Detector element. */
  public void setModel(String value) { setAttribute("Model", value); }

  /** Gets Manufacturer attribute of the Detector element. */
  public String getManufacturer() { return getAttribute("Manufacturer"); }

  /** Sets Manufacturer attribute of the Detector element. */
  public void setManufacturer(String value) {
    setAttribute("Manufacturer", value);
  }

  /**
   * Gets a list of logical channels (ChannelInfo elements)
   * using (referencing) this detector.
   */
  public List getLogicalChannelList() {
    return createReferralNodes(LogicalChannelNode.class, "ChannelInfo");
  }

  /**
   * Gets the number of logical channels (ChannelInfo elements)
   * using (referencing) this detector.
   */
  public int countLogicalChannelList() {
    return getSize(getReferrals("ChannelInfo"));
  }

}
