/*
 * loci.ome.xml.OriginalFileNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.OriginalFile;
import org.openmicroscopy.ds.st.Repository;
import org.w3c.dom.Element;

/**
 * OriginalFileNode is the node corresponding to the
 * "OriginalFile" XML element.
 */
public class OriginalFileNode extends AttributeNode implements OriginalFile {

  // -- Constructor --

  /** Constructs a OriginalFile node with the given associated DOM element. */
  public OriginalFileNode(Element element) { super(element); }


  // -- OriginalFile API methods --

  /** Gets Format attribute of the OriginalFile element. */
  public String getFormat() { return getAttribute("Format"); }

  /** Sets Format attribute for the OriginalFile element. */
  public void setFormat(String value) { setAttribute("Format", value); }

  /** Gets SHA1 attribute of the OriginalFile element. */
  public String getSHA1() { return getAttribute("SHA1"); }

  /** Sets SHA1 attribute for the OriginalFile element. */
  public void setSHA1(String value) { setAttribute("SHA1", value); }

  /** Gets FileID attribute of the OriginalFile element. */
  public Long getFileID() { return getLongAttribute("FileID"); }

  /** Sets FileID attribute for the OriginalFile element. */
  public void setFileID(Long value) { setLongAttribute("FileID", value); }

  /** Gets Path attribute of the OriginalFile element. */
  public String getPath() { return getAttribute("Path"); }

  /** Sets Path attribute for the OriginalFile element. */
  public void setPath(String value) { setAttribute("Path", value); }

  /**
   * Gets Repository referenced by Repository attribute
   * of the OriginalFile element.
   */
  public Repository getRepository() {
    return (Repository)
      createReferencedNode(RepositoryNode.class, "Repository", "Repository");
  }

  /**
   * Sets Repository referenced by Repository attribute
   * of the OriginalFile element.
   */
  public void setRepository(Repository value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Repository", "Repository");
  }

}
