/*
 * loci.ome.xml.LaserNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Laser;
import org.openmicroscopy.ds.st.LightSource;
import org.w3c.dom.Element;

/** LaserNode is the node corresponding to the "Laser" XML element. */
public class LaserNode extends AttributeNode implements Laser {

  // -- Constructor --

  /** Constructs a Laser node with the given associated DOM element. */
  public LaserNode(Element element) { super(element); }


  // -- Laser API methods --

  /**
   * Gets a LightSource node corresponding to the Laser element's
   * Pump child element (which references a LightSource element).
   */
  public LightSource getPump() {
    return (LightSource) createNode(LightSourceNode.class,
      findElement("LightSource", getAttribute("ID", getChildElement("Pump"))));
  }

  /**
   * Sets the Laser's Pump child element to match
   * the one associated with the given LightSource node.
   */
  public void setPump(LightSource value) {
    if (!(value instanceof OMEXMLNode)) return;
    setAttribute("ID", getAttribute("ID",
      ((OMEXMLNode) value).getDOMElement()), getChildElement("Pump"));
  }

  /** Gets the LightSource element ancestor to this Laser element. */
  public LightSource getLightSource() {
    return (LightSource)
      createAncestorNode(LightSourceNode.class, "LightSource");
  }

  /** Sets the LightSource element ancestor for this Laser element. */
  public void setLightSource(LightSource value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets Power attribute of the Laser element. */
  public Float getPower() { return getFloatAttribute("Power"); }

  /** Sets Power attribute for the Laser element. */
  public void setPower(Float value) { setFloatAttribute("Power", value); }

  /** Gets Pulse attribute of the Laser element. */
  public String getPulse() { return getAttribute("Pulse"); }

  /** Sets Pulse attribute for the Laser element. */
  public void setPulse(String value) { setAttribute("Pulse", value); }

  /** Gets Tunable attribute of the Laser element. */
  public Boolean isTunable() { return getBooleanAttribute("Tunable"); }

  /** Sets Tunable attribute for the Laser element. */
  public void setTunable(Boolean value) {
    setBooleanAttribute("Tunable", value);
  }

  /** Gets FrequencyDoubled attribute of the Laser element. */
  public Boolean isFrequencyDoubled() {
    return getBooleanAttribute("FrequencyDoubled");
  }

  /** Sets FrequencyDoubled attribute for the Laser element. */
  public void setFrequencyDoubled(Boolean value) {
    setBooleanAttribute("FrequencyDoubled", value);
  }

  /** Gets Wavelength attribute of the Laser element. */
  public Integer getWavelength() { return getIntegerAttribute("Wavelength"); }

  /** Sets Wavelength attribute for the Laser element. */
  public void setWavelength(Integer value) {
    setIntegerAttribute("Wavelength", value);
  }

  /** Gets Medium attribute of the Laser element. */
  public String getMedium() { return getAttribute("Medium"); }

  /** Sets Medium attribute for the Laser element. */
  public void setMedium(String value) { setAttribute("Medium", value); }

  /** Gets Type attribute of the Laser element. */
  public String getType() { return getAttribute("Type"); }

  /** Sets Type attribute for the Laser element. */
  public void setType(String value) { setAttribute("Type", value); }

}
