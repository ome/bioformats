/*
 * loci.ome.xml.PixelsNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Pixels;
import org.openmicroscopy.ds.st.Repository;
import org.w3c.dom.Element;

/** PixelsNode is the node corresponding to the "Pixels" XML element. */
public class PixelsNode extends AttributeNode implements Pixels {

  // -- Constructor --

  /** Constructs a Pixels node with the given associated DOM element. */
  public PixelsNode(Element element) { super(element); }


  // -- PixelsNode API methods --

  /** Gets DimensionOrder attribute of the Pixels element. */
  public String getDimensionOrder() { return getAttribute("DimensionOrder"); }

  /** Sets DimensionOrder attribute of the Pixels element. */
  public void setDimensionOrder(String value) {
    setAttribute("DimensionOrder", value);
  }

  /** Gets BigEndian attribute of the Pixels element. */
  public Boolean isBigEndian() { return getBooleanAttribute("BigEndian"); }

  /** Sets BigEndian attribute of the Pixels element. */
  public void setBigEndian(Boolean value) {
    setBooleanAttribute("BigEndian", value);
  }


  // -- Pixels API methods --

  /** Gets ImageServerID attribute of Pixels ST element. */
  public Long getImageServerID() {
    Element customPixels = getChildElement("Pixels",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    return getLongAttribute("ImageServerID", customPixels);
  }

  /** Sets ImageServerID attribute for Pixels ST element. */
  public void setImageServerID(Long value) {
    Element customPixels = getChildElement("Pixels",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    setLongAttribute("ImageServerID", value, customPixels);
  }

  /**
   * Gets Repository referenced by Repository attribute
   * of the Pixels ST element.
   */
  public Repository getRepository() {
    Element customPixels = getChildElement("Pixels",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    String repositoryID = customPixels.getAttribute("Repository");
    return (Repository) createNode(RepositoryNode.class,
      findElement("Repository", repositoryID));
  }

  /**
   * Sets Repository referenced by Repository attribute
   * of the Pixels ST element.
   */
  public void setRepository(Repository value) {
    if (!(value instanceof OMEXMLNode)) return;
    Element customPixels = getChildElement("Pixels",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    String repositoryID = ((OMEXMLNode) value).getLSID();
    setAttribute("Repository", repositoryID, customPixels);
  }

  /** Gets FileSHA1 attribute of Pixels ST element. */
  public String getFileSHA1() {
    Element customPixels = getChildElement("Pixels",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    return getAttribute("FileSHA1", customPixels);
  }

  /** Sets FileSHA1 attribute for Pixels ST element. */
  public void setFileSHA1(String value) {
    Element customPixels = getChildElement("Pixels",
      getChildElement("CustomAttributes", getAncestorElement("Image")));
    setAttribute("FileSHA1", value, customPixels);
  }

  /** Gets PixelType attribute of the Pixels element. */
  public String getPixelType() { return getAttribute("PixelType"); }

  /** Sets PixelType attribute of the Pixels element. */
  public void setPixelType(String value) { setAttribute("PixelType", value); }

  /** Gets SizeT attribute of the Pixels element. */
  public Integer getSizeT() { return getIntegerAttribute("SizeT"); }

  /** Sets SizeT attribute of the Pixels element. */
  public void setSizeT(Integer value) { setIntegerAttribute("SizeT", value); }

  /** Gets SizeC attribute of the Pixels element. */
  public Integer getSizeC() { return getIntegerAttribute("SizeC"); }

  /** Sets SizeC attribute of the Pixels element. */
  public void setSizeC(Integer value) { setIntegerAttribute("SizeC", value); }

  /** Gets SizeZ attribute of the Pixels element. */
  public Integer getSizeZ() { return getIntegerAttribute("SizeZ"); }

  /** Sets SizeZ attribute of the Pixels element. */
  public void setSizeZ(Integer value) { setIntegerAttribute("SizeZ", value); }

  /** Gets SizeY attribute of the Pixels element. */
  public Integer getSizeY() { return getIntegerAttribute("SizeY"); }

  /** Sets SizeY attribute of the Pixels element. */
  public void setSizeY(Integer value) { setIntegerAttribute("SizeY", value); }

  /** Gets SizeX attribute of the Pixels element. */
  public Integer getSizeX() { return getIntegerAttribute("SizeX"); }

  /** Sets SizeX attribute of the Pixels element. */
  public void setSizeX(Integer value) { setIntegerAttribute("SizeX", value); }

  /** Gets a list of DisplayOptions elements referencing this Pixels node. */
  public List getDisplayOptionsList() {
    return createNodes(DisplayOptionsNode.class, getAttrReferrals(
       "DisplayOptions", "Pixels", getLSID(), element.getOwnerDocument()));
  }

  /**
   * Gets the number of DisplayOptions elements referencing this Pixels node.
   */
  public int countDisplayOptionsList() {
    return getSize(getAttrReferrals("DisplayOptions",
      "Pixels", getLSID(), element.getOwnerDocument()));
  }

  /** Gets a list of ChannelComponent elements referencing this Pixels node. */
  public List getPixelChannelComponentList() {
    return createAttrReferralNodes(PixelChannelComponentNode.class,
      "ChannelComponent", "Pixels");
  }

  /**
   * Gets the number of ChannelComponent elements referencing this Pixels node.
   */
  public int countPixelChannelComponentList() {
    return getSize(getAttrReferrals("ChannelComponent", "Pixels"));
  }

}
