/*
 * loci.ome.xml.ImageExperimentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Experiment;
import org.openmicroscopy.ds.st.ImageExperiment;
import org.w3c.dom.Element;

/**
 * ImageExperimentNode is the node corresponding
 * to the "ImageExperiment" XML element.
 */
public class ImageExperimentNode extends AttributeNode
  implements ImageExperiment
{

  // -- Constructor --

  /**
   * Constructs an ImageExperiment node
   * with the given associated DOM element.
   */
  public ImageExperimentNode(Element element) { super(element); }


  // -- ImageExperiment API methods --

  /**
   * Gets Experiment referenced by Experiment attribute
   * of the ImageExperiment element.
   */
  public Experiment getExperiment() {
    return (Experiment) createReferencedNode(ExperimentNode.class,
      "Experiment", "Experiment");
  }

  /**
   * Sets Experiment referenced by Experiment attribute
   * of the ImageExperiment element.
   */
  public void setExperiment(Experiment value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Experiment", "Experiment");
  }

}
