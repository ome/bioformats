/*
 * loci.ome.xml.PlaneSum_iNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.PlaneSum_i;
import org.w3c.dom.Element;

/**
 * PlaneSum_iNode is the node corresponding to the "PlaneSum_i" XML element.
 */
public class PlaneSum_iNode extends AttributeNode implements PlaneSum_i {

  // -- Constructor --

  /** Constructs a PlaneSum_i node with the given associated DOM element. */
  public PlaneSum_iNode(Element element) { super(element); }


  // -- PlaneSum_i API methods --

  /** Gets Sum_i attribute of the PlaneSum_i element. */
  public Float getSum_i() { return getFloatAttribute("Sum_i"); }

  /** Sets Sum_i attribute for the PlaneSum_i element. */
  public void setSum_i(Float value) { setFloatAttribute("Sum_i", value); }

  /** Gets TheT attribute of the PlaneSum_i element. */
  public Integer getTheT() { return getIntegerAttribute("TheT"); }

  /** Sets TheT attribute for the PlaneSum_i element. */
  public void setTheT(Integer value) { setIntegerAttribute("TheT", value); }

  /** Gets TheC attribute of the PlaneSum_i element. */
  public Integer getTheC() { return getIntegerAttribute("TheC"); }

  /** Sets TheC attribute for the PlaneSum_i element. */
  public void setTheC(Integer value) { setIntegerAttribute("TheC", value); }

  /** Gets TheZ attribute of the PlaneSum_i element. */
  public Integer getTheZ() { return getIntegerAttribute("TheZ"); }

  /** Sets TheZ attribute for the PlaneSum_i element. */
  public void setTheZ(Integer value) { setIntegerAttribute("TheZ", value); }

}
