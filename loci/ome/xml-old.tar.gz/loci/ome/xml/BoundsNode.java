/*
 * loci.ome.xml.BoundsNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Bounds;
import org.w3c.dom.Element;

/** BoundsNode is the node corresponding to the "Bounds" XML element. */
public class BoundsNode extends AttributeNode implements Bounds {

  // -- Constructor --

  /** Constructs a Bounds node with the given associated DOM element. */
  public BoundsNode(Element element) { super(element); }


  // -- Bounds API methods --

  /** Gets Height attribute of the Bounds element. */
  public Integer getHeight() { return getIntegerAttribute("Height"); }

  /** Sets Height attribute of the Bounds element. */
  public void setHeight(Integer value) {
    setIntegerAttribute("Height", value);
  }

  /** Gets Width of the Bounds element. */
  public Integer getWidth() { return getIntegerAttribute("Width"); }

  /** Sets Width for the Bounds element. */
  public void setWidth(Integer value) { setIntegerAttribute("Width", value); }

  /** Gets Y of the Bounds element. */
  public Integer getY() { return getIntegerAttribute("Y"); }

  /** Sets Y for the Bounds element. */
  public void setY(Integer value) { setIntegerAttribute("Y", value); }

  /** Gets X of the Bounds element. */
  public Integer getX() { return getIntegerAttribute("X"); }

  /** Sets X for the Bounds element. */
  public void setX(Integer value) { setIntegerAttribute("X", value); }

}
