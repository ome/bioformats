/*
 * loci.ome.xml.ImageAnnotationNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Experimenter;
import org.openmicroscopy.ds.st.ImageAnnotation;
import org.w3c.dom.Element;

/**
 * ImageAnnotationNode is the node corresponding to the
 * "ImageAnnotation" XML element.
 */
public class ImageAnnotationNode extends AttributeNode
  implements ImageAnnotation
{

  // -- Constructor --

  /**
   * Constructs a ImageAnnotation node with the given associated DOM element.
   */
  public ImageAnnotationNode(Element element) { super(element); }


  // -- ImageAnnotation API methods --

  /** Gets Valid attribute of the ImageAnnotation element. */
  public Boolean isValid() { return getBooleanAttribute("Valid"); }

  /** Sets Valid attribute for the ImageAnnotation element. */
  public void setValid(Boolean value) { setBooleanAttribute("Valid", value); }

  /** Gets TheZ attribute of the ImageAnnotation element. */
  public Integer getTheZ() { return getIntegerAttribute("TheZ"); }

  /** Sets TheZ attribute for the ImageAnnotation element. */
  public void setTheZ(Integer value) { setIntegerAttribute("TheZ", value); }

  /** Gets TheT attribute of the ImageAnnotation element. */
  public Integer getTheT() { return getIntegerAttribute("TheT"); }

  /** Sets TheT attribute for the ImageAnnotation element. */
  public void setTheT(Integer value) { setIntegerAttribute("TheT", value); }

  /** Gets TheC attribute of the ImageAnnotation element. */
  public Integer getTheC() { return getIntegerAttribute("TheC"); }

  /** Sets TheC attribute for the ImageAnnotation element. */
  public void setTheC(Integer value) { setIntegerAttribute("TheC", value); }

  /** Gets Timestamp attribute of the ImageAnnotation element. */
  public Long getTimestamp() { return getLongAttribute("Timestamp"); }

  /** Sets Timestamp attribute for the ImageAnnotation element. */
  public void setTimestamp(Long value) {
    setLongAttribute("Timestamp", value);
  }

  /** Gets Content attribute of the ImageAnnotation element. */
  public String getContent() { return getAttribute("Content"); }

  /** Sets Content attribute for the ImageAnnotation element. */
  public void setContent(String value) { setAttribute("Content", value); }

  /**
   * Gets Experimenter referenced by Experimenter attribute
   * of the ImageAnnotation element.
   */
  public Experimenter getExperimenter() {
    return (Experimenter) createReferencedNode(ExperimenterNode.class,
      "Experimenter", "Experimenter");
  }

  /**
   * Sets Experimenter referenced by Experimenter attribute
   * of the ImageAnnotation element.
   */
  public void setExperimenter(Experimenter value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Experimenter", "Experimenter");
  }

}
