/*
 * loci.ome.xml.ExtentNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Extent;
import org.w3c.dom.Element;

/** ExtentNode is the node corresponding to the "Extent" XML element. */
public class ExtentNode extends AttributeNode implements Extent {

  // -- Constructor --

  /** Constructs a Extent node with the given associated DOM element. */
  public ExtentNode(Element element) { super(element); }


  // -- Extent API methods --

  /** Gets FormFactor of the Extent element. */
  public Float getFormFactor() { return getFloatAttribute("FormFactor"); }

  /** Sets FormFactor for the Extent element. */
  public void setFormFactor(Float value) {
    setFloatAttribute("FormFactor", value);
  }

  /** Gets Perimeter of the Extent element. */
  public Float getPerimeter() { return getFloatAttribute("Perimeter"); }

  /** Sets Perimeter for the Extent element. */
  public void setPerimeter(Float value) {
    setFloatAttribute("Perimeter", value);
  }

  /** Gets SurfaceArea of the Extent element. */
  public Float getSurfaceArea() { return getFloatAttribute("SurfaceArea"); }

  /** Sets SurfaceArea for the Extent element. */
  public void setSurfaceArea(Float value) {
    setFloatAttribute("SurfaceArea", value);
  }

  /** Gets Volume of the Extent element. */
  public Integer getVolume() { return getIntegerAttribute("Volume"); }

  /** Sets Volume for the Extent element. */
  public void setVolume(Integer value) {
    setIntegerAttribute("Volume", value);
  }

  /** Gets SigmaZ of the Extent element. */
  public Integer getSigmaZ() { return getIntegerAttribute("SigmaZ"); }

  /** Sets SigmaZ for the Extent element. */
  public void setSigmaZ(Integer value) {
    setIntegerAttribute("SigmaZ", value);
  }

  /** Gets SigmaY of the Extent element. */
  public Integer getSigmaY() { return getIntegerAttribute("SigmaY"); }

  /** Sets SigmaY for the Extent element. */
  public void setSigmaY(Integer value) {
    setIntegerAttribute("SigmaY", value);
  }

  /** Gets SigmaX of the Extent element. */
  public Integer getSigmaX() { return getIntegerAttribute("SigmaX"); }

  /** Sets SigmaX for the Extent element. */
  public void setSigmaX(Integer value) {
    setIntegerAttribute("SigmaX", value);
  }

  /** Gets MaxZ of the Extent element. */
  public Integer getMaxZ() { return getIntegerAttribute("MaxZ"); }

  /** Sets MaxZ for the Extent element. */
  public void setMaxZ(Integer value) { setIntegerAttribute("MaxZ", value); }

  /** Gets MaxY of the Extent element. */
  public Integer getMaxY() { return getIntegerAttribute("MaxY"); }

  /** Sets MaxY for the Extent element. */
  public void setMaxY(Integer value) { setIntegerAttribute("MaxY", value); }

  /** Gets MaxX of the Extent element. */
  public Integer getMaxX() { return getIntegerAttribute("MaxX"); }

  /** Sets MaxX for the Extent element. */
  public void setMaxX(Integer value) { setIntegerAttribute("MaxX", value); }

  /** Gets MinZ of the Extent element. */
  public Integer getMinZ() { return getIntegerAttribute("MinZ"); }

  /** Sets MinZ for the Extent element. */
  public void setMinZ(Integer value) { setIntegerAttribute("MinZ", value); }

  /** Gets MinY of the Extent element. */
  public Integer getMinY() { return getIntegerAttribute("MinY"); }

  /** Sets MinY for the Extent element. */
  public void setMinY(Integer value) { setIntegerAttribute("MinY", value); }

  /** Gets MinX of the Extent element. */
  public Integer getMinX() { return getIntegerAttribute("MinX"); }

  /** Sets MinX for the Extent element. */
  public void setMinX(Integer value) { setIntegerAttribute("MinX", value); }

}
