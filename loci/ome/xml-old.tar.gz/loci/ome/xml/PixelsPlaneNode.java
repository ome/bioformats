/*
 * loci.ome.xml.PixelsPlaneNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.PixelsPlane;
import org.openmicroscopy.ds.st.Repository;
import org.w3c.dom.Element;

/**
 * PixelsPlaneNode is the node corresponding to the "PixelsPlane" XML element.
 */
public class PixelsPlaneNode extends AttributeNode implements PixelsPlane {

  // -- Constructor --

  /** Constructs a PixelsPlane node with the given associated DOM element. */
  public PixelsPlaneNode(Element element) { super(element); }


  // -- PixelsPlane API methods --

  /** Gets SizeY attribute of the PixelsPlane element. */
  public Integer getSizeY() { return getIntegerAttribute("SizeY"); }

  /** Sets SizeY attribute for the PixelsPlane element. */
  public void setSizeY(Integer value) { setIntegerAttribute("SizeY", value); }

  /** Gets SizeX attribute of the PixelsPlane element. */
  public Integer getSizeX() { return getIntegerAttribute("SizeX"); }

  /** Sets SizeX attribute for the PixelsPlane element. */
  public void setSizeX(Integer value) { setIntegerAttribute("SizeX", value); }

  /** Gets FileSHA1 attribute of the PixelsPlane element. */
  public String getFileSHA1() { return getAttribute("FileSHA1"); }

  /** Sets FileSHA1 attribute for the PixelsPlane element. */
  public void setFileSHA1(String value) { setAttribute("FileSHA1", value); }

  /**
   * Gets Repository referenced by Repository attribute
   * of the PixelsPlane element.
   */
  public Repository getRepository() {
    return (Repository)
      createReferencedNode(RepositoryNode.class, "Repository", "Repository");
  }

  /**
   * Sets Repository referenced by Repository attribute
   * of the PixelsPlane element.
   */
  public void setRepository(Repository value) {
    if (!(value instanceof OMEXMLNode)) return;
    setReferencedNode((OMEXMLNode) value, "Repository", "Repository");
  }

  /** Gets PixelType attribute of the PixelsPlane element. */
  public String getPixelType() { return getAttribute("PixelType"); }

  /** Sets PixelType attribute for the PixelsPlane element. */
  public void setPixelType(String value) { setAttribute("PixelType", value); }

}
