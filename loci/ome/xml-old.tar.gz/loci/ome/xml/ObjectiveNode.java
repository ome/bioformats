/*
 * loci.ome.xml.ObjectiveNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Instrument;
import org.openmicroscopy.ds.st.Objective;
import org.w3c.dom.Element;

/** ObjectiveNode is the node corresponding to the "Objective" XML element. */
public class ObjectiveNode extends AttributeNode implements Objective {

  // -- Constructor --

  /** Constructs a Objective node with the given associated DOM element. */
  public ObjectiveNode(Element element) { super(element); }


  // -- Objective API methods --

  /** Gets the Instrument element ancestor to this Objective element. */
  public Instrument getInstrument() {
    return (Instrument) createAncestorNode(InstrumentNode.class, "Instrument");
  }

  /** Sets the Instrument element ancestor for this Objective element. */
  public void setInstrument(Instrument value) {
    if (!(value instanceof OMEXMLNode)) return;
    ((OMEXMLNode) value).getDOMElement().appendChild(element);
  }

  /** Gets value of Magnification child element for Objective element. */
  public Float getMagnification() {
    String s = getCharacterData(getChildElement("Magnification"));
    try { return new Float(s); }
    catch (NumberFormatException exc) { return null; }
  }

  /** Sets value of Magnification child element for Objective element. */
  public void setMagnification(Float value) {
    setCharacterData(value.toString(), getChildElement("Magnification"));
  }

  /** Gets value of LensNA child element for Objective element. */
  public Float getLensNA() {
    String s = getCharacterData(getChildElement("LensNA"));
    try { return new Float(s); }
    catch (NumberFormatException exc) { return null; }
  }

  /** Sets value of LensNA child element for Objective element. */
  public void setLensNA(Float value) {
    setCharacterData(value.toString(), getChildElement("LensNA"));
  }

  /** Gets SerialNumber attribute of the Objective element. */
  public String getSerialNumber() { return getAttribute("SerialNumber"); }

  /** Sets SerialNumber attribute of the Objective element. */
  public void setSerialNumber(String value) {
    setAttribute("SerialNumber", value);
  }

  /** Gets Model attribute of the Objective element. */
  public String getModel() { return getAttribute("Model"); }

  /** Sets Model attribute of the Objective element. */
  public void setModel(String value) { setAttribute("Model", value); }

  /** Gets Manufacturer attribute of the Objective element. */
  public String getManufacturer() { return getAttribute("Manufacturer"); }

  /** Sets Manufacturer attribute of the Objective element. */
  public void setManufacturer(String value) {
    setAttribute("Manufacturer", value);
  }

  /**
   * Gets a list of ImageInstrument elements
   * referencing this Objective node.
   */
  public List getImageInstrumentList() {
    return createAttrReferralNodes(ImageInstrumentNode.class,
      "ImageInstrument", "Objective");
  }

  /**
   * Gets the number of ImageInstrument elements
   * referencing this Objective node.
   */
  public int countImageInstrumentList() {
    return getSize(getAttrReferrals("ImageInstrument", "Objective"));
  }

  /** Gets a list of OTFs referencing this objective. */
  public List getOTFList() {
    return createReferralNodes(OTFNode.class, "OTF");
  }

  /** Gets the number of OTFs referencing this objective. */
  public int countOTFList() { return getSize(getReferrals("OTF")); }

}
