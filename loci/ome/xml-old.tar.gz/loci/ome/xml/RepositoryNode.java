/*
 * loci.ome.xml.RepositoryNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import java.util.List;
import org.openmicroscopy.ds.st.Repository;
import org.w3c.dom.Element;

/**
 * RepositoryNode is the node corresponding to the "Repository" XML element.
 */
public class RepositoryNode extends AttributeNode implements Repository {

  // -- Constructor --

  /** Constructs a Repository node with the given associated DOM element. */
  public RepositoryNode(Element element) { super(element); }


  // -- Repository API methods --

  /** Gets Local attribute of the Repository element. */
  public Boolean isLocal() { return getBooleanAttribute("Local"); }

  /** Sets Local attribute for the Repository element. */
  public void setLocal(Boolean value) {
    setBooleanAttribute("Local", value);
  }

  /** Gets ImageServerURL attribute of the Repository element. */
  public String getImageServerURL() { return getAttribute("ImageServerURL"); }

  /** Sets ImageServerURL attribute for the Repository element. */
  public void setImageServerURL(String value) {
    setAttribute("ImageServerURL", value);
  }

  /** Gets Path attribute of the Repository element. */
  public String getPath() { return getAttribute("Path"); }

  /** Sets Path attribute for the Repository element. */
  public void setPath(String value) { setAttribute("Path", value); }

  /** Gets a list of OTF elements referencing this Repository node. */
  public List getOTFList() {
    return createNodes(OTFNode.class, getAttrReferrals(
       "OTF", "Repository", getLSID(), element.getOwnerDocument()));
  }

  /** Gets the number of OTF elements referencing this Repository node. */
  public int countOTFList() {
    return getSize(getAttrReferrals("OTF",
      "Repository", getLSID(), element.getOwnerDocument()));
  }

  /** Gets a list of OriginalFile elements referencing this Repository node. */
  public List getOriginalFileList() {
    return createNodes(OriginalFileNode.class, getAttrReferrals(
       "OriginalFile", "Repository", getLSID(), element.getOwnerDocument()));
  }

  /**
   * Gets the number of OriginalFile elements referencing this Repository node.
   */
  public int countOriginalFileList() {
    return getSize(getAttrReferrals("OriginalFile",
      "Repository", getLSID(), element.getOwnerDocument()));
  }

  /** Gets a list of Pixels elements referencing this Repository node. */
  public List getPixelsList() {
    return createNodes(PixelsNode.class, getAttrReferrals(
       "Pixels", "Repository", getLSID(), element.getOwnerDocument()));
  }

  /** Gets the number of Pixels elements referencing this Repository node. */
  public int countPixelsList() {
    return getSize(getAttrReferrals("Pixels",
      "Repository", getLSID(), element.getOwnerDocument()));
  }

  /** Gets a list of PixelsPlane elements referencing this Repository node. */
  public List getPixelsPlaneList() {
    return createNodes(PixelsPlaneNode.class, getAttrReferrals(
       "PixelsPlane", "Repository", getLSID(), element.getOwnerDocument()));
  }

  /**
   * Gets the number of PixelsPlane elements referencing this Repository node.
   */
  public int countPixelsPlaneList() {
    return getSize(getAttrReferrals("PixelsPlane",
      "Repository", getLSID(), element.getOwnerDocument()));
  }

  /** Gets a list of Thumbnail elements referencing this Repository node. */
  public List getThumbnailList() {
    return createNodes(ThumbnailNode.class, getAttrReferrals(
       "Thumbnail", "Repository", getLSID(), element.getOwnerDocument()));
  }

  /**
   * Gets the number of Thumbnail elements referencing this Repository node.
   */
  public int countThumbnailList() {
    return getSize(getAttrReferrals("Thumbnail",
      "Repository", getLSID(), element.getOwnerDocument()));
  }

}
