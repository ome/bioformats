/*
 * loci.ome.xml.RatioNode
 *
 *-----------------------------------------------------------------------------
 *
 *  Copyright (C) 2005 Open Microscopy Environment
 *      Massachusetts Institute of Technology,
 *      National Institutes of Health,
 *      University of Dundee,
 *      University of Wisconsin-Madison
 *
 *
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *-----------------------------------------------------------------------------
 */


/*-----------------------------------------------------------------------------
 *
 * Written by:    Curtis Rueden <ctrueden@wisc.edu>
 *
 *-----------------------------------------------------------------------------
 */

package loci.ome.xml;

import org.openmicroscopy.ds.st.Ratio;
import org.w3c.dom.Element;

/** RatioNode is the node corresponding to the "Ratio" XML element. */
public class RatioNode extends AttributeNode implements Ratio {

  // -- Constructor --

  /** Constructs a Ratio node with the given associated DOM element. */
  public RatioNode(Element element) { super(element); }


  // -- Ratio API methods --

  /** Gets Ratio of the Ratio element. */
  public Float getRatio() { return getFloatAttribute("Ratio"); }

  /** Sets Ratio for the Ratio element. */
  public void setRatio(Float value) { setFloatAttribute("Ratio", value); }

}
