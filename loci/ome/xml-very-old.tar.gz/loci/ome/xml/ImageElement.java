//
// ImageElement.java
//

package loci.ome.xml;

import java.util.Vector;

public class ImageElement {

    // -- Fields --

    protected String id, creationDate, name, description;

    protected Vector datasetRefs = new Vector();
    protected Vector features = new Vector();

    protected CAElement customAttr = new CAElement();


    // -- ImageElement API methods --

    public void setID(String s) { id = s; }
    public void setCreationDate(String s) { creationDate = s; }
    public void setName(String s) { name = s; }
    public void setDescription(String s) { description = s; }

    public DatasetRefElement addDatasetRef() {
        DatasetRefElement datasetRef = new DatasetRefElement();
        datasetRefs.add(datasetRef);
        return datasetRef;
    }
    public FeatureElement addFeature() {
        FeatureElement feature = new FeatureElement();
        features.add(feature);
        return feature;
    }

    public String getID() { return id; }
    public String getCreationDate() { return creationDate; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public FeatureElement[] getFeatures() {
        FeatureElement[] f = new FeatureElement[features.size()];
        features.copyInto(f);
        return f;
    }
    public DatasetRefElement[] getDatasetRefs() {
        DatasetRefElement[] d = new DatasetRefElement[datasetRefs.size()];
        datasetRefs.copyInto(d);
        return d;
    }
    public CAElement getCustomAttr() { return customAttr; }

    public void printXML(StringBuffer sb) {
        if (id == null || id.equals("")) return;

        sb.append("  <Image ID=\"");
        sb.append(id);
        sb.append("\"");

        if (creationDate != null) {
            sb.append(" CreationDate=\"");
            sb.append(creationDate);
            sb.append("\"");
        }
        if (name != null) {
            sb.append(" Name=\"");
            sb.append(name);
            sb.append("\"");
        }
        if (description != null) {
            sb.append(" Description=\"");
            sb.append(description);
            sb.append("\"");
        }

        sb.append(">\n");

        for (int i=0; i<datasetRefs.size(); i++) {
            DatasetRefElement datasetRef =
                (DatasetRefElement) datasetRefs.elementAt(i);
            datasetRef.printXML(sb);
        }
        for (int i=0; i<features.size(); i++) {
            FeatureElement feature = (FeatureElement) features.elementAt(i);
            feature.printXML(sb);
        }
        customAttr.printXML(sb);

        sb.append("  </Image>\n");
    }

}
