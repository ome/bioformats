//
// FeatureElement.java
//

package loci.ome.xml;

import java.util.Vector;

public class FeatureElement {

    // -- Fields --

    protected String tag, name, id;
    protected Vector features = new Vector();
    protected CAElement customAttr = new CAElement();


    // -- FeatureElement API methods --

    public void setTag(String s) { tag = s; }
    public void setName(String s) { name = s; }
    public void setID(String s) { id = s; }

    public FeatureElement addFeature() {
        FeatureElement feature = new FeatureElement();
        features.add(feature);
        return feature;
    }

    public String getTag() { return tag; }
    public String getName() { return name; }
    public String getID() { return id; }

    public FeatureElement[] getFeatures() {
        FeatureElement[] f = new FeatureElement[features.size()];
        features.copyInto(f);
        return f;
    }
    public CAElement getCustomAttr() { return customAttr; }

    public void printXML(StringBuffer sb) {
        if (id == null) return;

        sb.append("  <Feature ID=\"");
        sb.append(id);
        sb.append("\" ");

        if (tag != null) {
            sb.append("Tag=\"");
            sb.append(tag);
            sb.append("\" ");
        }
        if (name != null) {
            sb.append("Name=\"");
            sb.append(name);
            sb.append("\" ");
        }

        sb.append(">\n");

        for (int i=0; i<features.size(); i++) {
          FeatureElement feature = (FeatureElement) features.elementAt(i);
          feature.printXML(sb);
        }
        customAttr.printXML(sb);

        sb.append("  </Feature>\n");
    }

}
