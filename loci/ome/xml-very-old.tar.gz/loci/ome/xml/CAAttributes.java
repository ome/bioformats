//
// CAAttributes.java
//

package loci.ome.xml;

import java.util.*;

public class CAAttributes {

    // -- Fields --

    private Hashtable attributes;
    private Vector names;


    // -- Constructor --

    public CAAttributes() {
        attributes = new Hashtable();
        names = new Vector();
    }


    // -- CAAttributes API methods --

    public void setValue(String name, String value) {
      attributes.put(name, value);
      names.add(name);
    }

    public String getValue(String name) {
      return (String) attributes.get(name);
    }

    public String[] getAttrNames() {
      String[] s = new String[names.size()];
      names.copyInto(s);
      return s;
    }

    public String[] getAttrValues() {
      int size = names.size();
      String[] s = new String[size];
      for (int i=0; i<size; i++) {
        s[i] = (String) attributes.get(names.elementAt(i));
      }
      return s;
    }

    public void printXML(StringBuffer sb) {
        int size = names.size();
        for (int i=0; i<size; i++) {
          String name = (String) names.elementAt(i);
          sb.append(" ");
          sb.append(name);
          sb.append("=\"");
          sb.append((String) attributes.get(name));
          sb.append("\"");
        }
    }

}
