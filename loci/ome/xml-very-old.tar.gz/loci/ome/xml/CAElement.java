//
// CAElement.java
//

package loci.ome.xml;

import java.util.*;

public class CAElement {

    // -- Constants --

    public static final String ID = "ID";

    //Detector
    public static final String DETECTOR = "Detector";
    public static final String DETECTOR_MANUFACTURER = "Manufacturer";
    public static final String DETECTOR_MODEL = "Model";
    public static final String DETECTOR_SERIAL_NUMBER = "SerialNumber";
    public static final String DETECTOR_TYPE = "Type";
    public static final String DETECTOR_INSTRUMENT = "Instrument";

    //Dimensions
    public static final String DIMENSIONS = "Dimensions";
    public static final String DIMENSIONS_PIXEL_SIZE_X = "PixelSizeX";
    public static final String DIMENSIONS_PIXEL_SIZE_Y = "PixelSizeY";
    public static final String DIMENSIONS_PIXEL_SIZE_Z = "PixelSizeZ";
    public static final String DIMENSIONS_PIXEL_SIZE_C = "PixelSizeC";
    public static final String DIMENSIONS_PIXEL_SIZE_T = "PixelSizeT";

    //DisplayChannel
    public static final String DISPLAY_CHANNEL = "DisplayChannel";
    public static final String DISPLAY_CHANNEL_CHANNEL_NUMBER =
        "ChannelNumber";
    public static final String DISPLAY_CHANNEL_BLACK_LEVEL = "BlackLevel";
    public static final String DISPLAY_CHANNEL_WHITE_LEVEL = "WhiteLevel";
    public static final String DISPLAY_CHANNEL_GAMMA = "Gamma";

    //DisplayOptions
    public static final String DISPLAY_OPTIONS = "DisplayOptions";
    public static final String DISPLAY_OPTIONS_ZOOM = "Zoom";
    public static final String DISPLAY_OPTIONS_Z_START = "ZStart";
    public static final String DISPLAY_OPTIONS_Z_STOP = "ZStop";
    public static final String DISPLAY_OPTIONS_T_START = "TStart";
    public static final String DISPLAY_OPTIONS_T_STOP = "TStop";
    public static final String DISPLAY_OPTIONS_RED_CHANNEL = "RedChannel";
    public static final String DISPLAY_OPTIONS_GREEN_CHANNEL =
        "GreenChannel";
    public static final String DISPLAY_OPTIONS_BLUE_CHANNEL = "BlueChannel";

    //DisplayROI
    public static final String DISPLAY_ROI = "DisplayROI";
    public static final String DISPLAY_ROI_X0 = "X0";
    public static final String DISPLAY_ROI_Y0 = "Y0";
    public static final String DISPLAY_ROI_Z0 = "Z0";
    public static final String DISPLAY_ROI_X1 = "X1";
    public static final String DISPLAY_ROI_Y1 = "Y1";
    public static final String DISPLAY_ROI_Z1 = "Z1";
    public static final String DISPLAY_ROI_T0 = "T0";
    public static final String DISPLAY_ROI_T1 = "T1";
    public static final String DISPLAY_ROI_DISPLAY_OPTIONS =
        "DisplayOptions";

    //Experiment
    public static final String EXPERIMENT = "Experiment";
    public static final String EXPERIMENT_TYPE = "Type";
    public static final String EXPERIMENT_DESCRIPTION = "Description";
    public static final String EXPERIMENT_EXPERIMENTER = "Experimenter";

    //Experimenter
    public static final String EXPERIMENTER = "Experimenter";
    public static final String EXPERIMENTER_FIRST_NAME = "FirstName";
    public static final String EXPERIMENTER_LAST_NAME = "LastName";
    public static final String EXPERIMENTER_EMAIL = "Email";
    public static final String EXPERIMENTER_OME_NAME = "OMEName";

    //ExperimenterGroup
    public static final String EXPERIMENTER_GROUP = "ExperimenterGroup";
    public static final String EXPERIMENTER_GROUP_EXPERIMENTER =
        "Experimenter";
    public static final String EXPERIMENTER_GROUP_GROUP = "Group";

    //Filter
    public static final String FILTER = "Filter";
    public static final String FILTER_INSTRUMENT = "Instrument";

    //FilterSet
    public static final String FILTER_SET = "FilterSet";
    public static final String FILTER_SET_MANUFACTURER = "Manufacturer";
    public static final String FILTER_SET_MODEL = "Model";
    public static final String FILTER_SET_LOT_NUMBER = "LotNumber";
    public static final String FILTER_SET_FILTER = "Filter";

    //Group
    public static final String GROUP = "Group";
    public static final String GROUP_NAME = "Name";
    public static final String GROUP_LEADER = "Leader";
    public static final String GROUP_CONTACT = "Contact";

    //ImageExperiment
    public static final String IMAGE_EXPERIMENT = "ImageExperiment";
    public static final String IMAGE_EXPERIMENT_EXPERIMENT = "Experiment";

    //ImageInstrument
    public static final String IMAGE_INSTRUMENT = "ImageInstrument";
    public static final String IMAGE_INSTRUMENT_INSTRUMENT = "Instrument";

    //ImagePlate
    public static final String IMAGE_PLATE = "ImagePlate";
    public static final String IMAGE_PLATE_WELL = "Well";
    public static final String IMAGE_PLATE_PLATE = "Plate";
    public static final String IMAGE_PLATE_SAMPLE = "Sample";

    //ImagingEnvironment
    public static final String IMAGING_ENVIRONMENT = "ImagingEnvironment";
    public static final String IMAGING_ENVIRONMENT_TEMPERATURE =
        "Temperature";
    public static final String IMAGING_ENVIRONMENT_AIR_PRESSURE =
        "AirPressure";
    public static final String IMAGING_ENVIRONMENT_HUMIDITY = "Humidity";
    public static final String IMAGING_ENVIRONMENT_CO2_PERCENT =
        "CO2Percent";

    //Instrument
    public static final String INSTRUMENT = "Instrument";
    public static final String INSTRUMENT_MANUFACTURER = "Manufacturer";
    public static final String INSTRUMENT_MODEL = "Model";
    public static final String INSTRUMENT_SERIAL_NUMBER = "SerialNumber";
    public static final String INSTRUMENT_TYPE = "Type";

    //LightSource
    public static final String LIGHT_SOURCE = "LightSource";
    public static final String LIGHT_SOURCE_MANUFACTURER = "Manufacturer";
    public static final String LIGHT_SOURCE_MODEL = "Model";
    public static final String LIGHT_SOURCE_SERIAL_NUMBER = "SerialNumber";
    public static final String LIGHT_SOURCE_INSTRUMENT = "Instrument";

    //LogicalChannel
    public static final String LOGICAL_CHANNEL = "LogicalChannel";
    public static final String LOGICAL_CHANNEL_NAME = "Name";
    public static final String LOGICAL_CHANNEL_ILLUMINATION_TYPE =
        "IlluminationType";
    public static final String LOGICAL_CHANNEL_AUX_TECHNIQUE =
        "AuxTechnique";
    public static final String LOGICAL_CHANNEL_EX_WAVE = "ExWave";
    public static final String LOGICAL_CHANNEL_EM_WAVE = "EmWave";
    public static final String LOGICAL_CHANNEL_FLOUR = "Flour";
    public static final String LOGICAL_CHANNEL_ND_FILTER = "NDfilter";
    public static final String LOGICAL_CHANNEL_LIGHT_SOURCE = "LightSource";
    public static final String LOGICAL_CHANNEL_AUX_LIGHT_SOURCE =
        "AuxLightSource";
    public static final String LOGICAL_CHANNEL_DETECTOR = "Detector";
    public static final String LOGICAL_CHANNEL_OTF = "OTF";
    public static final String LOGICAL_CHANNEL_FILTER = "Filter";

    //Objective
    public static final String OBJECTIVE = "Objective";
    public static final String OBJECTIVE_MANUFACTURER = "Manufacturer";
    public static final String OBJECTIVE_MODEL = "Model";
    public static final String OBJECTIVE_SERIAL_NUMBER = "SerialNumber";
    public static final String OBJECTIVE_LENS_NA = "LensNA";
    public static final String OBJECTIVE_MAGNIFICATION = "Magnification";
    public static final String OBJECTIVE_INSTRUMENT = "Instrument";

    //OpticalTransferFunction
    public static final String OPTICAL_TRANSFER_FUNCTION =
        "OpticalTransferFunction";
    public static final String OPTICAL_TRANSFER_FUNCTION_SIZE_X = "SizeX";
    public static final String OPTICAL_TRANSFER_FUNCTION_SIZE_Y = "SizeY";
    public static final String OPTICAL_TRANSFER_FUNCTION_PIXEL_TYPE =
        "PixelType";
    public static final String
        OPTICAL_TRANSFER_FUNCTION_OPTICAL_AXIS_AVERAGE = "OpticalAxisAverage";
    public static final String OPTICAL_TRANSFER_FUNCTION_INSTRUMENT =
        "Instrument";
    public static final String OPTICAL_TRANSFER_FUNCTION_OBJECTIVE =
        "Objective";
    public static final String OPTICAL_TRANSFER_FUNCTION_FILTER = "Filter";

    //PixelChannelComponent
    public static final String PIXEL_CHANNEL_COMPONENT =
        "PixelChannelComponent";
    public static final String PIXEL_CHANNEL_COMPONENT_PIXELS = "Pixels";
    public static final String PIXEL_CHANNEL_COMPONENT_INDEX = "Index";
    public static final String PIXEL_CHANNEL_COMPONENT_COLOR_DOMAIN =
        "ColorDomain";
    public static final String PIXEL_CHANNEL_COMPONENT_LOGICAL_CHANNEL =
        "LogicalChannel";

    //Plate
    public static final String PLATE = "Plate";
    public static final String PLATE_NAME = "Name";
    public static final String PLATE_EXTERNAL_REFERENCE =
        "ExternalReference";

    //PlateScreen
    public static final String PLATE_SCREEN = "PlateScreen";
    public static final String PLATE_SCREEN_PLATE = "PlateScreenPlate";
    public static final String PLATE_SCREEN_SCREEN = "PlateScreenScreen";

    //Screen
    public static final String SCREEN = "Screen";
    public static final String SCREEN_NAME = "Name";
    public static final String SCREEN_EXTERNAL_REFERENCE =
        "ExternalReference";

    //StageLabel
    public static final String STAGE_LABEL = "StageLabel";
    public static final String STAGE_LABEL_NAME = "Name";
    public static final String STAGE_LABEL_X = "X";
    public static final String STAGE_LABEL_Y = "Y";
    public static final String STAGE_LABEL_Z = "Z";


    // -- Fields --

    protected Hashtable elements;
    protected Vector names;
    protected int currentID = -1;


    // -- Constructor --

    public CAElement() {
        elements = new Hashtable();
        names = new Vector();
    }


    // -- CAElement API methods --

    public int getCurrentID() { return currentID; }

    public int createElement(String elmt) {
        ++currentID;
        names.add(currentID, elmt);
        elements.put(new Integer(currentID), new CAAttributes());
        return currentID;
    }

    public void setAttribute(String attr, String value) {
        // CTR the following line is a hack that should probably be eliminated at some point
        if (attr.equals(ID)) createElement(attr);
        setAttribute(currentID, attr, value);
    }

    public void setAttribute(int id, String attr, String value) {
        CAAttributes attributes;
        Integer idKey = new Integer(id);
        if (elements.containsKey(idKey)) {
            attributes = (CAAttributes) elements.get(idKey);
            attributes.setValue(attr, value);
        }
        else {
            // this should never happen...
            attributes = new CAAttributes();
            attributes.setValue(attr, value);
            elements.put(idKey, attributes);
        }
    }
    
    /**
     * Gets all element names. The list contains each name the number of times it appears
     * (not just once). That is, there are as many duplicates as there are ids for that
     * element name.
     */
    public String[] getElementNames() {
        String[] n = new String[names.size()];
        names.copyInto(n);
        return n;
    }
    
    /** Gets all element ids for all element names. */
    public int[] getElementIDs() {
        int[] ids = new int[names.size()];
        for (int i=0; i<ids.length; i++) ids[i] = i;
        return ids;
    }
    
    /** Gets all element ids for the given element name. */
    public int[] getElementIDs(String elmt) {
        int ndx = 0;
        Vector v = new Vector();
        while (true) {
            ndx = names.indexOf(elmt, ndx);
            if (ndx < 0) break;
            v.add(new Integer(ndx));
            ndx++;
        }
        int[] ids = new int[v.size()];
        for (int i=0; i<ids.length; i++) {
            ids[i] = ((Integer) v.elementAt(i)).intValue();
        }
        return ids;
    }

    /** Gets corresponding element name for the given element id. */
    public String getElementName(int id) {
        if (id < 0 || id >= names.size()) return null;
        return (String) names.elementAt(id);
    }
    
    public String[] getAttributeNames(int id) {
        CAAttributes attributes;
        Integer idKey = new Integer(id);
        if (elements.containsKey(idKey)) {
            attributes = (CAAttributes) elements.get(idKey);
            return attributes.getAttrNames();
        }
        /*TEMP*/System.out.println("OH MY GOD NO");
        return null;
    }

    public String getAttribute(int id, String attr) {
        CAAttributes attributes;
        Integer idKey = new Integer(id);
        if (elements.containsKey(idKey)) {
            attributes = (CAAttributes) elements.get(idKey);
            return attributes.getValue(attr);
        }
        return null;
    }

    public String[] getAttributes(String elmt, String attr) {
        int[] ids = getElementIDs(elmt);
        String[] s = new String[ids.length];
        for (int i=0; i<ids.length; i++) s[i] = getAttribute(ids[i], attr);
        return s;
    }

    public void printXML(StringBuffer sb) {
        if (elements.isEmpty()) return;

        Enumeration elmt = elements.keys();
        sb.append("    <CustomAttributes>\n");

        int namesSize = names.size();
        for (int i=0; i<namesSize; i++) {
            String ename = (String) names.elementAt(i);
            Integer idKey = new Integer(i);
            CAAttributes attributes = (CAAttributes) elements.get(idKey);
            sb.append("      <");
            sb.append(ename);
            attributes.printXML(sb);
            sb.append("/>\n");
        }
        sb.append("    </CustomAttributes>\n");
    }

}