//
// DatasetRefElement.java
//

package loci.ome.xml;

public class DatasetRefElement {

    // -- Fields --

    protected String id;


    // -- DatasetRefElement API methods --

    public void setID(String s) { id = s; }

    public String getID() { return id; }

    public void printXML(StringBuffer sb) {
        if (id == null) return;

        sb.append("    <DatasetRef ID=\"");
        sb.append(id);
        sb.append("\"/>\n");
    }
}


