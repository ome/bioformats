//
// DatasetElement.java
//

package loci.ome.xml;

import java.util.Vector;

public class DatasetElement{

    // -- Fields --

    protected String name, experimenter, id, description;
    protected String locked, group;

    protected Vector projectRefs = new Vector();
    protected CAElement customAttr = new CAElement();


    // -- DatasetElement API methods --

    public void setName(String s) { name = s; }
    public void setExperimenter(String s) { experimenter = s; }
    public void setID(String s) { id = s; }
    public void setDescription(String s) { description = s; }

    public void setLocked(String s) { locked = s; }
    public void setGroup(String s) { group = s; }

    public ProjectRefElement addProjectRef() {
        ProjectRefElement projectRef = new ProjectRefElement();
        projectRefs.add(projectRef);
        return projectRef;
    }

    public String getName() { return name; }
    public String getExperimenter() { return experimenter; }
    public String getID() { return id; }
    public String getDescription() { return description; }

    public String getLocked() { return locked; }
    public String getGroup() { return group; }

    public ProjectRefElement[] getProjectRefs() {
        ProjectRefElement[] p = new ProjectRefElement[projectRefs.size()];
        projectRefs.copyInto(p);
        return p;
    }
    public CAElement getCustomAttr() { return customAttr; }

    public void printXML(StringBuffer sb) {
        if (id == null) return;

        sb.append("  <Dataset ID=\"");
        sb.append(id);
        sb.append("\"");

        if (name != null) {
            sb.append(" Name=\"");
            sb.append(name);
            sb.append("\"");
        }
        if (experimenter != null) {
            sb.append(" Experimenter=\"");
            sb.append(experimenter);
            sb.append("\"");
        }
        if (description != null) {
            sb.append(" Description=\"");
            sb.append(description);
            sb.append("\"");
        }
        if (locked != null) {
            sb.append(" Locked=\"");
            sb.append(locked);
            sb.append("\"");
        }
        if (group != null) {
            sb.append(" Group=\"");
            sb.append(group);
            sb.append("\"");
        }

        sb.append(">\n");

        for (int i=0; i<projectRefs.size(); i++) {
            ProjectRefElement projectRef =
                (ProjectRefElement) projectRefs.elementAt(i);
            projectRef.printXML(sb);
        }
        customAttr.printXML(sb);

        sb.append("  </Dataset>\n");
    }

}
