//
// OMECATester.java
//

package loci.ome.xml;

import java.io.IOException;

import org.xml.sax.SAXException;

public class OMECATester {

  public static void main(String[] args) throws IOException, SAXException {
      System.out.println("creating OME root structure");
      OMEElement ome = new OMEElement();

      String inFile = args.length < 1 ? "Sample-CA.ome" : args[0];
      System.out.println("reading OMECA XML: " + inFile);
      ome.readXML(inFile);

      String outFile = args.length < 2 ? "out.ome" : args[1];
      System.out.println("writing OMECA XML: " + outFile);
      ome.printXML(outFile);
  }

}
