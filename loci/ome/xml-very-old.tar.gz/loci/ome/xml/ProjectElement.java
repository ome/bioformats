//
// ProjectElement.java
//

package loci.ome.xml;

public class ProjectElement {

    // -- Fields --

    protected String id, name, experimenter, description;
    protected String group;


    // -- ProjectElement API methods --

    public void setID(String s) { id = s; }
    public void setExperimenter(String s) { experimenter = s; }
    public void setName(String s) { name = s; }
    public void setDescription(String s) { description = s; }

    public void setGroup(String s) { group = s; }

    public String getID() { return id; }
    public String getExperimenter() { return experimenter; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public String getGroup() { return group; }

    public void printXML(StringBuffer sb) {
        if (id == null) return;

        sb.append("  <Project ID=\"");
        sb.append(id);
        sb.append("\"");

        if (experimenter != null) {
            sb.append(" Experimenter=\"");
            sb.append(experimenter);
            sb.append("\"");
        }
        if (name != null) {
            sb.append(" Name=\"");
            sb.append(name);
            sb.append("\"");
        }
        if (description != null) {
            sb.append(" Description=\"");
            sb.append(description);
            sb.append("\"");
        }
        if (group != null) {
            sb.append(" Group=\"");
            sb.append(group);
            sb.append("\"");
        }

        sb.append("/>\n");
    }

}
