//
// OMEElement.java
//

package loci.ome.xml;

import java.io.*;
import javax.xml.parsers.*;
import org.xml.sax.*;

public class OMEElement {

    // -- Constants --

    protected static final String[] HEADER_MESSAGE = {
      "This file was written by LOCI's Java OME-CA XML library,",
      "coded in 2004 by Maimoon Nasim and Curtis Rueden."
    };

    protected static final String XMLNS =
      "http://www.openmicroscopy.org/XMLschemas/CA/RC1/CA.xsd";

    protected static final String XMLNS_XSI =
      "http://www.w3.org/2001/XMLSchema-instance";

    protected static final String[] XSI_SCHEMA_LOCATIONS = {
      "http://www.openmicroscopy.org/XMLschemas/OME/FC/ome.xsd",
      "http://www.openmicroscopy.org/XMLschemas/STD/RC2/STD.xsd"
    };


    // -- Fields --

    protected ProjectElement project = new ProjectElement();
    protected DatasetElement dataset = new DatasetElement();
    protected ImageElement image = new ImageElement();
    protected CAElement customAttr = new CAElement();


    // -- OMEElement API methods --

    public ProjectElement getProject() { return project; }
    public DatasetElement getDataset() { return dataset; }
    public ImageElement getImage() { return image; }
    public CAElement getCustomAttr() { return customAttr; }

    public void printXML(PrintWriter out) throws IOException {
        StringBuffer sb = new StringBuffer();
        sb.append("<?xml version=\"1.0\"?>\n");
        sb.append("<!--\n");
        for (int i=0; i<HEADER_MESSAGE.length; i++) {
          sb.append(HEADER_MESSAGE[i]);
          sb.append("\n");
        }
        sb.append("-->\n");

        sb.append("<OME ");
        sb.append("xmlns=\"");
        sb.append(XMLNS);
        sb.append("\" xmlns:xsi=\"");
        sb.append(XMLNS_XSI);
        sb.append("\" xsi:schemaLocation=\"");
        for (int i=0; i<XSI_SCHEMA_LOCATIONS.length; i++) {
          if (i > 0) sb.append(" ");
          sb.append(XSI_SCHEMA_LOCATIONS[i]);
        }
        sb.append("\">\n");

        project.printXML(sb);
        dataset.printXML(sb);
        image.printXML(sb);
        customAttr.printXML(sb);
        sb.append("</OME>\n");

        out.print(sb.toString());
    }

    public void printXML(String filename) throws IOException {
        PrintWriter fout = new PrintWriter(new FileWriter(filename));
        printXML(fout);
        fout.close();
    }

    public void readXML(InputSource in) throws SAXException, IOException {
        SAXParser parser = null;
        try { parser = SAXParserFactory.newInstance().newSAXParser(); }
        catch (ParserConfigurationException exc) { exc.printStackTrace(); }

        OMECAHandler handler = new OMECAHandler(this);

        parser.parse(in, handler);
    }

    public void readXML(InputStream in) throws SAXException, IOException{
      SAXParser parser = null;
        try { parser = SAXParserFactory.newInstance().newSAXParser(); }
        catch (ParserConfigurationException exc) { exc.printStackTrace(); }

        OMECAHandler handler = new OMECAHandler(this);

        parser.parse(in, handler);
    }

    public void readXML(String filename) throws SAXException, IOException {
      FileInputStream fin = new FileInputStream(filename);
      readXML(fin);
      fin.close();
    }

}
