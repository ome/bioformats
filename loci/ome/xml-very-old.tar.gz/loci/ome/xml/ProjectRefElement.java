//
// ProjectRefElement.java
//

package loci.ome.xml;

public class ProjectRefElement {

    // -- Fields --

    protected String id;


    // -- ProjectRefElement API methods --

    public void setID(String s) { id = s; }

    public String getID() { return id; }

    public void printXML(StringBuffer sb) {
        if (id == null) return;

        sb.append("    <ProjectRef ID=\"");
        sb.append(id);
        sb.append("\"/>\n");
    }

}
