//
// OMECAHandler.java
//

package loci.ome.xml;

import java.util.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

public class OMECAHandler extends DefaultHandler {

  // -- Constants --

  protected static final boolean DEBUG = false;


  // -- Fields --

  protected OMEElement root;

  protected String chars = "";
  protected int indent = 0;

  protected Stack stack = new Stack();
  protected Vector errors = new Vector();


  // -- Constructor --

  public OMECAHandler(OMEElement ome) { root = ome; }


  // -- OMECAHandler API methods --

  /** Gets list of errors encountered while parsing the XML. */
  public String[] getParseErrors() {
    String[] s = new String[errors.size()];
    errors.copyInto(s);
    return s;
  }


  // -- ContentHandler API methods --

  public void startElement(String uri, String lName, String qName,
    Attributes attrs)
  {
    if (DEBUG) {
      System.out.print(space() + "<" + qName);
      indent += 2;

      int len = attrs.getLength();
      for (int i=0; i<len; i++) {
        String attr = attrs.getQName(i);
        String value = attrs.getValue(i);
        System.out.println();
        System.out.print(space() + attr + "=\"" + value + "\"");
      }
      System.out.println(">");
      chars = "";
    }

    if (qName.equals("CustomAttributes")) parseCustomAttributes(attrs);
    else if (qName.equals("Dataset")) parseDataset(attrs);
    else if (qName.equals("DatasetRef")) parseDatasetRef(attrs);
    else if (qName.equals("Feature")) parseFeature(attrs);
    else if (qName.equals("Image")) parseImage(attrs);
    else if (qName.equals("OME")) parseOME(attrs);
    else if (qName.equals("Project")) parseProject(attrs);
    else if (qName.equals("ProjectRef")) parseProjectRef(attrs);
    else parseWildcard(qName, attrs);
  }

  public void endElement(String uri, String lName, String qName) {
    if (DEBUG) {
      if (!chars.equals("")) System.out.println(space() + chars);
      indent -= 2;
      System.out.println(space() + "</" + qName + ">");
    }

    Object o = stack.pop();

    if (qName.equals("CustomAttributes")) checkType(o, CAElement.class);
    else if (qName.equals("Dataset")) checkType(o, DatasetElement.class);
    else if (qName.equals("DatasetRef")) checkType(o, DatasetRefElement.class);
    else if (qName.equals("Feature")) checkType(o, FeatureElement.class);
    else if (qName.equals("Image")) checkType(o, ImageElement.class);
    else if (qName.equals("OME")) checkType(o, OMEElement.class);
    else if (qName.equals("Project")) checkType(o, ProjectElement.class);
    else if (qName.equals("ProjectRef")) checkType(o, ProjectRefElement.class);
    else checkType(o, String.class);
  }

  public void characters(char[] ch, int start, int length) {
    if (DEBUG) {
      String s = new String(ch, start, length).trim();
      chars += s;
    }
  }


  // -- Helper methods --

  /** Handles parsing of CustomAttributes tag. */
  protected void parseCustomAttributes(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<Feature> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    CAElement custom;
    if (o instanceof DatasetElement) {
      DatasetElement dataset = (DatasetElement) o;
      custom = dataset.getCustomAttr();
    }
    else if (o instanceof FeatureElement) {
      FeatureElement feature = (FeatureElement) o;
      custom = feature.getCustomAttr();
    }
    else if (o instanceof ImageElement) {
      ImageElement image = (ImageElement) o;
      custom = image.getCustomAttr();
    }
    else if (o instanceof OMEElement) {
      OMEElement ome = (OMEElement) o;
      custom = ome.getCustomAttr();
    }
    else {
      errors.add("<Feature> tag must lie within " +
        "<Dataset>, <Feature>, <Image> or <OME> scope");
      return;
    }

    stack.push(custom);
  }

  /** Handles parsing of Dataset tag. */
  protected void parseDataset(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<Dataset> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    if (!(o instanceof OMEElement)) {
      errors.add("<Dataset> tag must lie within <OME> scope");
      return;
    }
    OMEElement ome = (OMEElement) o;
    DatasetElement dataset = ome.getDataset();

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);

      if (attr.equals("Name")) dataset.setName(value);
      else if (attr.equals("Experimenter")) dataset.setExperimenter(value);
      else if (attr.equals("ID")) dataset.setID(value);
      else if (attr.equals("Description")) dataset.setDescription(value);

      else if (attr.equals("Locked")) dataset.setLocked(value);
      else if (attr.equals("Group")) dataset.setGroup(value);

      else errors.add("Unknown <Dataset> attribute \"" + attr + "\"");
    }

    stack.push(dataset);
  }

  /** Handles parsing of DatasetRef tag. */
  protected void parseDatasetRef(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<DatasetRef> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    if (!(o instanceof ImageElement)) {
      errors.add("<DatasetRef> tag must lie within <Image> scope");
      return;
    }
    ImageElement image = (ImageElement) o;
    DatasetRefElement datasetRef = image.addDatasetRef();

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);

      if (attr.equals("ID")) datasetRef.setID(value);

      else errors.add("Unknown <DatasetRef> attribute \"" + attr + "\"");
    }

    stack.push(datasetRef);
  }

  /** Handles parsing of Feature tag. */
  protected void parseFeature(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<Feature> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    FeatureElement feature;
    if (o instanceof FeatureElement) {
      FeatureElement parent = (FeatureElement) o;
      feature = parent.addFeature();
    }
    else if (o instanceof ImageElement) {
      ImageElement image = (ImageElement) o;
      feature = image.addFeature();
    }
    else {
      errors.add("<Feature> tag must lie within <Feature> or <Image> scope");
      return;
    }

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);

      if (attr.equals("Tag")) feature.setTag(value);
      else if (attr.equals("Name")) feature.setName(value);
      else if (attr.equals("ID")) feature.setID(value);

      else errors.add("Unknown <Feature> attribute \"" + attr+ "\"");
    }

    stack.push(feature);
  }

  /** Handles parsing of Image tag. */
  protected void parseImage(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<Image> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    if (!(o instanceof OMEElement)) {
      errors.add("<Image> tag must lie within <OME> scope");
      return;
    }
    OMEElement ome = (OMEElement) o;
    ImageElement image = ome.getImage();

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);

      if (attr.equals("ID")) image.setID(value);
      else if (attr.equals("CreationDate")) image.setCreationDate(value);
      else if (attr.equals("Name")) image.setName(value);
      else if (attr.equals("Description")) image.setDescription(value);

      else errors.add("Unknown <Image> attribute \"" + attr + "\"");
    }

    stack.push(image);
  }

  /** Handles parsing of OME tag. */
  protected void parseOME(Attributes attrs) {
    if (!stack.isEmpty()) {
      errors.add("<OME> tag must be root element");
      return;
    }
    OMEElement ome = root;

    stack.push(ome);
  }

  /** Handles parsing of Project tag. */
  protected void parseProject(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<Project> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    if (!(o instanceof OMEElement)) {
      errors.add("<Project> tag must lie within <OME> scope");
      return;
    }
    OMEElement ome = (OMEElement) o;
    ProjectElement project = ome.getProject();

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);

      if (attr.equals("ID")) project.setID(value);
      else if (attr.equals("Experimenter")) project.setExperimenter(value);
      else if (attr.equals("Name")) project.setName(value);
      else if (attr.equals("Description")) project.setDescription(value);

      else if (attr.equals("Group")) project.setGroup(value);

      else errors.add("Unknown <Project> attribute \"" + attr + "\"");
    }

    stack.push(project);
  }

  /** Handles parsing of ProjectRef tag. */
  protected void parseProjectRef(Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<ProjectRef> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    if (!(o instanceof DatasetElement)) {
      errors.add("<ProjectRef> tag must lie within <Dataset> scope");
      return;
    }
    DatasetElement dataset = (DatasetElement) o;
    ProjectRefElement projectRef = dataset.addProjectRef();

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);

      if (attr.equals("ID")) projectRef.setID(value);

      else errors.add("Unknown <ProjectRef> attribute \"" + attr + "\"");
    }

    stack.push(projectRef);
  }

  /** Handles parsing of custom attributes wildcard elements. */
  protected void parseWildcard(String name, Attributes attrs) {
    if (stack.isEmpty()) {
      errors.add("<" + name + "> tag must not be root element");
      return;
    }
    Object o = stack.peek();
    if (!(o instanceof CAElement)) {
      errors.add(
        "<" + name + "> tag must lie within <CustomAttributes> scope");
      return;
    }
    CAElement custom = (CAElement) o;

    int id = custom.createElement(name);

    int len = attrs.getLength();
    for (int i=0; i<len; i++) {
      String attr = attrs.getQName(i);
      String value = attrs.getValue(i);
      custom.setAttribute(id, attr, value);
    }

    stack.push(name);
  }

  /** Verifies the given object is an instance of the specified class. */
  protected void checkType(Object o, Class c) {
    if (o.getClass().equals(c)) return;
    errors.add("Unexpected end element tag type \"" +
      o.getClass().getName() + "\" (expected \"" + c.getName() + "\")");
  }

  protected String space() {
    char[] c = new char[indent];
    Arrays.fill(c, ' ');
    return new String(c);
  }

}
